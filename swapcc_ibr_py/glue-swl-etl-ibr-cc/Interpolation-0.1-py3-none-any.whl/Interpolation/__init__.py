from .Interpolation import Interpol
