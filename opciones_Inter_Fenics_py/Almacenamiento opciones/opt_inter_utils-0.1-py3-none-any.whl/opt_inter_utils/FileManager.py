import json
import logging
import time

from precia_utils.precia_logger import create_log_msg
from precia_utils.precia_exceptions import PlataformError
from precia_utils import precia_aws, precia_sftp


logger = logging.getLogger()


class FileManager:
    """
    Clase que representa los archivos de opciones internacionales

    Attributes:
    ----------
    instrument: str
        El nombre del instrumento
    valuation_date: str
        Fecha de valoración
    opcdd: Dataframe
        Contiene la información para la generación del archivo opcdd
    opcd: Dataframe
        Contiene la información para la generación del archivo opcd
    opbrd: Dataframe
        Contiene la información para la generación del archivo opbrd
    opbr: Dataframe
        Contiene la información para la generación del archivo opbr

    Methods:
    --------
    rename_column_dataframes(df_op, column_new)
        Cambia el nombre de las columnas según los parámetros establecidos

    load_files_to_sftp(route_sftp, sftp, df_op, file_name, columns_file)
        Genera y carga los archivos en el SFTP

    run()
        Orquesta los métodos de la clase

    """

    def __init__(self, instrument, valuation_date, opcdd, opcd, opbrd, opbr) -> None:
        self.instrument = instrument
        self.valuation_date = valuation_date.replace("-", "")
        self.opcdd = opcdd
        self.opcd = opcd
        self.opbrd = opbrd
        self.opbr = opbr

    def rename_column_dataframes(self, df_op, column_new, file_alias):
        """Cambia el nombre de las columnas según los parámetros establecidos
        Parameters:
        ----------
        df_op: Dataframe, required
            Datos para la creación del archivo
        column_new: dict, required
            Nombre de las columnas que serán reemplazadas y las nuevas
        """
        logger.info(
            "Comienza a renombrar las columnas del dataframe %s ...", file_alias
        )
        if df_op.empty:
            error_msg = "El Dataframe a transformar en archivo se encuentra vacío"
            logger.error(error_msg)
            raise PlataformError(error_msg)

        try:
            df_op.rename(columns=column_new, inplace=True)
        except (Exception,) as name_exc:
            logger.error(
                create_log_msg("No se pudo renombrar las columnas del dataframe")
            )
            raise_msg = f"Fallo el cambio de nombre de las columnas para {file_alias}"
            raise PlataformError(raise_msg) from name_exc

    def load_files_to_sftp(self, route_sftp, sftp, df_op, file_name, columns_file):
        """Genera y carga los archivos en el SFTP

        Parameters:
        -----------
        route_sftp: str, required
            Contiene la ruta en donde se guardan los archivos en el SFTP
        sftp: SFTPClient, required
            Es la conexión al SFTP
        df_op: Dataframe, required
            Datos que van en el archivo
        file_name: str, required
            Nombre del archivo a generar
        columns_file: list, required
            Columnas que irán en el archivo
        """
        error_msg = f"No se pudo generar el archivo en el SFTP: {file_name}"
        try:
            logger.info("Comenzando a generar el archivo %s en el sftp ...", file_name)
            decimal = precia_aws.get_params(["DECIMAL_ROUND"])["DECIMAL_ROUND"]
            sftp_full_path = route_sftp + file_name
            logger.info("Ruta destino: %s", sftp_full_path)
            with sftp.open(sftp_full_path, "w") as f:
                f.write(
                    df_op.to_csv(
                        index=False,
                        sep=" ",
                        columns=columns_file,
                        float_format=f"%.{decimal}f",
                    )
                )
            logger.info("Archivo generado exitosamente")
        except (Exception,) as load_exc:
            logger.error(create_log_msg(error_msg))
            raise PlataformError() from load_exc

        logger.info("El archivo se creo correctamente: %s", file_name)

    def run(self):
        """Orquesta los métodos de la clase
        Trae los parámetros necearios para la clase
        Trae la conexión SFTP de precia_utils.connect_to_sftp y la cierra
        """
        error_msg = "Fallo la carga de la configuracion para la creacion de archivos"
        try:
            logger.info(
                "Comienza a traer los datos para la creación de los archivos y los castea"
            )
            glue_params = precia_aws.get_params(
                [
                    "PARAMS_FILE_OPCDD",
                    "PARAMS_FILE_OPCD",
                    "PARAMS_FILE_OPBRD",
                    "PARAMS_FILE_OPBR",
                    "FTP_MAX_RETRIES",
                    "FTP_WAIT_FOR_RETRY",
                    "CONFIG_SECRET_NAME",
                    "PATH_OUT_OPT_INTER",
                    "SFTP_OUTPUT",
                ]
            )
            info_opcdd = json.loads(glue_params["PARAMS_FILE_OPCDD"])
            info_opcd = json.loads(glue_params["PARAMS_FILE_OPCD"])
            info_opbrd = json.loads(glue_params["PARAMS_FILE_OPBRD"])
            info_opbr = json.loads(glue_params["PARAMS_FILE_OPBR"])
            optimusk_config = precia_aws.get_secret(glue_params["CONFIG_SECRET_NAME"])
            route_sftp = optimusk_config[glue_params["PATH_OUT_OPT_INTER"]]
        except PlataformError:
            logger.error(create_log_msg(error_msg))
            raise
        except (Exception,) as config_exc:
            logger.error(create_log_msg(error_msg))
            raise PlataformError() from config_exc

        error_msg = "Fallo al dar formato a los nombres de los archivos"
        try:
            logger.info("Formatear el nombre de los archivos...")
            file_name_opcdd = info_opcdd["filename"].format(
                instrument=self.instrument, valuation_date=self.valuation_date
            )
            file_name_opcd = info_opcd["filename"].format(
                instrument=self.instrument, valuation_date=self.valuation_date
            )
            file_name_opbrd = info_opbrd["filename"].format(
                instrument=self.instrument, valuation_date=self.valuation_date
            )
            file_name_opbr = info_opbr["filename"].format(
                instrument=self.instrument, valuation_date=self.valuation_date
            )
        except (Exception,) as format_exc:
            logger.error(create_log_msg(error_msg))
            raise PlataformError() from format_exc

        error_msg = "Fallo al actualizar las columnas de los Dataframes de los archivos"
        try:
            logger.info("Cambio nombre de columnas Dataframes")
            self.rename_column_dataframes(
                self.opcdd, info_opcdd["header"]["column_dict"], "opcdd"
            )
            self.rename_column_dataframes(
                self.opcd, info_opcd["header"]["column_dict"], "opcd"
            )
            self.rename_column_dataframes(
                self.opbrd, info_opbrd["header"]["column_dict"], "opbrd"
            )
            self.rename_column_dataframes(
                self.opbr, info_opbr["header"]["column_dict"], "opbr"
            )
        except (Exception,) as col_exc:
            logger.error(create_log_msg(error_msg))
            raise PlataformError() from col_exc

        error_msg = "Fallo la obtención del secreto y la conexión SFTP"
        try:
            max_tries = int(glue_params["FTP_MAX_RETRIES"])
            wait_time = int(glue_params["FTP_WAIT_FOR_RETRY"])
            logger.info("Trae el valor de los secretos para la conexión al SFTP")
            sftp_secret_name = optimusk_config[glue_params["SFTP_OUTPUT"]]
            print(sftp_secret_name)
            secret_values_sftp = precia_aws.get_secret(sftp_secret_name)
            successful = False
            for attempt in range(max_tries):
                logger.info("Intentos de conexion: %s/%s", attempt + 1, max_tries)
                try:
                    client = precia_sftp.connect_to_sftp(secret_values_sftp)
                    successful = True
                    break
                except (Exception,):
                    logger.error(create_log_msg(error_msg))
                    logger.info("Esperando para re-intentar %ss", wait_time)
                    time.sleep(wait_time)
                    continue
            if not successful:
                raise PlataformError(
                    "Se completo el maximo re-intentos de conexion al FTP"
                )
            sftp_connect = client.open_sftp()
        except PlataformError:
            logger.error(create_log_msg(error_msg))
            raise
        except (Exception,):
            logger.error(create_log_msg(error_msg))
            raise

        error_msg = "Fallo al generar archivos en el SFTP"
        try:
            logger.info("Generación de archivos en el SFTP")
            self.load_files_to_sftp(
                route_sftp,
                sftp_connect,
                self.opcdd,
                file_name_opcdd,
                info_opcdd["header"]["file_columns"],
            )
            self.load_files_to_sftp(
                route_sftp,
                sftp_connect,
                self.opcd,
                file_name_opcd,
                info_opcd["header"]["file_columns"],
            )
            self.load_files_to_sftp(
                route_sftp,
                sftp_connect,
                self.opbrd,
                file_name_opbrd,
                info_opbrd["header"]["file_columns"],
            )
            self.load_files_to_sftp(
                route_sftp,
                sftp_connect,
                self.opbr,
                file_name_opbr,
                info_opbr["header"]["file_columns"],
            )
        except (Exception,) as put_exc:
            logger.error(create_log_msg(error_msg))
            raise PlataformError(error_msg) from put_exc

        try:
            sftp_connect.close()
            logger.info("Conexión cerrada SFTP")
        except (Exception,):
            logger.error(create_log_msg("No pudo cerrar la conexión"))
        finally:
            try:
                client.close()
                logger.info("Conexión cerrada: cliente SFTP")
            except (Exception,):
                logger.error(
                    create_log_msg("No se pudo cerrar la conexión: cliente SFTP")
                )
