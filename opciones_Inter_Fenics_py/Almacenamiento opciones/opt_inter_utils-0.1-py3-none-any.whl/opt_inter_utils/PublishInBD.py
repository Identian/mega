"""
================================================================================

Nombre: PublishInBD.py
Tipo: Modulo

Autor:
	- Hector Augusto Daza Roa
Tecnologia - Precia

Ultima modificacion: 21/11/2022

Contiene la clase PublishInBD y las importaciones necesarias para que funcione

================================================================================
"""

import json
import logging
import sqlalchemy as sql

from precia_utils.precia_logger import create_log_msg
from precia_utils.precia_exceptions import PlataformError
from precia_utils.precia_aws import (
    get_params,
    get_secret,
)
from precia_utils.precia_db import connect_db_by_secret

logger = logging.getLogger()


class PublishInBD:

    """
    Agrupa las funciones necesarias para publicar la informacion generada
    por el proceso de opciones internacionales en el esquema de la base
    datos de publicacion (pub_otc)
    """

    db_connection = None

    def __init__(self, *dataframes) -> None:
        """
        Crea una instancia de PublishInBD (objeto). PublishInBD Agrupa las funciones necesarias
        para publicar la informacion de superficies generada por el proceso de opciones
        internacionales en el esquema de base datos de publicacion (pub_otc)

        Args:
            *dataframes (tuple, list, dict o 4 dataframes):
                Se esperan los dataframes en el orden mostrado y se asumen por defecto
                las tablas de BD en las que se carga la info:
                    Caso 1: tuple (len = 4): (opcd_df, opcdd_df, opbr_df, opbrd_df)
                    Caso 2: list (len = 4): [opcd_df, opcdd_df, opbr_df, opbrd_df]
                    Caso 3: 4 dataframes: opcd_df, opcdd_df, opbr_df, opbrd_df
                Se recibe cualquier cantidad de dataframes, relacionado tabla en BD con dataframe:
                    Caso 4: dict: Ejemplo:
                    {
                        opcd_df_table: opcd_df,
                        opcdd_df_table: opcdd_df,
                        opbr_df_table: opbr_df,
                        opbrd_df_table: opbrd_df,
                        ...
                    }

                Glosario:
                    opcd_df (dataframe): Contiene la informacion de publicacion de los
                    nodos de la superficie en deltas
                    opcd_df_table (str): nombre de la tabla en la que se va cargar opcd_df
                    opcdd_df (dataframe): Contiene la informacion de publicacion diaria
                    de la superficie en deltas
                    opcdd_df_table (str): nombre de la tabla en la que se va cargar opcdd_df
                    opbr_df (dataframe): Contiene la informacion de publicacion de los nodos
                    de la superficie en estrategias
                    opbr_df_table (str): nombre de la tabla en la que se va cargar opbr_df_df
                    opbrd_df (dataframe): Contiene la informacion de publicacion diaria de la
                    superficie en estrategias
                    opbrd_df_table (str): nombre de la tabla en la que se va cargar opbrd_df_df
        """
        try:
            logger.info("Creando objeto...")
            len_four = len(dataframes) == 4
            len_one = len(dataframes) == 1
            if not (len_four or len_one):
                raise_msg = "La cantidad de parametros no es correcta. "
                raise_msg += f"Se recibieron: {len(dataframes)}, Se esperaban: 1 o 4"
                raise PlataformError(raise_msg)
            if len_one:
                dataframes = dataframes[0]
            is_tuple = isinstance(dataframes, tuple)
            is_list = isinstance(dataframes, list)
            is_dict = isinstance(dataframes, dict)
            have_to_convert = is_tuple or is_list or len_four
            if have_to_convert:
                logger.info(
                    "Convirtiendo lista o tupla en diccionario y traduciendo columnas..."
                )
                self.dataframes_dict = self.convert_to_dict(dataframes)
                logger.info("Conversion en diccionario exitosa")
            elif is_dict:
                self.dataframes_dict = dataframes
            else:
                raise_msg = "El tipo de parametro recibido no es correcto. "
                raise_msg += "Se esperaba tuple, dict, list o 4 dataframes. "
                raise_msg += f"Se recibio: {type(dataframes)}"
                raise PlataformError(raise_msg)
            logger.info("Creancion de objeto exitosa")
        except (Exception,) as init_exc:
            logger.error(create_log_msg("Fallo la creacion del objeto"))
            raise PlataformError("Fallo la creacion del objeto") from init_exc

    def excute(self):
        """
        Ejecuta el proceso completo de publicacion:
            - Creacion de la conexion a la base de datos
            - Eliminacion de la informacion preexistente de la superficie en BD
            - Insercion de la informacion de la superficie en BD
            - Cierra la conexion a la BD

        """
        try:
            logger.info("Estableciendo conexion a la BD...")
            self.set_db_connection()
            logger.info("Conexion a la BD existosa")
            logger.info("Publicando dataframes...")
            self.publish_all()
            logger.info("Dataframes publicados exitosamente")
        except (Exception,) as exc_exc:
            error_msg = "Fallo el proceso de publicacion de la informacion "
            error_msg += "de superficies de opciones internacionales en BD published"
            logger.error(create_log_msg(error_msg))
            raise PlataformError(error_msg) from exc_exc
        finally:
            if self.db_connection is None:
                self.db_connection.close()

    def convert_to_dict(self, dataframes):
        """
        Convierte una tupla o lista de dataframes en un diccionario.

        Args:
            dataframes (list o tuple)

        Returns:
            dict: Diccionario que relaciona las tablas en BD (keys) con los dataframes (values)
        """
        raise_msg = "Fallo la conversion a diccionario"
        try:
            len_dfs = len(dataframes)
            if len_dfs != 4:
                raise PlataformError("Se esperaban 4 dataframes, no " + str(len_dfs))
            PARAM_LIST = [
                "PUB_DB_OPCD_TABLE",  # deltas nodos
                "PUB_DB_OPCDD_TABLE",  # deltas diaria
                "PUB_DB_OPBR_TABLE",  # estrategias nodos
                "PUB_DB_OPBRD_TABLE",  # estrategias diaria
            ]
            PARAMS = get_params(PARAM_LIST)
            dfs_dict = {}
            for pos in range(0, len_dfs):
                table = PARAMS[PARAM_LIST[pos]]
                dfs_dict[table] = dataframes[pos]
            return dfs_dict
        except (Exception,) as ctd_exc:
            logger.error(create_log_msg(raise_msg))
            raise PlataformError(raise_msg) from ctd_exc

    def translate_df(self, table):
        """
        Traduce los nombres de los columnas de los dataframes a los usados en las tablas de la
        base de datos

        Args:
            df (dataframe): dataframe a traducir

        Returns:
            dataframe: datagframe con los nombres de columnas traducidos
        """
        raise_msg = "Fallo la traduccion del dataframe"
        try:
            PARAM_LIST = ["DELTAS_TRANSLATE_DICT", "STRATEGY_TRANSLATE_DICT"]
            PARAMS = get_params(PARAM_LIST)
            DELTAS_TRANSLATE_DICT = json.loads(PARAMS["DELTAS_TRANSLATE_DICT"])
            STRATEGIES_TRANSLATE_DICT = json.loads(PARAMS["STRATEGY_TRANSLATE_DICT"])
            df_translated = self.dataframes_dict[table].rename(
                columns=DELTAS_TRANSLATE_DICT
            )
            df_translated = df_translated.rename(columns=STRATEGIES_TRANSLATE_DICT)
            self.dataframes_dict[table] = df_translated
        except (Exception,) as trans_exc:
            logger.error(create_log_msg(raise_msg))
            raise PlataformError(raise_msg) from trans_exc

    def set_db_connection(self):
        """
        Establece la conexion al esquema de base de datos de publicacion (pub_otc)
        """
        try:
            if self.db_connection is None:
                PARAM_LIST = ["CONFIG_SECRET_NAME", "PUB_DB_SECRET_KEY"]
                params = get_params(PARAM_LIST)
                config_secret_name = params["CONFIG_SECRET_NAME"]
                config_secret = get_secret(config_secret_name)
                db_secret_key = params["PUB_DB_SECRET_KEY"]
                db_secret_name = config_secret[db_secret_key]
                db_secret = get_secret(db_secret_name)
                self.db_connection = connect_db_by_secret(db_secret)
        except (Exception,) as db_exc:
            error_msg = "Fallo la creacion de la conexion al esquema de BD: pub_otc"
            logger.error(create_log_msg(error_msg))
            raise PlataformError(error_msg) from db_exc

    def publish_all(self):
        """
        Publica la informacion de todos los dataframes (con los que se creo el objeto)
        en el esquema de base de datos de publicacion. Realiza:
            - Eliminacion de informacion preexistente en BD para la superficie a publicar
            - Inserta la informacion de la superficie en BD
        """
        try:
            for table in self.dataframes_dict:
                self.translate_df(table)
                df = self.dataframes_dict[table]
                if self.validate_df(table) is False:
                    error_msg = f"El dataframe que se quiere cargar en {table} no tiene una estructura valida"
                    raise PlataformError(error_msg)
                if "days" in df:
                    self.dataframes_dict[table].set_index("days", inplace=True)
                self.delete_repeated(table)
                self.insert(table)
        except (Exception,) as pub_exc:
            error_msg = (
                "Fallo la publicacion de los dataframes con la informacion de opt inter"
            )
            logger.error(create_log_msg(error_msg))
            raise PlataformError(error_msg) from pub_exc

    def delete_repeated(self, table):
        """
        Elimina la informacion preexistente en BD para la superficie a publicar. Identifca el dataframe
        a partir de la tabla (indexando el diccionario de dataframes del objeto). Identifica la
        informacion a eliminar a partir de los campos 'currency' y 'valuation_date' del dataframe

        Args:
            table (str): tabla de la BD en la que se va a eliminar informacion
        """
        raise_msg = f"Fallo la eliminacion de la informacion preexistente de la superficie en {table}"
        try:
            logger.info("Construyendo delete query...")
            df = self.dataframes_dict[table].reset_index()
            currency = df.at[0, "currency"]
            valuation_date_str = df.at[0, "valuation_date"]
            if not isinstance(valuation_date_str, str):
                date_type = type(valuation_date_str)
                raise PlataformError(
                    "Se esperaba valuation_date como tipo string, no como "
                    + str(date_type)
                )
            delete_info = f"currency: {currency} y valuation_date: {valuation_date_str}"
            delete_info += f" en {table}"
            delete_query = sql.sql.text(
                f"""DELETE FROM {table} WHERE currency = :CURRENCY 
                AND valuation_date = :VALUATION_DATE"""
            )
            logger.debug("Delete query: %s", delete_query)
            query_params = {
                "VALUATION_DATE": valuation_date_str,
                "CURRENCY": currency,
            }
            logger.info("delete query construida")
            logger.info("Eliminando informacion para %s", delete_info)
            self.db_connection.execute(delete_query, query_params)
            logger.info("Delete query ejecutada")
        except (Exception,) as del_exc:
            logger.error(create_log_msg(raise_msg))
            raise PlataformError(raise_msg) from del_exc

    def insert(self, table):
        """
        Inserta la informacion de la superficie en el esquema de base de datos de publish (pub_otc).

        Args:
            table (str): tabla en la que se va a publicar el dataframe. Se identifca el dataframe
            a partir de la tabla (indexando el diccionario de dataframes del objeto)
        """
        try:
            logger.info("Insertando dataframe en %s ...", table)
            self.dataframes_dict[table].to_sql(
                table, con=self.db_connection, if_exists="append"
            )
            logger.info("Inserción de dataframe exitosa")
        except (Exception,) as ins_exc:
            error_msg = "Fallo la insercion del dataframe en {table}"
            logger.error(create_log_msg(error_msg))
            raise PlataformError(error_msg) from ins_exc

    def validate_df(self, table):
        try:
            is_valid = True
            df = self.dataframes_dict[table]
            if df.isnull().values.any() == True:
                logger.info(
                    "El dataframe que se quiere cargar en %s tiene valores nulos", table
                )
                is_valid = False
            elif df.empty:
                logger.info("El dataframe que se quiere cargar en %s esta vacio", table)
                is_valid = False
            return is_valid
        except (Exception,) as val_exc:
            error_msg = (
                f"Fallo la validacion del dataframe que se quiere cargar en {table}"
            )
            logger.error(create_log_msg(error_msg))
            raise PlataformError(error_msg) from val_exc
