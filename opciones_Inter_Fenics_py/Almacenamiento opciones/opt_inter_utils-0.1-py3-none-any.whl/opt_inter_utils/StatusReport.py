""" 
================================================================================

Nombre: StatusReport.py
Tipo: Modulo

Autor:
	- Hector Augusto Daza Roa
Tecnologia - Precia

Ultima modificacion: 22/11/2022

Contiene la clase StatusReport y las importaciones necesarias para que funcione 

================================================================================
 """

import logging

import sqlalchemy as sql
import pandas as pd

from precia_utils.precia_logger import create_log_msg
from precia_utils.precia_exceptions import PlataformError
from precia_utils.precia_aws import (
    get_params,
    get_secret,
)
from precia_utils.precia_db import connect_db_by_secret

logger = logging.getLogger()
PARAM_LIST = ["CONFIG_SECRET_NAME", "UTILS_DB_SECRET_KEY", "UTILS_DB_STATUS_TABLE"]
VALID_STATUS = ["Ejecutando", "Exitoso", "Fallido"]


class StatusReport:

    """
    Agrupa las funciones para actualizar y consultar el estatus de ejecucion
    del procesamiento de los insumos en opciones internacionales
    """

    db_connection = None

    def set_db_connection(self):
        """
        Establece la conexion al esquema de base de datos de precia_utils
        """
        try:
            if self.db_connection is None:
                logger.info("Obteniendo secreto de base de datos...")
                params = get_params(PARAM_LIST)
                config_secret_name = params["CONFIG_SECRET_NAME"]
                config_secret = get_secret(config_secret_name)
                db_secret_key = params["UTILS_DB_SECRET_KEY"]
                db_secret_name = config_secret[db_secret_key]
                db_secret = get_secret(db_secret_name)
                logger.info("Secreto de base datos obtenido")
                self.db_connection = connect_db_by_secret(db_secret)
        except (Exception,) as db_exc:
            error_msg = (
                "Fallo la creacion de la conexion al esquema de BD: precia_utils"
            )
            logger.error(create_log_msg(error_msg))
            raise PlataformError(error_msg) from db_exc

    def update_status(
        self,
        status,
        schedule_name,
        valuation_date,
        byproduct_id="opt_inter",
        schedule_type="ETL",
    ):
        """
        Actualiza la tabla DB_STATUS_TABLE para informar al proceso sobre el estado del
        procesamiento del insumo indicado para la fecha indicada
        Args:
            status (str): Estado del procesamiento del insumo. Estados posibles
                'Ejecutando': Cuando se lanza el ETL
                'Exitoso': Cuando concluya exitosamente
                'Fallido': Cuando el archivo no sea procesable
            valuation_date (str): Fecha de valoracion del insumo
            schedule_name (str): Nombre del insumo
            byproduct_id (str, opcional):
                Tipo de derivado (fwd_inter,opt_inter,etc). Por defecto es opt_inter
            schedule_type (str, opcional): Componente que proceso el insumo. Por defecto es ETL
        """
        error_msg = (
            "No fue posible actualizar el estado del procesamiento del insumo en DB"
        )
        try:
            if status not in VALID_STATUS:
                raise PlataformError("El status a reportar no es valido")
            self.set_db_connection()
            db_status_table = get_params(PARAM_LIST)["UTILS_DB_STATUS_TABLE"]
            status_register = {
                "id_byproduct": byproduct_id,
                "name_schedule": schedule_name,
                "type_schedule": schedule_type,
                "state_schedule": status,
                "details_schedule": valuation_date,
            }
            logger.info(
                "Actualizando el status de el/la %s a: %s", schedule_type, status
            )
            status_df = pd.DataFrame([status_register])
            status_df.to_sql(
                name=db_status_table,
                con=self.db_connection,
                if_exists="append",
                index=False,
            )
            logger.info("Status actualizado en base de datos.")
        except (Exception,) as sts_exc:
            error_msg = f"Fallo la actualizacion del estado de procesamiento del insumo {schedule_name} ({valuation_date})"
            logger.error(create_log_msg(error_msg))
            raise PlataformError(error_msg) from sts_exc

    def get_status(
        self,
        valuation_date,
        schedule_name,
        byproduct_id="opt_inter",
        schedule_type="ETL",
    ):
        """
        Obtiene el estado del procesamiento del insumo indicado para la fecha indicada
        Args:
            valuation_date (str): Fecha de valoracion del insumo
            schedule_name (str): Nombre del insumo
            byproduct_id (str, opcional):
                Tipo de derivado (fwd_inter,opt_inter,etc). Por defecto es opt_inter
            schedule_type (str, opcional): Componente que proceso el insumo. Por defecto es ETL
        Return:
            str: Ultimo estado reportado del procesamiento del insumo.
                Estados posibles:
                    'Ejecutando': Cuando se lanza el ETL
                    'Exitoso': Cuando concluya exitosamente
                    'Fallido': Cuando el archivo no sea procesable
        """
        try:
            self.set_db_connection()
            db_status_table = get_params(PARAM_LIST)["UTILS_DB_STATUS_TABLE"]
            select_query = sql.sql.text(
                f"""SELECT state_schedule FROM {db_status_table} WHERE id_byproduct = :id_byproduct
                AND details_schedule = :details_schedule AND type_schedule = :type_schedule
                AND name_schedule = :name_schedule  ORDER BY last_update LIMIT 1
                """
            )
            query_params = {
                "id_byproduct": byproduct_id,
                "name_schedule": schedule_name,
                "type_schedule": schedule_type,
                "details_schedule": valuation_date,
            }
            status_info = f"Consultando status para {schedule_type} {schedule_name}"
            status_info += (
                f" ({byproduct_id}), fecha de valoracion: {valuation_date} ..."
            )
            logger.info(status_info)
            result = self.db_connection.execute(select_query, query_params).fetchall()[
                0
            ][0]
            logger.info("Ultimo estado reportado en BD: %s", result)
            return result
        except (Exception,) as sts_exc:
            error_msg = f"Fallo la consulta sobre el estado de procesamienrto del insumo {schedule_name} ({valuation_date})"
            logger.error(create_log_msg(error_msg))
            raise PlataformError(error_msg) from sts_exc

    def close_connection(self):
        try:
            if self.db_connection is not None:
                self.db_connection.close()
        except (Exception,) as db_exc:
            error_msg = "Fallo el cierre de conexion al esquema de BD: precia_utils"
            logger.error(create_log_msg(error_msg))
            raise PlataformError(error_msg) from db_exc
