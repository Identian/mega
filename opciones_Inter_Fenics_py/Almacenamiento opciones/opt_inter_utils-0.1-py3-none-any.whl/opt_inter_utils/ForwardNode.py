"""
=============================================================

Nombre: ForwardNode.py
Tipo: Class

Autor:
    - Ruben Antonio Parra Medrano
Tecnología - Precia

Ultima modificación: 22/11/2022

Reune las funcionalidades para el generar logs con formato en
Precia, los formatos son los presentados en las variables
ERROR_MSG_LOG_FORMAT y PRECIA_LOG_FORMAT

=============================================================
"""
import logging
import json

import pandas as pd
import sqlalchemy as sa

from precia_utils.precia_logger import create_log_msg
from precia_utils.precia_exceptions import DependencyError, PlataformError
from precia_utils.precia_aws import (
    get_params,
    get_secret,
)
from precia_utils.precia_db import connect_db_by_secret


logger = logging.getLogger()

DATE_FORMAT = "%Y-%m-%d"


class ForwardNode:
    """
    Clase que abstrae nodos forward internacional
    """

    def __init__(self, instrument: str, valuation_date: str, config_dict: dict) -> None:
        self.instrument = instrument
        self.valuation_date = valuation_date
        self.config_secret = config_dict

    def get_maturity_date(self) -> pd.DataFrame:
        """
        Obtiene de la base de datos pub_otc los dias para la fecha de valoracion definida
        en el constructor para calcular la fecha de maduracion, entre los datos consultados
        se encuentra el tenor

        Raises:
            PlataformError: Cuando no es posible obtener la fecha de maduracion de intrumento
            forward internacional

        Returns:
            pd.DataFrame: Dataframe padnas con columna tenor, valuation_date, days y maturity_datex
        """
        error_msg = "No fue posible validar y/o obtener la(s) dependencia(s) de informacion desde"
        error_msg += " forward internacional para opciones internacionales "
        error_msg += f"{self.instrument} para  {self.valuation_date}"
        try:
            FWD_DEPENDENT = self.config_secret["dependence/fwd_to_opt"]
            fwd_dependent_dict = json.loads(FWD_DEPENDENT)
            if self.instrument not in list(fwd_dependent_dict):
                return pd.DataFrame()
            db_connection = connect_to_db_pub(self.config_secret)
            fwd_table = get_params(["PUB_DB_FWD_INTER_TABLE"])["PUB_DB_FWD_INTER_TABLE"]
            tenors = (get_params(["TENORS"])["TENORS"]).split(",")
            columns = ["tenor", "days", "valuation_date", "maturity_date", "instrument"]
            all_fwd_node_df = pd.DataFrame(index=tenors, columns=columns)
            for fwd_intrument in fwd_dependent_dict[self.instrument]:
                days_query = "SELECT tenor_fwd AS tenor, days_fwd as days from "
                days_query += (
                    f"{fwd_table} WHERE valuation_date='{self.valuation_date}' "
                )
                days_query += f"AND instrument_fwd='{fwd_intrument}'"
                logger.debug("query para obtener dias: %s", days_query)
                fwd_node_df = pd.read_sql(days_query, con=db_connection)
                if fwd_node_df.empty:
                    logger.warning(
                        "Para FWD INTER %s no hay datos para %s",
                        self.instrument,
                        self.valuation_date,
                    )
                    raise_msg = (
                        "Se requiere que el proceso de forward internacional para "
                    )
                    raise_msg += f"{self.instrument} se ejecute primero para continuar este proceso"
                    raise DependencyError(raise_msg)
                fwd_node_df["valuation_date"] = pd.to_datetime(
                    self.valuation_date, format=DATE_FORMAT
                )
                fwd_node_df["instrument"] = fwd_intrument
                fwd_node_df["maturity_date"] = fwd_node_df[
                    "valuation_date"
                ] + pd.to_timedelta(fwd_node_df["days"], unit="D")
                fwd_node_df["valuation_date"] = fwd_node_df[
                    "valuation_date"
                ].dt.strftime(DATE_FORMAT)
                fwd_node_df["maturity_date"] = fwd_node_df["maturity_date"].dt.strftime(
                    DATE_FORMAT
                )
                logger.debug("days_df: %s\n", fwd_node_df.to_string())
                fwd_node_df.set_index("tenor", drop=False, inplace=True)
                all_fwd_node_df.update(fwd_node_df)
            db_connection.close()
            all_fwd_node_df.reset_index(inplace=True, drop=True)
            all_fwd_node_df.dropna(inplace=True)
            all_fwd_node_df["days"] = all_fwd_node_df["days"].astype("int")
            return all_fwd_node_df
        except DependencyError:
            logger.error(create_log_msg(error_msg))
            raise
        except (Exception,) as day_exc:
            logger.error(create_log_msg(error_msg))
            raise PlataformError(error_msg) from day_exc
        finally:
            try:
                db_connection.close()
            except (Exception,):
                pass


def connect_to_db_pub(config_opt_k: dict) -> sa.engine:
    """
    Gestiona conexion a la base de datos pub_otc

    Args:
        config_opt_k (dict): diccionario de configuracion de optimus K

    Raises:
        PlataformError: Cuando no es posible conectarse a la base de datos

    Returns:
        sa.engine: Conexion a la base de datos pub_otc
    """
    try:
        params = get_params(["PUB_DB_SECRET_KEY"])
        db_secret_key = params["PUB_DB_SECRET_KEY"]
        db_secret_name = config_opt_k[db_secret_key]
        db_secret = get_secret(db_secret_name)
        db_connection = connect_db_by_secret(db_secret)
        return db_connection
    except (Exception,) as pub_exc:
        error_msg = "No fue posible conectarse a pub_otc para obtener los nodos fwd"
        logger.error(create_log_msg(error_msg))
        raise PlataformError(error_msg) from pub_exc
