from email.message import EmailMessage
from io import BytesIO
import logging
import mimetypes
import smtplib

import pandas as pd

from precia_utils.precia_logger import create_log_msg
from precia_utils.precia_exceptions import PlataformError
from precia_utils import precia_aws

logger = logging.getLogger()


class ReportEmail:
    """
    Clase que representa los correos que reportan las variaciones del día

    Attributes:
    ----------
    subject: str
        Asunto del correo
    body: str
        Cuerpo del correo
    data_file: dict
        Información para el archivo adjunto del correo

    Methods:
    --------
    connect_to_smtp(secret)
        Conecta al servicio SMTP de precia

    create_mail_base
        Crea el objeto EmailMessage con los datos básicos para enviar el correo

    attach_file_to_message(message, df_file)
        Adjunta el archivo al mensaje para enviar por el correo

    send_email(smtp_connection, message)
        Envia el objeto EmailMessage construido a los destinatarios establecidos

    run()
        Orquesta los métodos de la clase

    """

    def __init__(self, subject, body, data_file) -> None:
        self.subject = subject
        self.body = body
        self.data_file = data_file
        self.run()

    def connect_to_smtp(self, secret):
        """Conecta al servicio SMTP de precia con las credenciales que vienen en secret
        Parameters:
        -----------
        secret: dict, required
            Contiene las credenciales de conexión al servicio SMTP

        Returns:
        --------
        Object SMTP
            Contiene la conexión al servicio SMTP
        """
        error_msg = "No fue posible conectarse al relay de correos de Precia"
        try:
            logger.info("Conectandose al SMTP ...")
            connection = smtplib.SMTP(host=secret["server"], port=secret["port"])
            connection.starttls()
            connection.login(secret["user"], secret["password"])
            logger.info("Conexión exitosa.")
            return connection
        except (Exception,) as url_exc:
            logger.error(create_log_msg(error_msg))
            raise PlataformError(error_msg) from url_exc

    def create_mail_base(self, mail_from, mails_to):
        """Crea el objeto EmailMessage que contiene todos los datos del email a enviar
        Parameters:
        -------
        mail_from: str, required
            Dirección de correo que envía el mensaje
        mails_to: str, required
            Direcciones de correo destinatario

        Returns:
        Object EmailMessage
            Contiene el mensaje base (objeto) del correo

        Raises:
        ------
        PlataformError
            Si no se pudo crear el objeto EmailMessage

        """
        error_msg = "No se crear el correo para el SMTP"
        try:
            logger.info('Creando objeto "EmailMessage()" con los datos básicos...')
            message = EmailMessage()
            message["Subject"] = self.subject
            message["From"] = mail_from
            message["To"] = mails_to
            message.set_content(self.body)
            logger.info("Mensaje creado correctamente")
            return message
        except (Exception,) as mail_exp:
            logger.error(create_log_msg(error_msg))
            raise PlataformError(error_msg) from mail_exp

    def attach_file_to_message(self, message):
        """Adjunta el archivo al mensaje(object EmailMessage) para enviar por el correo
        Parameters:
        -----------
        message: Object EmailMessage, required
            Contiene el mensaje básico del correo

        Returns:
        Object EmailMessage
            Tiene los archivos adjuntos junto a la data básica el mensaje

        Raises:
        -------
        PlataformError
            Si no pudo adjuntar los archivos al mensaje
        """

        logger.info("Comienza adjuntar los archivos...")
        for file_name, file_data in self.data_file.items():
            df_file_data = pd.DataFrame(file_data)
            try:
                buf = BytesIO()
                df_file_data.to_csv(buf, index=False)
                buf.seek(0)
                binary_data = buf.read()
                maintype, _, subtype = (
                    mimetypes.guess_type(file_name)[0] or "application/octet-stream"
                ).partition("/")
                message.add_attachment(
                    binary_data, maintype=maintype, subtype=subtype, filename=file_name
                )
            except (Exception,) as att_exc:
                logger.error(
                    create_log_msg("Fallo en adjuntar los archivos en el mensaje")
                )
                raise PlataformError(
                    "Hubo un error al adjuntar los archivos"
                ) from att_exc

        logger.info("Termino de adjuntar los archivos en el mensaje correctamente")
        return message

    def send_email(self, smtp_connection, message):
        """Envia el objeto EmailMessage construido a los destinatarios establecidos
        Parameters:
        -----------
        smtp_connection: Object SMTP, required
            Contiene la conexión con el servicio SMTP
        message: Object EmailMessage
            Mensaje para enviar por correo

        Raises:
        -------
        PlataformError
            Si no pudo enviar el correo
            Si no pudo cerrar la conexión SMTP
        """
        logger.info("Enviando Mensaje...")
        try:
            smtp_connection.send_message(message)
        except (Exception,) as conn_exc:
            logger.error(create_log_msg("No se pudo enviar el mensaje"))
            raise PlataformError("No se pudo enviar el mensaje") from conn_exc
        finally:
            try:
                smtp_connection.quit()
                logger.info("Conexión cerrada: SMTP")
            except (Exception,) as quit_exc:
                logger.error(create_log_msg("No se pudo cerra la conexión"))
                raise PlataformError(
                    "Hubo un error cerrando la conexión SMTP"
                ) from quit_exc

    def run(self):
        """Orquesta los métodos de la clase
        Trae los secretos necesarios para la clase
        """
        try:
            glue_params = precia_aws.get_params(
                ["SMTP_SECRET_KEY", "CONFIG_SECRET_NAME"]
            )
            secrets_optimus_k = precia_aws.get_secret(glue_params["CONFIG_SECRET_NAME"])
            smtp_secret_name = secrets_optimus_k[glue_params["SMTP_SECRET_KEY"]]
            secret_values_smtp = precia_aws.get_secret(smtp_secret_name)
            mails_to = secrets_optimus_k["validator/mail_to"]
            mail_from = secrets_optimus_k["validator/mail_from"]
        except (Exception,) as config_exc:
            logger.error(create_log_msg("Fallo la obtención del secreto"))
            raise PlataformError("No se pudo obtener los secretos") from config_exc

        try:
            smtp_connection = self.connect_to_smtp(secret_values_smtp)

            message = self.create_mail_base(mail_from, mails_to)

            if len(self.data_file) == 0:
                self.send_email(smtp_connection, message)
            else:
                message_with_file = self.attach_file_to_message(message)
                self.send_email(smtp_connection, message_with_file)
        except (Exception,) as send_exc:
            logger.error(create_log_msg("No se pudo enviar el correo/reporte"))
            raise PlataformError("No se pudo enviar el correo/reporte") from send_exc
