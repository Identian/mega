import boto3
import json
import logging

import pandas as pd
from sqlalchemy import Column, String, Float, Date
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

from precia_utils.precia_exceptions import PlataformError
from precia_utils.precia_logger import create_log_msg
from precia_utils.precia_aws import get_secret, get_params
from precia_utils.precia_db import connect_db_by_secret

Base = declarative_base()
logger = logging.getLogger()

try:
    PARAMS_KEYS = [
        "CONFIG_SECRET_NAME",
        "BUCKET_NAME_KEY",
        "UTILS_DB_SECRET_KEY",
        "SRC_DB_SECRET_KEY",
        "PRC_DB_SECRET_KEY",
        "S3_FILE_PATH",
        "SRC_DB_INPUT_TABLE",
        "UTILS_DB_API_DICT_TABLE",
        "PRC_DB_OPT_ID_PRECIA_TABLE",
        "BY_PRODUCT",
    ]
    GLUE_PARAMS = get_params(PARAMS_KEYS)
    CONFIG_SECRET = get_secret(GLUE_PARAMS["CONFIG_SECRET_NAME"])
    BUCKET_NAME = CONFIG_SECRET[GLUE_PARAMS["BUCKET_NAME_KEY"]]
    UTILS_DB_SECRET_NAME = CONFIG_SECRET[GLUE_PARAMS["UTILS_DB_SECRET_KEY"]]
    UTILS_DB_SECRET = get_secret(UTILS_DB_SECRET_NAME)
    SRC_DB_SECRET_NAME = CONFIG_SECRET[GLUE_PARAMS["SRC_DB_SECRET_KEY"]]
    SRC_DB_SECRET = get_secret(SRC_DB_SECRET_NAME)
    PRC_DB_SECRET_NAME = CONFIG_SECRET[GLUE_PARAMS["PRC_DB_SECRET_KEY"]]
    PRC_DB_SECRET = get_secret(PRC_DB_SECRET_NAME)
    S3_FILE_PATH = GLUE_PARAMS["S3_FILE_PATH"]
    SRC_DB_INPUT_TABLE = GLUE_PARAMS["SRC_DB_INPUT_TABLE"]
    UTILS_DB_API_DICT_TABLE = GLUE_PARAMS["UTILS_DB_API_DICT_TABLE"]
    PRC_DB_OPT_ID_PRECIA_TABLE = GLUE_PARAMS["PRC_DB_OPT_ID_PRECIA_TABLE"]
    BY_PRODUCT = GLUE_PARAMS["BY_PRODUCT"]
except (Exception,) as sec_exc:
    init_error_msg = "Fallo la carga de configuracion (parametros y secretos)"
    logger.error(create_log_msg(init_error_msg))
    raise PlataformError(init_error_msg) from sec_exc


class RefinitivETL(object):
    def __init__(self, valuation_date: str) -> None:
        self.key = S3_FILE_PATH
        self.valuation_date = valuation_date
        self.precia_sources = connect_db_by_secret(SRC_DB_SECRET)
        self.precia_process = connect_db_by_secret(PRC_DB_SECRET)
        self.precia_utils = connect_db_by_secret(UTILS_DB_SECRET)
        Session_sources = sessionmaker(bind=self.precia_sources)
        self.session_src = Session_sources()
        Session_process = sessionmaker(bind=self.precia_process)
        self.session_prc = Session_process()
        Session_utils = sessionmaker(bind=self.precia_utils)
        self.session_utils = Session_utils()

    def get_files_refinitiv(self):
        try:
            logger.info("Obteniendo archivo insumo desde el bucket S3: %s", BUCKET_NAME)
            s3_client = boto3.client("s3")
            body_json = None
            response = s3_client.get_object(Bucket=BUCKET_NAME, Key=self.key)
            body = response["Body"].read().decode("utf-8")
            body_json = json.loads(body)
            refinitiv_resource = pd.io.json.json_normalize(body_json["value"])
            refinitiv_resource.columns = refinitiv_resource.columns.map(
                lambda x: x.split(".")[-1]
            )
            return refinitiv_resource
        except (Exception,) as file_exc:
            error_msg = f"Fallo en la obtencion del archivo {self.key} desde el bucket {BUCKET_NAME}"
            logger.error(create_log_msg(error_msg))
            raise PlataformError(error_msg) from file_exc

    def validate_input_file_data(self, currency, file_data):
        """
        Valida el contenido del archivo antes de ser procesado conforme a
        los requerimientos de I+D

        Args:
            currency (str): _description_
            file_data (pd.DataFrame): Dataframe con los datos brutos del archivo

        Raises:
            PlataformError: Cuando no es posible validar el contenido del archivo

        Returns:
            bool: True si el archivo es valido, False el caso contrario
        """
        try:
            input_data = file_data.copy()
            fwd_dependent = CONFIG_SECRET["dependence/fwd_to_opt"]
            if currency in fwd_dependent:
                if "Maturity Date" in input_data:
                    input_data.drop(columns=["Maturity Date"], inplace=True)
                if "maturity_date" in input_data:
                    input_data.drop(columns=["maturity_date"], inplace=True)
            if input_data.isnull().values.any():
                return False
            return True
        except (Exception,) as val_exc:
            error_msg = "No fue posible validar los datos del archivo insumo"
            logger.error(create_log_msg(error_msg))
            raise PlataformError(error_msg) from val_exc

    def get_opts_inter(self):
        error_msg = "Fallo la obtencion de id-precia desde prc-otc"
        try:
            return pd.read_sql(
                self.session_prc.query(OptsLocal)
                .filter(OptsLocal.id_byproduct == BY_PRODUCT)
                .statement,
                self.session_prc.bind,
            )
        except (Exception,) as save_exc:
            logger.error(create_log_msg(error_msg))
            raise PlataformError(error_msg) from save_exc

    def get_dictionary(self):
        error_msg = (
            "Fallo la obtencion del diccionario de homologacion desde precia-utils"
        )
        try:
            ids = pd.read_sql(
                self.session_utils.query(ApiDictionary)
                .filter(ApiDictionary.alias_type == "id")
                .filter(ApiDictionary.id_byproduct == BY_PRODUCT)
                .statement,
                self.session_utils.bind,
            )
            fields = pd.read_sql(
                self.session_utils.query(
                    ApiDictionary.precia_alias, ApiDictionary.supplier_alias
                )
                .filter(ApiDictionary.alias_type == "field")
                .filter(ApiDictionary.id_byproduct == BY_PRODUCT)
                .statement,
                self.session_utils.bind,
            )
            return ids, fields
        except (Exception,) as save_exc:
            logger.error(create_log_msg(error_msg))
            raise PlataformError(error_msg) from save_exc

    def save_opt_inter(self, opts_inter) -> None:
        error_msg = f"Fallo al actualizar base de datos: {SRC_DB_INPUT_TABLE}"
        try:
            logger.info("Guardando opciones de Refinitiv en base de datos")
            opts_inter.to_sql(
                SRC_DB_INPUT_TABLE,
                self.precia_sources,
                chunksize=125,
                method="multi",
                if_exists="append",
                index=False,
            )
        except (Exception,) as save_exc:
            logger.error(create_log_msg(error_msg))
            raise PlataformError(error_msg) from save_exc

    def delete_opt_inter(self, currency) -> None:
        error_msg = (
            f"No se pudo eliminar datos pasados en {SRC_DB_INPUT_TABLE}"
        )
        try:
            logger.info("Eliminando registros en la base de datos")
            self.session_src.query(OtcOptionsInter).filter(
                OtcOptionsInter.valuation_date == self.valuation_date
            ).filter(OtcOptionsInter.currency == currency).delete()
            self.session_src.commit()
        except (Exception,) as save_exc:
            logger.error(create_log_msg(error_msg))
            raise PlataformError(error_msg) from save_exc

    def run(self):
        error_msg = "Fallo el procesamiento del archivo insumo de opciones internacionales de Refinitiv"
        try:
            logger.info("Inicia el procesamiento de las opciones de Refinitiv")
            ids, fields = self.get_dictionary()
            name_fields = fields.set_index("supplier_alias").T.to_dict()
            opc_dictionary = ids.rename(
                columns={"supplier_alias": "Identifier", "precia_alias": "id_precia"}
            )
            opts_inter = self.get_opts_inter()
            refinitiv_opts = self.get_files_refinitiv()
            dic_file = opc_dictionary.merge(refinitiv_opts, on="Identifier")
            dic_opts_inter = dic_file.merge(opts_inter, on="id_precia")
            inter_options = dic_opts_inter[
                [
                    "id_precia",
                    "name_input",
                    "strategy",
                    "General Value4 Text",
                    "Close Bid Price",
                    "Close Ask Price",
                    "Maturity Date",
                ]
            ]
            refinitiv_options = inter_options.rename(
                columns={
                    "Close Bid Price": name_fields.get("Close Bid Price")[
                        "precia_alias"
                    ],
                    "Close Ask Price": name_fields.get("Close Ask Price")[
                        "precia_alias"
                    ],
                    "General Value4 Text": name_fields.get("General Value4 Text")[
                        "precia_alias"
                    ],
                    "Maturity Date": name_fields.get("Maturity Date")["precia_alias"],
                    "name_input": "currency",
                }
            )
            currency = refinitiv_options.loc[0]["currency"]
            if not self.validate_input_file_data(currency, refinitiv_opts):
                raise_msg = (
                    f"El archivo insumo '{self.key}' tiene Nan o valores invalidos"
                )
                raise PlataformError(raise_msg)
            refinitiv_options.insert(
                loc=0, column="valuation_date", value=self.valuation_date
            )
            refinitiv_options["tenor"] = refinitiv_options["tenor"].str[:2]
            self.delete_opt_inter(currency=refinitiv_options.loc[0]['currency'])
            self.save_opt_inter(opts_inter=refinitiv_options)
            logger.info(
                "Finaliza el procesamiento de las opciones de Refinitiv exitosamente"
            )
            logger.debug(
                "Datos del archivo insumo limpios: \n %s",
                refinitiv_options.to_string(),
            )
            return currency, refinitiv_options
        except PlataformError:
            logger.error(create_log_msg(error_msg))
            raise
        except (Exception,) as run_exc:
            logger.error(create_log_msg(error_msg))
            raise PlataformError(error_msg) from run_exc
        finally:
            try:
                self.session_prc.close()
            except (Exception,):
                pass
            try:
                self.session_utils.close()
            except (Exception,):
                pass
            try:
                self.session_src.close()
            except (Exception,):
                pass


class OptsLocal(Base):
    __tablename__ = PRC_DB_OPT_ID_PRECIA_TABLE
    id_byproduct = Column(String)
    id_precia = Column(String, primary_key=True)
    strategy = Column(String)
    tenor = Column(String)


class ApiDictionary(Base):
    __tablename__ = UTILS_DB_API_DICT_TABLE
    id_byproduct = Column(String, primary_key=True)
    name_input = Column(String, primary_key=True)
    precia_alias = Column(String, primary_key=True)
    supplier_alias = Column(String, primary_key=True)
    id_supplier = Column(String, primary_key=True)
    alias_type = Column(String)


class OtcOptionsInter(Base):
    __tablename__ = SRC_DB_INPUT_TABLE
    valuation_date = Column(Date, primary_key=True)
    id_precia = Column(String, primary_key=True)
    currency = Column(String)
    strategy = Column(String, primary_key=True)
    tenor = Column(String, primary_key=True)
    bid = Column(Float)
    ask = Column(Float)
    maturity_date = Column(Date)
