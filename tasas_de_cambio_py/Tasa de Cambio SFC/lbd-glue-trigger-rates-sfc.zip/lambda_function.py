import json
import logging
import os
from datetime import datetime as dt
from datetime import timezone, timedelta
import boto3

from precia_logger import setup_logging, create_log_msg
from precia_exceptions import PlataformError

logger = setup_logging(logging.INFO)

init_failed = False

try:
    raise_msg = "Fallo la incializacion de la lambda"
    logger.info('Inicializando lambda...')
    GLUE_JOB_NAME = os.environ["JOB_NAME"]
    logger.info('Termino Inicializacion de lambda...')
except (Exception,):
    init_failed = True
    logger.error(raise_msg)

def extract_date(event: dict) -> str:
    """
    Extrae la fecha de valoracion del event necesaria como insumo para el glue

    Parameters:
        event (dict): event que recibe la funcion lambda

    Returns:
        str: la fecha de valoracion contenida en el event
    """
    raise_msg = 'Fallo la extraccion de la fecha'
    try:
        valuation_date_str = event["valuation_date"]
        if valuation_date_str == "TODAY":
            colombia_offset = timedelta(hours=-5)
            colombia_timezone = timezone(colombia_offset)
            today_date = dt.now(colombia_timezone).date()
            valuation_date_str = today_date.strftime("%Y-%m-%d")
        return valuation_date_str
    except KeyError as key_exc:
        logger.error(create_log_msg("El event no tiene la estructura esperada"))
        raise PlataformError(raise_msg) from key_exc
    except (Exception,) as ext_exc:
        logger.error(create_log_msg("Fallo la extracion de la fecha del event"))
        raise PlataformError(raise_msg) from ext_exc


def run_glue_job(name_glue_job, valuation_date):
    """Ejecuta el correspondiente el glue job de
    get calendars

    Parameters:
    -----------
    name_glue_job: str
        Nombre del Glue Job a ejecutar

    valuation_date: str
        Fecha del proceso

    """
    raise_msg = "Fallo el lanzamiento del job de Glue"
    try:
        glue = boto3.client("glue")
        arguments = {"--VALUATION_DATE": valuation_date}
        logger.info("Comienza la ejecucion del Glue")
        response = glue.start_job_run(JobName=name_glue_job, Arguments=arguments)
        job_run_id = response["JobRunId"]
        logger.info("El Glue Job se lanzo bajo el id: %s.", job_run_id)
    except (Exception,) as rgj_exc:
        logger.error(create_log_msg(raise_msg))
        raise PlataformError(raise_msg) from rgj_exc

def lambda_handler(event, context):
    """
    Funcion principal (main)

    Args:
        event: Evento que descadena la ejecucion de la lambda
        context: Informacion sobre la ejecucion de la lambda

    Returns:
        json: Respuesta de lambda luego de terminar su ejecucion
    """
    try:
        if init_failed:
            raise PlataformError('No se completo la inicializacion')
        logger.info("Event:\n%s",json.dumps(event))
        valuation_date = extract_date(event=event)
        logger.info("Glue Job a ejecutar: %s",GLUE_JOB_NAME)
        run_glue_job(GLUE_JOB_NAME, valuation_date)
        return {
            "statusCode": 200,
            "body": json.dumps("Finalizo exitosamente la ejecucion de la lambda"),
        }
    except (Exception,):
        logger.error(create_log_msg("Ejecucion de lambda interrumpida"))
        return {
            "statusCode": 500,
            "body": json.dumps("Fallo la ejecucion de la lambda"),
        }
