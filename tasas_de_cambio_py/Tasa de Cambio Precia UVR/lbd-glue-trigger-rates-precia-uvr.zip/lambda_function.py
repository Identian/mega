import json
import logging
import os
import boto3

from precia_logger import setup_logging, create_log_msg
from precia_exceptions import PlataformError

logger = setup_logging(logging.INFO)

init_failed = False

try:
    raise_msg = "Fallo la incializacion de la lambda"
    logger.info('Inicializando lambda...')
    GLUE_JOB_NAME = os.environ["JOB_NAME"]
    logger.info('Termino Inicializacion de lambda...')
except (Exception,):
    init_failed = True
    logger.error(raise_msg)

def run_glue_job(name_glue_job, is_auto):
    """Ejecuta el correspondiente el glue job de
    get calendars

    Parameters:
    -----------
    name_glue_job: str
        Nombre del Glue Job a ejecutar

    valuation_date: str
        Fecha del proceso

    """
    try:
        glue = boto3.client("glue")
        arguments = {"--IS_AUTO": is_auto}
        logger.info("Comienza la ejecucion del Glue")
        response = glue.start_job_run(JobName=name_glue_job, Arguments=arguments)
        job_run_id = response["JobRunId"]
        logger.info("El Glue Job se lanzo bajo el id: %s.", job_run_id)
    except (Exception,) as rgj_exc:
        logger.error(create_log_msg(raise_msg))
        raise PlataformError(raise_msg) from rgj_exc

def lambda_handler(event, context):
    """
    Funcion principal (main)

    Args:
        event: Evento que descadena la ejecucion de la lambda
        context: Informacion sobre la ejecucion de la lambda

    Returns:
        json: Respuesta de lambda luego de terminar su ejecucion
    """
    try:
        if init_failed:
            raise PlataformError('No se completo la inicializacion')
        logger.info("Event:\n%s",json.dumps(event))
        is_auto = 'False'
        if 'IS_AUTO' in event:
            is_auto = event['IS_AUTO'] == 'True'
        logger.info("Glue Job a ejecutar: %s",GLUE_JOB_NAME)
        run_glue_job(GLUE_JOB_NAME, is_auto)
        return {
            "statusCode": 200,
            "body": json.dumps("Finalizo exitosamente la ejecucion de la lambda"),
        }
    except (Exception,):
        logger.error(create_log_msg("Ejecucion de lambda interrumpida"))
        return {
            "statusCode": 500,
            "body": json.dumps("Fallo la ejecucion de la lambda"),
        }