import logging
import numpy as np
import pandas as pd
import datetime as dt
import time
import common_library.general_functions as functions
pd.options.mode.chained_assignment = None  # default='warn'
from common_library.error import PlataformError
from common_library.precia_logger import setup_logging, create_log_msg

logger = setup_logging()
logger.setLevel(logging.INFO)

class OptionBonds(object):
    """
    Esta clase ejecuta la metodologia de bonos con opcionalidad
    Autor: investigacion y desarrollo <investigacion@precia.co>
    Fecha: 2022-10-12
    """

    def __init__(self, valuation_date):
        self.valuation_date = valuation_date
        
    def equivalent_margin_corp(self, corp_data, variable_instr_index, today_indexes):
        """
        Calcular el margen equivalente de unos titulos
        Autor: Laura Natalia Lopez <llopez@precia.co>
        Fecha: 2021-05-05
        :corp_data: (DataFrame) informacion de los titulos ('TIR','RATE_TYPE','RATE_EXPRESSION',
                                'EQUIVALENT_MARGIN')
        :variable_instr_index: (array) tipo de indices de los titulos tasa variable
        :today_indexes: (DataFrame) datos de los indices para el dia de valoracion ('RATE_VALUE','RATE_TYPE')
        :return: corp_data (DataFrame) con el campo 'EQUIVALENT_MARGIN' calculado
        """
        try:
            for j in range(0, len(variable_instr_index)):
                index = variable_instr_index[j]
                today_index = today_indexes['RATE_VALUE'][today_indexes['RATE_TYPE'] == index]
                expression = corp_data[corp_data['RATE_TYPE'] == index][
                    'RATE_EXPRESSION'].drop_duplicates().reset_index(drop=True)
                if len(expression) != 1:
                    logger.info('Existe(n) titulo(s) con rate_type ' + str(index) + ' y mas de una expresion de tasa ' +\
                                 str(np.array(expression)) + 'No permite calcular cupon actual')
                    error_msg = 'Existe(n) titulo(s) con rate_type ' + str(index) + ' y mas de una expresion de tasa ' +\
                                 str(np.array(expression)) + 'No permite calcular cupon actual'
                    logger.error(create_log_msg(error_msg))
                    raise PlataformError(error_msg)
                expression = expression[0]
                index_pos = corp_data[corp_data['RATE_TYPE'] == index].index
                if index == 'IPC' and expression == 'EFE':
                    corp_data.loc[index_pos, 'EQUIVALENT_MARGIN'] = ((corp_data.loc[index_pos, 'TIR'] / 100 + 1) / (
                                1 + np.array(today_index) / 100) - 1) * 100
                elif index == 'IB1' and expression == 'NOM':
                    periodic_rate = np.array(today_index) / 100 / 12
                    annual_rate = ((1 + periodic_rate) ** (12) - 1) * 100
                    corp_data.loc[index_pos, 'EQUIVALENT_MARGIN'] = ((corp_data.loc[index_pos, 'TIR'] / 100 + 1) / (
                                1 + np.array(annual_rate) / 100) - 1) * 100
                elif index == 'IB3' and expression == 'NOM':
                    periodic_rate = np.array(today_index) / 100 / 4
                    annual_rate = ((1 + periodic_rate) ** (4) - 1) * 100
                    corp_data.loc[index_pos, 'EQUIVALENT_MARGIN'] = ((corp_data.loc[index_pos, 'TIR'] / 100 + 1) / (
                                1 + np.array(annual_rate) / 100) - 1) * 100
                elif index == 'IB6' and expression == 'NOM':
                    periodic_rate = np.array(today_index) / 100 / 2
                    annual_rate = ((1 + periodic_rate) ** (2) - 1) * 100
                    corp_data.loc[index_pos, 'EQUIVALENT_MARGIN'] = ((corp_data.loc[index_pos, 'TIR'] / 100 + 1) / (
                                1 + np.array(annual_rate) / 100) - 1) * 100
                elif index == 'DTF' and expression == 'NOM':  # Si es DTF es NATA, hay que pasarlo a Efectivo
                    efective_rate_ant = (np.array(today_index) / 100) / 4
                    efective_rate = efective_rate_ant / (1 - efective_rate_ant)
                    annual_rate = ((1 + efective_rate) ** 4 - 1) * 100
                    corp_data.loc[index_pos, 'EQUIVALENT_MARGIN'] = ((corp_data.loc[index_pos, 'TIR'] / 100 + 1) / (
                                1 + np.array(annual_rate) / 100) - 1) * 100
                elif expression == 'NOM':  # se asume anual
                    annual_rate = np.array(today_index)
                    corp_data.loc[index_pos, 'EQUIVALENT_MARGIN'] = ((corp_data.loc[index_pos, 'TIR'] / 100 + 1) / (
                                1 + np.array(annual_rate) / 100) - 1) * 100
                elif expression == 'EFE':  # Se asume anual
                    corp_data.loc[index_pos, 'EQUIVALENT_MARGIN'] = ((corp_data.loc[index_pos, 'TIR'] / 100 + 1) / (
                                1 + np.array(today_index) / 100) - 1) * 100
                else:
                    logger.info('Existe(n) titulo(s) con rate_type ' + str(
                        index) + ' y una expresion de tasa que no es EFE ni NOM')
                    error_msg = 'Existe(n) titulo(s) con rate_type ' + str(
                        index) + ' y una expresion de tasa que no es EFE ni NOM'
                    logger.error(create_log_msg(error_msg))
                    raise PlataformError(error_msg)
        except ValueError as sec_exc:
            logger.error('Se genero un error en la funcion equivalent_margin_corp ')
            error_msg = "Se genero un error en la funcion equivalent_margin_corp"
            raise PlataformError(error_msg) from sec_exc
        except NameError as sec_exc:
            logger.error('Se genero un error en la funcion equivalent_margin_corp ')
            error_msg = 'Se genero un error en la funcion equivalent_margin_corp '
            raise PlataformError(error_msg) from sec_exc
        except TypeError as sec_exc:
            logger.error('Se genero un error en la funcion equivalent_margin_corp ')
            error_msg = 'Se genero un error en la funcion equivalent_margin_corp '
            raise PlataformError(error_msg) from sec_exc
        except IndexError as sec_exc:
            logger.error('Se genero un error en la funcion equivalent_margin_corp ')
            error_msg = 'Se genero un error en la funcion equivalent_margin_corp '
            raise PlataformError(error_msg) from sec_exc
        except Exception as sec_exc:
            logger.error('Se genero un error en la funcion equivalent_margin_corp ')
            error_msg = 'Se genero un error en la funcion equivalent_margin_corp '
            raise PlataformError(error_msg) from sec_exc
        return corp_data

    
    def option_bonds_prices(self,option_get_category, opt_margin_diff,category_margin,
                            index_hist,ref_curve,operations):
        """
        Calcular el precio estimado, precio limpio, el margen de valoracion y TIR equivalentes
            para los bonos con opcionalidad
        Autor: investigacion y desarrollo <investigacion@precia.co>
        Fecha: 2022-10-12
        :param parameters: Informacion de parametros desde tabla src_rfl_parameters
        :param get_category_table: Informacion de condiciones faciales desde tabla prc_rfl_gt_category
        :param instrument_info: Información de condicionoes faciales adicionales de los bonos con opcionalidad
        :param category_margin: Margenes de las categorias de prc_rfl_category_margin
        :param rates_values: Historico de las tasas de src_rfl_rates
        :param ref_curve: Curvas cero cupon para el dia de valoracion de pub_rfl_yield
        :param operations: Operaciones para el dia de valoracion de prc_rfl_operations
        :return: Tabla con condiciones faciales de titulos, precio promedio, precio limpio, margen y tir equivaltes, cupon corrido y calculos de riesgo
        """
        try:
            logger.info('Inician los calculos de valoracion de los bonos con opionalidad')
            option_get_category = option_get_category.merge(opt_margin_diff,on = ['INSTRUMENT','ISIN_CODE'],how = 'left')
            option_get_category = option_get_category.merge(category_margin,on = 'CATEGORY_ID',how = 'left')
            instr_index = option_get_category['RATE_TYPE'].drop_duplicates().reset_index(drop=True)
            variable_instr_index = index_hist['RATE_TYPE'].drop_duplicates().reset_index(drop=True)
            date_ini = dt.datetime.strptime(self.valuation_date,'%Y-%m-%d').date()
            today_indexes = index_hist[index_hist['RATE_DATE'] == date_ini]
            diff_rates = np.setdiff1d(instr_index[instr_index != 'FS'],today_indexes['RATE_TYPE'])
            if len(diff_rates) != 0:
                logger.info('No existe informacion de las tasas ' + str(
                    diff_rates) + ' en la tabla src_rfl_rates para el dia de valoracion ' + str(self.valuation_date))
                error_msg = 'No existe informacion de las tasas  '
                raise PlataformError(error_msg)
            
            option_get_category['RATE_FIXED_FLOAT'] = 1
            pos_var = np.where(option_get_category['RATE_TYPE'] != 'FS')[0]
            option_get_category['RATE_FIXED_FLOAT'][pos_var] = 3
            logger.info('identificacion de las caracteristicas faciales de los titulos')
            option_get_category.loc[:, 'BASE_NUM'] = np.nan
            option_get_category.loc[:, 'BASE_DENOM'] = np.nan
            option_get_category.loc[:, 'CPN_COMPLETE'] = False
            option_get_category.loc[:, 'COUPON_RATE'] = option_get_category['COUPON'].copy()
            
            base_365_nl_pos = np.where(option_get_category['BASE'] == 'N')[0]
            base_30_360_pos = np.where(option_get_category['BASE'] == 'C')[0]
            base_Act_366_pos = np.where(option_get_category['BASE'] == 'D')[0]
            ## Titulos Act NL/ 365, base = N
            option_get_category.loc[base_365_nl_pos, 'BASE_NUM'] = '365'
            option_get_category.loc[base_365_nl_pos, 'BASE_DENOM'] = 365
            ## Titulos 30/360, base = C
            option_get_category.loc[base_30_360_pos, 'BASE_NUM'] = '30'
            option_get_category.loc[base_30_360_pos, 'BASE_DENOM'] = 360
            ## Titulos Act/366, base = D
            option_get_category.loc[base_Act_366_pos, 'BASE_NUM'] = 'Act'
            option_get_category.loc[base_Act_366_pos, 'BASE_DENOM'] = 366
            ## ------ cupon completo, son los que el spread_coupon es el cupon completo.
            logger.info('identificacion de cupon completo o cupon spread')
            option_get_category.loc[option_get_category['RATE_TYPE'] == 'FS', 'CPN_COMPLETE'] = True
            logger.info('Inicia el calculo de cupon segun tasa actual para los titulos indexados a ' + str(
                np.array(variable_instr_index)))
            for j in range(0, len(variable_instr_index)):
                index = variable_instr_index[j]
                today_index = today_indexes['RATE_VALUE'][today_indexes['RATE_TYPE'] == index]
                expression = option_get_category[option_get_category['RATE_TYPE'] == index][
                    'RATE_EXPRESSION'].drop_duplicates().reset_index(drop=True)
                if len(expression) != 1:
                    logger.error('Existe(n) titulo(s) con rate_type ' + str(index) + ' y mas de una expresion de tasa '
                                 + str(np.array(expression)) + 'No permite calcular cupon actual')
                    raise PlataformError(error_message='Existe(n) titulo(s) con rate_type')
                expression = expression[0]
                index_pos = np.where(option_get_category['RATE_TYPE'] == index)[0]
                if expression == 'EFE':  # es efectivo (se suman geométricamente)
                    option_get_category.loc[index_pos, 'COUPON'] = ((option_get_category.loc[index_pos, 'COUPON_RATE'] / 100 + 1) * (
                            1 + np.array(today_index) / 100) - 1) * 100
                elif expression == 'NOM':  # es nominal (se suman directamente)
                    option_get_category.loc[index_pos, 'COUPON'] = option_get_category.loc[index_pos, 'COUPON_RATE'] + np.array(today_index)
                else:
                    logger.error('Existe(n) titulo(s) con rate_type ' + str(index) + ' y una expresion de tasa que no es EFE ni NOM')
                    raise PlataformError(error_message='Existe(n) titulo(s) con rate_type')
            logger.info('Inicia alistamiento de informacion para el calculo de precio estimado')
            issue_t = np.array(pd.to_datetime(option_get_category['ISSUE_DATE'], format='%Y-%m-%d').dt.date)
            mat_t = np.array(pd.to_datetime(option_get_category['OPT_DATE'], format='%Y-%m-%d').dt.strftime("%d/%m/%Y"))
            spread = np.array(option_get_category['COUPON_RATE'])
            cpn = np.array(option_get_category['COUPON'])
            noc_val = np.array(option_get_category['STRIKE']/100)
            base = np.array(option_get_category['BASE_DENOM'])
            base_num = np.array(option_get_category['BASE_NUM'])
            rate_expr = np.array(option_get_category['RATE_EXPRESSION'])
            rate_type = np.array(option_get_category['RATE_TYPE'])
            cpn_complete = np.array(option_get_category['CPN_COMPLETE'])
            freq_months = np.array(option_get_category['FREQUENCY_MONTHS'])
            rate_use = np.array(option_get_category['USE_RATE'])

            logger.info('Inicia calculo de matriz de flujos para ' + str(len(option_get_category)) + ' titulos')
            dataList = dict({'date_ini': date_ini,# Fecha de valoracin en dt.date
                             'issue_t': issue_t,  # Fechas de emicion de los titulos
                             'mat_t': mat_t,  # Fechas de vencimiento de los titulos en np.array con str
                             'cpn': cpn,  # cupones de los titulos en np.array
                             'noc': noc_val,  # valor del nocional de los titulos en np.array
                             'base': base,  # base del denominador del conteo de dias, puede ser 365, 360
                             'base_num': base_num,  # 356 es Act/365 NL, Act es Act/365
                             'freq_months': freq_months,  # Cada cuanto paga cupon en np.array
                             'cpn_complete': cpn_complete,# booleano que determina si cpn es cupon completo o el spread
                             'y_lim': [-10, 30],  # limites que se utilizan para encontrar una raiz (optim)
                             'rate_expr': rate_expr,  # Expresion de la tasa 0 para efectiva, 2 para nominal
                             'spread': spread,  # parte del cupon que es un spread fijo sobre el indice
                             'rate_use': rate_use,# Informacion si los titulos utilzan tasa previa P o actual A
                             'index_hist': index_hist,# Historico de los indices con 3 columnas rate_type, rate_date, value_rate
                             'rate_type': rate_type,  # Informacion de tipo de tasa de los titulos
                             })
            ini = time.time()
            flows_dict = functions.bond_flows_m(dataList)
            failed_instr_pos = flows_dict['failed_instr_pos']
            logger.info("inicia el proceso de option bonds 6")
            if len(failed_instr_pos) != 0:
                instr_ = np.array(option_get_category['ISIN_CODE'].drop_duplicates())
                falied_instr = instr_[failed_instr_pos]
                logger.info('No se construyo de manera adecuada la matriz de flujos para lo(s) titulo(s) ' + str(
                    falied_instr) + ' revisar log')
            fin = time.time()
            logger.info("El tiempo de ejcucion en el calculo de matriz de flujos corp (seg):" + 
                        str(fin - ini) + " para " + str(len(option_get_category)) + " titulos")
            
            logger.info("Determinar insumos de mercado para calculo de precios")
            terms = flows_dict['terms_desc']
            delta_t = terms / 365
            unique_ref_curve = np.unique(option_get_category["CC_CURVE"])
            disc_curves = np.zeros((len(terms), len(option_get_category)))
            logger.info("Construir factores de descuento")
            ini_time = time.time()
            for i in range(len(unique_ref_curve)):
                curves_rates = ref_curve['RATE'][ref_curve["CC_CURVE"]==unique_ref_curve[i]].values
                if len(curves_rates) == 0:
                    logger.info('En pub_rfl_yield, no existen datos de la curva ' + str(unique_ref_curve[i]))
                    raise PlataformError(error_message='En pub_rfl_yield, no existen datos de la curva')
                delta_t_i = np.array(range(1, curves_rates.shape[0] + 1)) / 365
                curves_values = functions.discount_factor_curve_m(curves_rates/100, delta_t_i)
                curves_values = curves_values[terms[terms <= len(curves_values)] - 1]
                curves_pos = np.where(option_get_category["CC_CURVE"] == unique_ref_curve[i])[0]
                ind_row = np.array(range(curves_values.shape[0]))
                curves_rep = np.tile(curves_values, len(curves_pos)).reshape(len(curves_pos),len(curves_values)).T
                disc_curves[ind_row[:, None], curves_pos] = curves_rep

            fin_time = time.time()
            logger.info("El tiempo de ejecucion para la construccion de factores de descuento fue de" + str(fin_time - ini_time))
            logger.info("Determinar si la matriz de factores de descuento tiene valores en infinito")
            disc_curves[np.isnan(disc_curves)] = 0.0
            inf_pos = np.where(np.isinf(disc_curves))[0]            
            if len(inf_pos)!=0:
                inf_curve = disc_curves['CC_CURVE'].iloc[inf_pos]
                logger.info('La curva de factores de descuento ' + inf_curve + ' tiene valores en infinito (revisar la curva en pub_rfl_yield)')
                raise PlataformError(error_message='La curva de factores de descuento ' + inf_curve + ' tiene valores en infinito')
            logger.info("Inicio de calculos de valoracion para " + str(len(option_get_category)) + " instrumentos")
            option_get_category['VTO_DATE'] = np.where(option_get_category['MATURITY_DATE'] == option_get_category['OPT_DATE'],1,0)
            option_get_category = option_get_category.reset_index().rename(columns = {'index':'flows_loc'})
            option_get_category['MARGIN_ORIGIN'] = 'IND'
            option_get_category['INST_CONDITION'] = 'A'

            if len(operations) != 0:
                logger.info("Inicio de calculo de precio promedio ponderado")
                wm = lambda x: np.average(x, weights=operations.loc[x.index, "AMOUNT"])
                average_price = operations.groupby(['INSTRUMENT']).agg(MEAN_PRICE = ('DIRTY_PRICE',wm))
                logger.info("Se calculo precio promedio ponderado para " + str(len(average_price)) + " titulos")
                
                bonds_level1 = option_get_category.merge(average_price,left_on ='INSTRUMENT',right_index = True,how ='left')
                bonds_level1 = bonds_level1[~bonds_level1['MEAN_PRICE'].isna()]
                
                logger.info("Inicio de calculo de yield to worst para identificar el plazo del precio promedio")
                yields = functions.price_to_yield_loop(bonds_level1['MEAN_PRICE'].values/100,dataList,flows_dict,bonds_level1.flows_loc.values)
                bonds_level1['TIR'] = functions.rd_vec(yields, 3)
                bonds_level1 = bonds_level1[bonds_level1.groupby(['ISIN_CODE']).TIR.transform(min) == bonds_level1.TIR]
                
                logger.info("Inicio de calculo del margen para el precio promedio al plazo indicado por ytw")
                margin = functions.instrument_margin(bonds_level1['MEAN_PRICE'].values,flows_dict, delta_t, disc_curves,bonds_level1.flows_loc.values)
                bonds_level1['MARGIN_VALUE'] = margin
                bonds_level1['MARGIN_DIFF'] = bonds_level1['MARGIN_VALUE'] - bonds_level1['MARGIN_CAT']
                bonds_level1['MARGIN_TYPE'] = 'C'
                bonds_level1['CALCULATION_TYPE'] = '1'
                bonds_level1['CALCULATION_BASE'] = '0'
                
                bonds_teoric = option_get_category[~option_get_category['ISIN_CODE'].isin(bonds_level1['ISIN_CODE'])]
            else:
                logger.info("No hay operaciones para calcular precio promedio ponderado")
                bonds_level1 = pd.DataFrame()
                bonds_teoric = option_get_category
            
            if len(bonds_teoric) != 0:
                logger.info("Inicio de calculo de precio teorico para los titulos sin operaciones")
                bonds_vto = bonds_teoric[bonds_teoric['VTO_DATE'] == 1]
                bonds_opt = bonds_teoric[bonds_teoric['VTO_DATE'] == 0]
                pos_vto = bonds_vto.reset_index().set_index(['ISIN_CODE']).loc[bonds_opt['ISIN_CODE'], 'index'].values
                margin_vto = bonds_vto['MARGIN_CAT'][pos_vto].values
                
                logger.info("Inicio de calculo de precio forward para las fechas de opcionalidad")
                fwd_price = functions.fwd_option_price(bonds_opt,margin_vto,disc_curves,flows_dict,pos_vto)
                bonds_opt = bonds_opt[fwd_price*100 > bonds_opt['STRIKE']]
                bonds_opt = bonds_opt[bonds_opt.groupby(['ISIN_CODE']).DAYS.transform(min) == bonds_opt.DAYS]
                
                logger.info("Inicio de calculo de precio estimado para las fechas indicadas por el precio forward")
                bonds_vto = bonds_vto[~bonds_vto['ISIN_CODE'].isin(bonds_opt['ISIN_CODE'])]
                bonds_level2 = pd.concat([bonds_vto,bonds_opt])
                bonds_level2['MARGIN_VALUE'] = bonds_level2['MARGIN_DIFF'] + bonds_level2['MARGIN_CAT']
                bonds_level2['MEAN_PRICE'] = functions.instrument_dirty_price(flows_dict, delta_t, disc_curves,
                                                bonds_level2.flows_loc.values, bonds_level2['MARGIN_VALUE'].values)
                bonds_level2['MARGIN_TYPE'] = 'H'
                bonds_level2['CALCULATION_TYPE'] = '2'
                bonds_level2['CALCULATION_BASE'] = '0'
                
                logger.info("Inicio de calculo de yield to worst para los titulos sin operaciones")
                bonds_teoric = bonds_teoric.merge(bonds_level2[['ISIN_CODE','MEAN_PRICE']],on='ISIN_CODE',how = 'left')
                ytw = functions.price_to_yield_loop(bonds_teoric['MEAN_PRICE'].values/100,dataList,flows_dict,bonds_teoric.flows_loc.values)
                bonds_teoric['TIR'] = functions.rd_vec(ytw, 3)
                bonds_teoric = bonds_teoric[['ISIN_CODE','TIR']][bonds_teoric.groupby(['ISIN_CODE']).TIR.transform(min) == bonds_teoric.TIR]
                bonds_level2 = bonds_level2.merge(bonds_teoric,on='ISIN_CODE',how = 'left')
            else:
                logger.info("No hay titulo para valorar por nivel 2")
                bonds_level2 = pd.DataFrame()
            
            option_get_category = pd.concat([bonds_level1,bonds_level2])
            
            logger.info('Inicia calculo de medidas de riesgo')
            mac_duration = functions.mac_duration_m(flows_dict, option_get_category)*100
            option_get_category['DURATION'] = functions.rd_vec(mac_duration, 4)
            mod_duration = functions.mod_duration_m_adj(option_get_category, mac_duration/100)*100
            option_get_category['MODIFIED_DURATION'] = functions.rd_vec(mod_duration, 4)
            convex = functions.convexity_m(flows_dict, option_get_category) * 100
            option_get_category['CONVEXITY'] = functions.rd_vec(convex, 4)
                     
            logger.info("Finalizan los calculos de valoracion para " + str(len(option_get_category)) + " instrumentos")
            logger.info('Asignacion de cupon corrido')
            cpn_acum  = flows_dict['accrued_interest'][option_get_category.flows_loc.values]
            option_get_category['ACCRUED_INTEREST'] = functions.rd_vec(cpn_acum, 4)
            logger.info('Calculo de precio limpio')
            option_get_category["CLEAN_PRICE"] = functions.rd_vec(option_get_category["MEAN_PRICE"] - option_get_category["ACCRUED_INTEREST"], 3)
            # Asignar margen equivalente a los titulos con rate_tipe igual a fs
            logger.info("Inicia calculo de margen equivalente para " + str(len(variable_instr_index)) + ' tipos de tasa')
            option_get_category["EQUIVALENT_MARGIN"] = option_get_category["MARGIN_VALUE"]
            option_get_category = OptionBonds.equivalent_margin_corp(self, option_get_category, variable_instr_index, today_indexes)
            
            logger.info('Inicia organización de tabla de salida')
            columns_order_price = ['CATEGORY_DATE', 'CATEGORY_ID', 'ISIN_CODE', 'INSTRUMENT', 'ISSUE_DATE',
                                   'MATURITY_DATE', 'MATURITY_DAYS', 'PAYMENT_FREQUENCY', 'RATE_TYPE',
                                   'COUPON_RATE', 'MARGIN_VALUE', 'ACCRUED_INTEREST', 'ISSUE_NUM','TIR',
                                   'INST_CONDITION', 'CURRENCY_TYPE', 'MEAN_PRICE', 'CLEAN_PRICE','CONVEXITY',
                                   'EQUIVALENT_MARGIN', 'CALCULATION_TYPE', 'DURATION','MODIFIED_DURATION',
                                   'MARGIN_TYPE','MARGIN_ORIGIN','MARGIN_DIFF','OPT_DATE','RATE_FIXED_FLOAT','CALCULATION_BASE']
            option_pub_prices = option_get_category.reindex(columns=columns_order_price, copy=False)
            option_pub_prices['CATEGORY_DATE'] = self.valuation_date
            option_pub_prices['ISSUE_DATE'] = np.array(
                pd.to_datetime(option_pub_prices['ISSUE_DATE']).dt.strftime('%Y-%m-%d'))
            option_pub_prices['MATURITY_DATE'] = np.array(
                pd.to_datetime(option_pub_prices['MATURITY_DATE']).dt.strftime('%Y-%m-%d'))
            logger.info('Fin de calculo de precio estimado, precio limpio, margenes y TIRs para ' + str(
                len(option_pub_prices)) + ' titulos con opcionalidad')
        except ValueError as e:
            logger.error('Se genero un error en la funcion corp_estimated_prices ')
            logger.error(e)
            raise PlataformError(error_message='Se genero un error en la funcion corp_estimated_prices ')
        except NameError as e:
            logger.error('Se genero un error en la funcion corp_estimated_prices ')
            logger.error(e)
            raise PlataformError(error_message='Se genero un error en la funcion corp_estimated_prices')
        except TypeError as e:
            logger.error('Se genero un error en la funcion corp_estimated_prices ')
            logger.error(e)
            raise PlataformError(error_message='Se genero un error en la funcion corp_estimated_prices')
        except IndexError as e:
            logger.error('Se genero un error en la funcion corp_estimated_prices ')
            logger.error(e)
            raise PlataformError(error_message='Se genero un error en la funcion corp_estimated_prices')
        except Exception as e:
            logger.error('Se genero un error en la funcion corp_estimated_prices ')
            logger.error(e)
            raise PlataformError(error_message='Se genero un error en la funcion corp_estimated_prices ')
        return option_pub_prices


    def instrument_variation(self, parameters,today_prices_table,prev_prices_table,prev_date):
        """
        Determinar los titulos cuya variacion se encuentra por fuera de los limites de precios y TIRs.
        Autor: Investigacion y Desarrollo <investigacion@precia.co>
        Fecha: 2021-09-17
        :param parameters: Informacion de parametros desde tabla
        :param valuation_date: String Fecha de valoracion
        :return: Tabla con informacion de los titulos
        """
        try: 
            logger.info("Inicia calculo de variaciones en precios y TIRs para el "+self.valuation_date)
            today_prices_table.rename(columns = {'CATEGORY_DATE':'VALUATION_DATE','TIR':'YIELD'},inplace = True)
            max_price_variation = int(parameters['Properties']['max_price_variation'])
            max_yield_variation = int(parameters['Properties']['max_yield_variation'])
            logger.info("El analisis se realiza con una variacion maxima de " + str(max_price_variation)
                        +" en pips (precio) y de "+str(max_yield_variation)+" en pbs (TIRs)")
            price_data = today_prices_table.merge(prev_prices_table, how="inner", on=['INSTRUMENT', 'ISIN_CODE'])
            price_data = price_data.reset_index(drop=True)
            if len(price_data)==0:
                logger.info('No existe informacion de titulos que coincida entre la fecha '+ self.valuation_date
                             +' y la fecha '+ str(prev_date) +'. Termina el proceso sin calculo de variaciones')
                return
            logger.info("Ordenar columnas de la tabla de precios")
            col_order = ['VALUATION_DATE', 'ISIN_CODE', 'INSTRUMENT', 'CATEGORY_ID', 'MATURITY_DAYS', 'MEAN_PRICE_x',
                         'MEAN_PRICE_y', 'YIELD_x', 'YIELD_y','ACCRUED_INTEREST']
            price_data = price_data.reindex(columns=col_order, copy=False)
            logger.info("Inicia el calculo de variaciones de precios y TIRs")
            price_data.insert(7, "PRICE_DIFF", (price_data['MEAN_PRICE_x']-price_data['MEAN_PRICE_y'])*100)
            price_data.insert(10, "YIELD_DIFF", (price_data['YIELD_x']-price_data['YIELD_y'])*100)
            logger.info("Determinar titulos con variaciones de precios y TIRs superiores a los limites")
            price_pos = np.where((price_data['PRICE_DIFF'].abs()>max_price_variation))[0]
            tir_pos = np.where((price_data['YIELD_DIFF'].abs()>max_yield_variation))[0]
            total_pos = np.unique(np.concatenate((price_pos, tir_pos)))
            price_data = price_data.iloc[total_pos,:]
            logger.info("Determinar titulos que pagaron cupon")
            price_data.insert(5, "PAID_COUPON", 'N')
            price_data.loc[price_data['ACCRUED_INTEREST']==0,'PAID_COUPON'] = 'S'
            price_data = price_data.drop(columns=['ACCRUED_INTEREST'])
            timestamp = dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            price_data['UPDATE_TIME'] = timestamp
            logger.info("Finaliza al calculo de las variaciones en precios y TIRs para el "+self.valuation_date)
        except AttributeError as e:
            logger.error('Se genero un error en la funcion instrument_variation ')
            logger.error(e)
            raise PlataformError(error_message='Se genero un error en la funcion instrument_variation ')
        except ValueError as e:
            logger.error('Se genero un error en la funcion instrument_variation ')
            logger.error(e)
            raise PlataformError(error_message='Se genero un error en la funcion instrument_variation ')
        except NameError as e:
            logger.error('Se genero un error en la funcion get_instrument_out_limits_variation ')
            logger.error(e)
            raise PlataformError(error_message='Se genero un error en la funcion instrument_variation ')
        except TypeError as e:
            logger.error('Se genero un error en la funcion get_instrument_out_limits_variation ')
            logger.error(e)
            raise PlataformError(error_message='Se genero un error en la funcion instrument_variation ')
        except IndexError as e:
            logger.error('Se genero un error en la funcion get_instrument_out_limits_variation ')
            logger.error(e)
            raise PlataformError(error_message='Se genero un error en la funcion instrument_variation ')
        except Exception as e:
            logger.error('Se genero un error en la funcion get_instrument_out_limits_variation ')
            logger.error(e)
            raise PlataformError(error_message='Se genero un error en la funcion instrument_variation ')
        return price_data
