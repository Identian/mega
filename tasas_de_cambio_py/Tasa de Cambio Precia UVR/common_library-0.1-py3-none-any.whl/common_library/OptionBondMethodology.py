import sys
import datetime as dt
import pandas as pd
import time

from common_library.persistence import Model
from common_library.categorization import Categorization
from common_library.option_bonds import OptionBonds
from common_library.error import PlataformError
from common_library.precia_logger import setup_logging, create_log_msg
from common_library.aws_utils import getSecret, connect_db
from awsglue.utils import getResolvedOptions

try:
    logger = setup_logging()
    args = getResolvedOptions(sys.argv,['VALUATION_DATE','DB_SECRET_NAME'])
    params = getSecret(args['DB_SECRET_NAME'])
except (Exception,) as sec_exc:
    error_msg = "Se ha presentado un error obteniendo los parametros para la metodologia"
    logger.error(create_log_msg(error_msg))
    raise PlataformError(error_msg) from sec_exc


class OptionBondMethodology:
    def __init__(self) -> None:
        self.conn_sources = connect_db(params['engine'], params['host'], params['port'], 'precia_sources', params['username'], params['password'])
        self.conn_process = connect_db(params['engine'], params['host'], params['port'], 'precia_process', params['username'], params['password'])
        self.engine_published = connect_db(params['engine'], params['host'], params['port'], 'precia_published', params['username'], params['password'])

    def execute_option_bonds(self):
        try:
            logger.info("Inicia la ejecución de la metodología de bonos con opcionalidad de Renta Fija Local")
            valuation_date = args['VALUATION_DATE']
            date = valuation_date
            valuation_datetime = dt.datetime.strptime(valuation_date, '%Y-%m-%d')
            valuation_date = valuation_datetime.date()
            valuation_datetime = (valuation_datetime + dt.timedelta(hours=20)).strftime('%Y-%m-%d %H:%M:%S')
            
            
            category_object = Categorization(self.conn_sources, self.conn_process, valuation_date)
            model_object = Model(self.conn_sources, self.conn_process, self.engine_published)
            prices_object = OptionBonds(date)
            
            logger.info("Incluyendo insumos necesarios de las bases de datos")
            
            option_bonds_info = Model.get_option_bonds_info(model_object)
            option_bonds_info.columns = option_bonds_info.columns.str.upper()
            
            if len(option_bonds_info) == 0:
                logger.info('No hay informacion de titulos para valorar en src_rfl_option_bonds')
                sys.exit(0)
            if any(option_bonds_info['OPT_DATE'].str.split("|").str.len() != option_bonds_info['STRIKE'].str.split("|").str.len()):
                logger.error('La cantidad de fechas de ejercicio no coincide con la cantidad de strikes parametrizados')
                raise PlataformError(error_message="La cantidad de fechas de ejercicio no coincide con la cantidad de strikes parametrizados")
            
            isines_opt = option_bonds_info['ISIN_CODE'].unique()
            instrument_info = Model.get_instrument_info(model_object,isines_opt)
            instrument_info.columns = instrument_info.columns.str.upper()
            category_table = Model.get_get_category(model_object, isines_opt, valuation_date)
            category_table.columns = category_table.columns.str.upper()
            
            if len(instrument_info) == 0:
                logger.info("No hay instrumentos activos en la tabla src_rfl_instrument")
                sys.exit(0)
                
            if len(category_table) == 0:
                logger.error("No hay informacion de titulos para valorar en prc_rfl_get_category")
                PlataformError(error_message="No hay informacion de titulos para valorar en prc_rfl_get_category")
            
            instrument_info = instrument_info.merge(option_bonds_info,on = ['INSTRUMENT','ISIN_CODE'],how = 'left')
            instrument_info = instrument_info.merge(category_table,on = ['INSTRUMENT','ISIN_CODE'],how = 'left')
            rating_info = instrument_info[['INSTRUMENT','ISIN_CODE','REAL_RATING']]
            
            parameters = Model.get_rfl_parameters(model_object)
            if len(parameters) == 0:
                logger.info('No hay informacion en la tabla src_rfl_parameters ')
                PlataformError(error_message="No hay informacion en la tabla src_rfl_parameters ")
            
            margin_diff = Model.get_option_diff(model_object,isines_opt,valuation_date)
            margin_diff.columns = margin_diff.columns.str.upper()
            if len(margin_diff) == 0:
                logger.error('No hay informacion en prc_rfl_option_bonds_diff para el día anterior')
                raise PlataformError(error_message = 'No hay informacion en prc_rfl_option_bonds_diff para el día anterior')
            
            instrument_rates = instrument_info['RATE_TYPE'].unique()
            rates_values = Model.get_src_rates(model_object,instrument_rates)
            rates_values.columns = rates_values.columns.str.upper()
            
            if len(rates_values) == 0 and all(instrument_rates != 'FS'):
                logger.error('No hay informacion en src_rfl_rates')
                raise PlataformError(error_message = 'No hay informacion en src_rfl_rates')
            
            instrument_curves = instrument_info['CC_CURVE'].unique()
            ref_curve = Model.get_cc_curve(model_object,valuation_date,instrument_curves)
            
            ref_curve.columns = ref_curve.columns.str.upper()
            
            if len(ref_curve) == 0:
                logger.error('No hay informacion en pub_rfl_yield')
                raise PlataformError(error_message = 'No hay informacion en pub_rfl_yield')
            
            instruments = instrument_info['INSTRUMENT'].unique()
            operations = Model.get_operations_total_time(model_object, valuation_date,valuation_datetime,instruments)
            operations.columns = operations.columns.str.upper()
            if len(operations) == 0:
                logger.info('No hay informacion en la tabla prc_rfl_operations')
            
            prev_date =  valuation_date - dt.timedelta(days=1)
            prev_prices = Model.get_prices_to_variation(model_object, prev_date,isines_opt)
            if len(prev_prices) == 0:
                logger.info('No hay informacion en la tabla pub_rfl_prices para '+ str(prev_date))
                
            logger.info("Inicia el proceso de Categorizacion")
            
            expiration_ranges = Model.get_expiration_ranges(model_object)
            get_category_table = Categorization.categorize(category_object,instrument_info, expiration_ranges)
            
            logger.info("Finaliza el proceso de categorizacion")
            
            instrument_categories = get_category_table['CATEGORY_ID'].unique()
            category_margin = Model.get_category_margin(model_object,valuation_date,instrument_categories)
            category_margin.columns = category_margin.columns.str.upper()
            category_margin["CATEGORY_ID"] = category_margin["CATEGORY_ID"].astype(str)
            
            if len(category_margin) == 0:
                logger.error('No hay informacion en prc_rfl_category_margin')
                raise PlataformError(error_message = "No hay informacion en prc_rfl_category_margin")

            logger.info("Inicia el proceso de Valoracion")
            
            p_opt = OptionBonds.option_bonds_prices(prices_object,get_category_table,
                                    margin_diff,category_margin,rates_values,ref_curve,operations)
            
            
            logger.info('Incluyendo calificacion proveniente de src_rfl_options_bonds')
            p_opt = p_opt.merge(rating_info,on = ['INSTRUMENT','ISIN_CODE'],how = 'left')
            
            margin_diff = p_opt[['CATEGORY_DATE','INSTRUMENT','ISIN_CODE','OPT_DATE','MARGIN_DIFF']]
            margin_value = p_opt[['ISIN_CODE','MARGIN_VALUE','MARGIN_TYPE','MARGIN_ORIGIN']]
            pub_prices = p_opt.drop(['OPT_DATE','MARGIN_DIFF','MARGIN_TYPE','MARGIN_ORIGIN'],axis=1)
            Model.delete_option_bond_prices(model_object, valuation_date, isines_opt)
            Model.insert_prices_risk_pd(model_object, pub_prices)
            Model.update_options_bonds_margin(model_object,margin_value)
            Model.delete_option_bond_diff(model_object, valuation_date, isines_opt)
            Model.insert_margin_diff(model_object,margin_diff)
            Model.delete_rfl_price_yield_variation(model_object,valuation_date,isines_opt)
            table_out = OptionBonds.instrument_variation(prices_object,parameters,pub_prices,prev_prices,prev_date)
            Model.insert_rfl_price_yield_variation(model_object,table_out)
            self.conn_sources.close()
            self.conn_process.close()
            self.engine_published.close()
            logger.info("Finaliza correctamente la ejecucion de la metodología de bonos con opcionalidad de Renta Fija Local")
        except (Exception,) as sec_exc:
            error_msg = "Se ha presentado un error ejecutando la metodología"
            logger.error(create_log_msg(error_msg))
            raise PlataformError(error_msg) from sec_exc

if __name__ == "__main__":
    app = OptionBondMethodology()
    app.execute_option_bonds()