import logging
import pandas as pd
import numpy as np
import itertools
from dateutil.relativedelta import relativedelta
from scipy import optimize as optim
import datetime as dt

import common_library.error as error
import common_library.date_utils as dm
from common_library.error import PlataformError
from common_library.precia_logger import setup_logging, create_log_msg

logger = setup_logging()

def nearest_value(vector, num):
    """
    Encontrar el valor dentro de un vector mas cercano a un numero dado
    :param vector: (array) Vector
    :param num: (int,float) Numero unico
    """
    idx = (np.abs(vector - num)).argmin()
    return vector[idx]

def rd(x, y=0):
    """
    Un redondeo matemático clasico
    Autor: Voznica
    Fecha: 2021-04-19
    :param x: (float) Numero
    :param y: (int) Numeor de decimales a redondear
    :return:
    """
    try:
        m = int('1'+'0' * y) # multiplier - how many positions to the right
        q = round(x*m, 2) # shift to the right by multiplier
        c = int(q) # new number
        i = int( (q-c)*10 ) # indicator number on the right
        if i >= 5:
            c += 1
    except (Exception,) as sec_exc:
        error_msg = "Se ha presentado un error ejecutando la funcion rd"
        logger.error(create_log_msg(error_msg))
        raise PlataformError(error_msg) from sec_exc
    return c/m

rd_vec = np.vectorize(rd)
   
def bond_flows(data):
    """
    Esta función genera una organizacion de condiciones faciales de un solo titulo de manera vectorizada.
    Autor: Laura Natalia Lopez <llopez@precia.co>
    Fecha: 2021-07-14 (Mod 2021-11-25)
    :param data: (dict) Contiene la informacion de mercado para el dia de valoracion
            con informacion obligatoria:
                date_ini: Fecha de valoracin en dt.date (se convierte en np.array)
                ytm: Tasas de interes (TIR) de los titulos float (se convierte en np.array)
                mat_t: Fechas de vencimiento de los titulos str dd/mm/Y (se convierte en np.array)
                cpn: cupones de los titulos en np.array (en %) float (se convierte en np.array)
                    [pueden ser totales o cupones actuales (index+spread)]
                noc: valor del nocional de los titulos float (se convierte en np.array)
                base: base del denominador del conteo de dias, puede ser 365, 360, 366, etc,
                    o 'Act' para hacer un conteo 365 y 366 si es bisiesto (int o str) np.array
                base_num: '356' es Act/base NL, 'Act' es Act/base, '30' es 30/base str (se convierte en np.array)
                freq_months: cada cuantos meses paga cupon int (se convierte en np.array)
                cpn_complete: booleano que determina si cpn es el cupon completo (True) o es el spread (False)
                            (se convierte en np.array)
            con informacion opcional:
                - Si en cpn_complete any False, es necesario, para todos los titulos:
                    issue_t: fecha de emision en dt.date
                    rate_type: Informacion de tipo de tasa de los titulos str (se convierte en np.array)
                    rate_expr:  Expresion de la tasa 'EFE' para efectiva, 'NOM 'para nominal en str np.array
                            (Si se tiene un rate_type DTF y un rate_expr de 'NOM' se asume que el cpn del titulo es NATA,
                            por el contrario, si es un rate_type DTF con el cpn ajustado a efectivo vencido, debe usarse el rate_expr 'EFE'.
                            En el caso de que se calcule el cupon previo para un rate_type DTF, no importa la convencion rate_expr, siempre
                            se calculara como un NATA)
                    spread: parte del cupon que es un spread fijo sobre el indice float (se convierte en np.array)
                    rate_use: Informacion si los titulos utilzan tasa previa P o actual A str (se convierte en np.array)
                    index_hist: Informacion historica de los indices con 3 columnas rate_type, rate_date, value_rate
    :return:(dict) Contiene la informacion:
            mat: Dias a vencimiento anualizados np.array
            flows: matriz de pago de cupones np.array
            term: dias al vencimiento con convencion de conteo de dias
            term_desc: dias al vencimiento con convencion Act NL/365 para la de descuento/curva cero cupon
            accrued_interest: cupon corrido np.array
            failed_instr_pos: posicion de los titulos a los cuales no se les puede construir matriz
    """
    try:
        date_ini = np.array(data['date_ini'])
        mat_t = np.array(data['mat_t'])
        cpn = np.array(data['cpn'])
        noc = np.array(data['noc'])
        base = np.array(data['base'])
        base_num = np.array(data['base_num'])
        freq_months = np.array(data['freq_months'])
        cpn_complete = np.array(data['cpn_complete'])

        if cpn.size != noc.size or cpn.size != mat_t.size:
            logger.error('Las dimensiones de la información sobre cupon, nocional y madurez no son consistentes')
            error_message = 'Las dimensiones de la información sobre cupon, nocional y madurez no son consistentes'
            raise PlataformError(error_message=error_message)
        if base.size != base_num.size or base_num.size != freq_months.size:
            logger.error('Las dimensiones de la información sobre base, base_num y freq_months no son consistentes')
            error_message = 'Las dimensiones de la información sobre base, base_num y freq_months no son consistentes'
            raise PlataformError(error_message=error_message)
        # traer la informacion  historica de los indices
        if (cpn_complete == False).any():
            try:
                index_hist = data['index_hist']
            except Exception as e:
                logger.error(
                    'Si cpn_complete tiene any Flase, debe especificar index_hist, rate_use, rate_type ')
                error_message = 'Si cpn_complete tiene any Flase, debe especificar index_hist, rate_use, rate_type '
                raise PlataformError(error_message=error_message)
        # Calculando plazos, flujos y cupon corrido
        out1 = [[0]] * mat_t.size
        out2 = [[0]] * mat_t.size
        out3 = [[0]] * mat_t.size
        out4 = [[0]] * mat_t.size
        out5 = [[0]] * mat_t.size
        out6 = []  # ubicacion de los titulos que fallan
        for i in range(0, cpn.size):
            try:
                if noc != 0:
                    mat = dt.datetime.strptime(str(mat_t), '%d/%m/%Y').date()
                    days_diff = mat - date_ini
                if freq_months == 0:  # PV
                    try:
                        issue_t = data['issue_t']
                        coupon_dates = np.array([issue_t, dt.datetime.strptime(str(mat_t), '%d/%m/%Y').date()])
                        prev_coupon = issue_t
                    except:
                        coupon_dates = np.array([data['date_ini'], dt.datetime.strptime(str(mat_t), '%d/%m/%Y').date()])
                    future_coupon_dates = coupon_dates[coupon_dates > date_ini]
                    future_coupon_dates = np.sort(future_coupon_dates)
                else:
                    # Se generan flujos mensuales que se saltan cada data['freq_months'] meses (MV, BV, TV, SV, AV)
                    flow = days_diff.days / 30 + 24
                    try:
                        issue_t = data['issue_t']
                        flow = (mat - issue_t).days / 30 + 24
                    except:
                        issue_t = np.array([mat - relativedelta(months=+x) for x in range(0, int(flow), freq_months)])[
                            -1]
                    coupon_dates = np.array \
                            ([issue_t + relativedelta(months=+x) for x in range(0 ,int(flow) ,freq_months)])
                    coupon_dates[coupon_dates > mat] = mat
                    #### Para ajustar las fechas y el cupon irregular:
                    # Seleccionar solo las fechas antes del vencimiento
                    coupon_dates = np.unique(coupon_dates)
                    # Seleccionar la fecha del penultimo pago, segun la fecha de vencimiento y la frecuencia de pago
                    prev_coupon_period =(coupon_dates[-1]- relativedelta(months=+freq_months))
                    ## Ajustar la fecha del penultimo pago (si la fecha de vencimiento cae en un mes que no se encuentra en la muestra)
                    if freq_months!=1:
                        #Se realiza para las frecuencias de pago diferentes a 1 mes, debido a que si es mensual, siempre estara en la muestra
                        # Extraer la fecha mas cercano a la 'penultima fecha de pago' (es diferente a la muestra los meses de la muestra
                        # cuando el mes de la fecha de vencimiento no esta en la muestra de meses pagados)
                        prev_coupon_period = nearest_value(coupon_dates, prev_coupon_period)
                    # Determinar cuando deberia ser el penultimo pago de cupon, segun el penultimo mes
                    bool_array = [(coupon_dates)[k].month == prev_coupon_period.month  for k in range(0, len(coupon_dates))]
                    #Seleccionar la ultima fecha del mes de pago del penultimo cupon.
                    prev_coupon_pos =  np.where(bool_array)[0][-1]
                    if freq_months>=12:
                        # Si la frecuencia de pagos de cupon es anual, puede que el mes sea el mismo pero los dias no.
                        # Determinar si el ultimo dia y mes es diferente
                        day_pays = np.array([(coupon_dates)[k].day for k in range(0, len(coupon_dates))])
                        months_pays = np.array([(coupon_dates)[k].month for k in range(0, len(coupon_dates))])
                        last_day = day_pays[-1]
                        prev_day = day_pays[-2]
                        last_month = months_pays[-1]
                        prev_month = months_pays[-2]
                        if last_day > prev_day and last_month>=prev_month:
                            #Solo en el caso de que el ultimo mes sea mayor o igual al mes del pago anterior
                            #y los dias sean mayores, se debe alargar el cupon.
                            mensual_days_pays = day_pays[0]
                            bool_day = [(coupon_dates)[k].day == mensual_days_pays  for k in range(0, len(coupon_dates))]
                            # Seleccionar la fecha del penultimo cupon
                            prev_day_pos =  np.where(bool_day)[0][-1]
                            #Si estamos con frecuencia de pago anual
                            coupon_dates[prev_day_pos] = mat
                    else:
                        coupon_dates[prev_coupon_pos+1] = mat
                    coupon_dates = np.unique(coupon_dates)
                    ### Traer informecion del cupon anterior
                    try:
                        prev_coupon = coupon_dates[coupon_dates<=date_ini][-1]
                    except:
                        prev_coupon = issue_t
                    coupon_dates = coupon_dates[coupon_dates>=prev_coupon]
                    future_coupon_dates = coupon_dates[coupon_dates >date_ini]
                    future_coupon_dates = np.sort(future_coupon_dates)
                date_manager = dm.DateUtils()
                if base_num == 'Act':
                    accrued_days = (date_ini - prev_coupon).days
                    term_ = (future_coupon_dates - date_ini)
                    term = [term_[x].days for x in range(0, term_.size)]
                    ext_term_ = (coupon_dates - prev_coupon)
                    ext_term = [ext_term_[x].days for x in range(0, ext_term_.size)]
                    coupon_days_diff = [np.diff(coupon_dates)[x].days for x in range(0, coupon_dates.size - 1)]
                    if base != 'Act':
                        delta = [coupon_days_diff[-future_coupon_dates.size:][x] /base for x in range(0 ,future_coupon_dates.size)]
                    else:
                        base_bool= [366 if date_manager.is_leap(future_coupon_dates[x].year) else 365 for x in range(0 ,future_coupon_dates.size) ]
                        delta = [coupon_days_diff[-future_coupon_dates.size:][x] /base_bool[x] for x in range(0 ,future_coupon_dates.size)]
                elif base_num == '365':
                    accrued_days = date_manager.days_non_leap(prev_coupon, data['date_ini'])
                    term = [date_manager.days_non_leap(date_ini, future_coupon_dates[x]) for x in
                            range(0, future_coupon_dates.size)]
                    ext_term = [date_manager.days_non_leap(prev_coupon, coupon_dates[x]) for x in
                                range(0, coupon_dates.size)]
                    term_diff = [np.diff(ext_term)[x] for x in range(0, len(ext_term) - 1)]
                    delta = [term_diff[x] / base for x in range(0, len(term_diff))]
                    if base != 'Act':
                            delta = [term_diff[x ] /base for x in range(0 ,len(term_diff))]
                    else:
                        base_bool= [366 if date_manager.is_leap(future_coupon_dates[x].year) else 365 for x in range(0 ,future_coupon_dates.size) ]
                        delta = [term_diff[x ] /base_bool[x] for x in range(0 ,len(term_diff))]
                elif base_num == '30':
                    accrued_days = date_manager.days_30_co(prev_coupon, data['date_ini'])
                    term = [date_manager.days_30_co(data['date_ini'], future_coupon_dates[x]) for x in
                            range(0, future_coupon_dates.size)]
                    ext_term = [date_manager.days_30_co(prev_coupon, coupon_dates[x]) for x in
                                range(0, coupon_dates.size)]
                    term_diff = [np.diff(ext_term)[x] for x in range(0, len(ext_term) - 1)]
                    if base != 'Act':
                        delta = [term_diff[x ] /base for x in range(0 ,len(term_diff))]
                    else:
                        base_bool= [366 if date_manager.is_leap(future_coupon_dates[x].year) else 365 for x in range(0 ,future_coupon_dates.size) ]
                        delta = [term_diff[x ] /base_bool[x] for x in range(0 ,len(term_diff))]
                else:
                    logger.info('Esta funcion solo soporta conteo de dias 30, Act NL y Act')
                    out6.append(i)
                    continue
                if len(delta)==0:
                        logger.info('El calculo de las fechas no es adecuado, ya que el delta del cupon sale vacio')
                        out6.append(i)
                        continue
                # Generar los dias al vencimiento anualizados con Act NL/365 para las curvas cero cupon
                # En el caso de titulos con conteo de dias Act NL/365, term y term_desc son iguales
                term_desc = [date_manager.days_non_leap(date_ini, future_coupon_dates[x]) for x in
                             range(0, future_coupon_dates.size)]
                anual_term = [term_desc[x] / 365 for x in range(0, len(
                    term_desc))]  ## Para calcular el descuento, se usa un conteo de dias Act NL/ 365
                #  Calculando cupones de cada título
                try:
                    rate_expr = np.array(data['rate_expr'])
                    rate_type = np.array(data['rate_type'])
                    if rate_expr == 'EFE':  # Tasa efectiva
                        cf = ((1 + cpn / 100) ** np.array(delta) - 1)
                    elif rate_type[i] == 'DTF' and rate_expr[
                        i] == 'NOM':  # Si es DTF es NATA, hay que pasarlo a Efectivo
                        efective_rate_ant = (cpn[i] / 100) / 4
                        efective_rate = efective_rate_ant / (1 - efective_rate_ant)
                        cpn_adj = ((1 + efective_rate) ** 4 - 1) * 100
                        cf = ((1 + cpn_adj / 100) ** np.array(delta) - 1)  # Termina siendo tasa efectiva
                    elif rate_expr == 'NOM':  # Tasa Nominal
                        cf = cpn * np.array(delta) / 100
                    else:
                        logger.info(
                            'La informacion de rate_expression no es la adecuada: debe ser EFE o NOM del titulo con maturity_date ' + str(
                                mat_t))
                        out6.append(i)
                        continue
                except:
                    # Si no se especifica expresion de la tasa, se toma efectiva
                    cf = ((1 + cpn / 100) ** np.array(delta) - 1)
                # Para los títulos con tasa previa, se ajusta el primer cupon
                if (cpn_complete == False).any():
                    try:
                        rate_use = np.array(data['rate_use'])
                        rate_type = np.array(data['rate_type'])
                        index_inst = index_hist[index_hist['RATE_TYPE'] == str(rate_type)]
                        spread = np.array(data['spread'])
                        rate_expr = np.array(data['rate_expr'])
                        if rate_use == 'P' and rate_type == 'FS':
                            logger.info('El titulo con maturity_date ' + str(
                                mat_t) + ' tiene rate_use P y rate_type FS, se asume A ')
                        elif rate_use == 'P':
                            index_prev = index_inst['RATE_VALUE'][index_inst['RATE_DATE'] == prev_coupon]
                            if len(index_prev) == 0:
                                logger.error('No existe informacion del indice ' + str(rate_type) + ' para el ' + str(
                                    prev_coupon))
                                out6.append(i)
                                continue
                            try:
                                if rate_type == 'DTF':  # Si es DTF siempre se asume NATA, hay que pasarlo a Efectivo
                                    efective_rate_ant = (spread / 100 + np.array(index_prev) / 100) / 4
                                    efective_rate = efective_rate_ant / (1 - efective_rate_ant)
                                    cpn_adj = ((1 + efective_rate) ** 4 - 1) * 100
                                    cpn_prev = ((1 + cpn_adj / 100) ** np.array(
                                        delta[0]) - 1)  # Termina siendo tasa efectiva
                                elif rate_type == 'DTE':  # Si es DTE es EFE, sin mebargo, por metdologia, se suma directo con el spread
                                    cpn_cal = spread + np.array(index_prev)
                                    cpn_prev = ((1 + cpn_cal / 100) ** np.array(delta[0]) - 1)
                                elif rate_expr == 'EFE':  # Tasa efectiva
                                    cpn_cal = ((spread / 100 + 1) * (1 + np.array(index_prev) / 100) - 1) * 100
                                    cpn_prev = ((1 + cpn_cal / 100) ** np.array(delta[0]) - 1)
                                elif rate_expr == 'NOM':  # Tasa Nominal
                                    cpn_cal = spread + np.array(index_prev)
                                    cpn_prev = cpn_cal * np.array(delta[0]) / 100
                                else:
                                    logger.info(
                                        'La informacion de rate_expression no es la adecuada: debe ser EFE o NOM del titulo con maturity_date ' + str(
                                            mat_t))
                                    out6.append(i)
                                    continue
                            except:
                                # Si no se especifica expresion de la tasa, se toma efectiva
                                cpn_cal = ((spread / 100 + 1) * (1 + np.array(index_prev) / 100) - 1) * 100
                                cpn_prev = ((1 + cpn_cal / 100) ** np.array(delta[0]) - 1)
                            cf[0] = cpn_prev
                        elif rate_use != 'P' and rate_use != 'A':
                            logger.info(
                                'La informacion de use_rate no es la adecuada: debe ser P o A del titulo con maturity_date ' + str(
                                    mat_t))
                            out6.append(i)
                            continue
                    except NameError as e:
                        logger.error(
                            'Si cpn_complete tiene any, debe especificar index_hist, rate_use, rate_type ')
                        logger.error(e)
                        error_message = 'Si cpn_complete tiene any, debe especificar index_hist, rate_use, rate_type '
                        raise PlataformError(error_message=error_message)
                cf_noc = rd_vec(cf.copy(),6)
                cf_noc[cf_noc.size - 1] = cf_noc[cf_noc.size - 1] + noc
                # Calculado accrued interest
                accrued_int = [cf[0] * accrued_days * 100 / np.diff(ext_term)[0]]
                # Almacenando información
                out1[i] = term  # conteo de dias con la convencion del titulo
                out2[i] = cf_noc  # vector de cupones del titulo
                out3[i] = anual_term  # dias anualizados para descuento con convencion Act NL / 365
                out4[i] = accrued_int  # cupon corrido del titulo
                out5[i] = term_desc  # conteo de dias con convencion Act NL / 365
            except:
                logger.info(
                    'Se genero un error en el calculo de cupones y cupon corrido del titulo con maturity_date ' + str(
                        mat_t) + ' ubicacion en la matriz ' + str(i))
                out6.append(i)
                continue
        # Definiendo dimensiones del resultado
        time_desc = np.sort(np.unique(list(itertools.chain.from_iterable(out5))))
        cpn_days = np.sort(np.unique(list(itertools.chain.from_iterable(out3))))
        time = np.sort(np.unique(list(itertools.chain.from_iterable(out1))))
        accrued_interest = np.array(list(itertools.chain.from_iterable(out4)))
        bonds = cpn.size
        flows = np.zeros((cpn_days.size, bonds))
        flows = pd.DataFrame(flows)
        # Construyendo matriz
        for j in range(0, cpn.size):
            # flows.iloc[np.in1d(time, out1[j]),j] = out2[j]
            flows.iloc[np.in1d(cpn_days, out3[j]), j] = out2[j]
        ##  En caso de que falle algun titulo, se tendran valores de cero en plazos, hay que eliminarlos
        flows = flows[(flows.T != 0).any()].reset_index(drop=True)
        flows = np.array(flows)
        time_desc = time_desc[time_desc != 0]
        cpn_days = cpn_days[cpn_days != 0]
        time = time[time != 0]
        accrued_interest[accrued_interest <= 0] = 0

        out = dict({
            'mat': cpn_days,  # Dias anualizados para el descuento del cupon Act NL/365
            'flows': flows,  # Matriz de plazos con valor de cupones para cada titulo
            'terms': time,  # Dias de pago de los cupones y titulo
            'terms_desc': time_desc,  # Dias de pago del titulo en Act NL/365 para curva de descuento
            'accrued_interest': accrued_interest,  # Cupon corrido para los titulos
            'failed_instr_pos': out6  # ubicacion de los titulos que fallan
        })
    except ValueError as e:
        logger.error('Se genero un error en la funcion bond_flows ')
        logger.error(e)
        
    except NameError as e:
        logger.error('Se genero un error en la funcion bond_flows ')
        logger.error(e)
        
    except AttributeError  as e:
        logger.error('Se genero un error en la funcion bond_flows ')
        logger.error(e)
        
    except TypeError as e:
        logger.error('Se genero un error en la funcion bond_flows ')
        logger.error(e)
       
    except IndexError as e:
        logger.error('Se genero un error en la funcion bond_flows ')
        logger.error(e)
        
    except Exception as e:
        logger.error('Se genero un error en la funcion bond_flows ')
        logger.error(e)
        
    return out

def bond_flows_m(data):
    """
    Esta función genera una organizacion de condiciones faciales de los titulos de manera vectorizada conjunta.
    Autor: Laura Natalia Lopez <llopez@precia.co>
    Fecha: 2021-07-14 (Mod 2021-11-25)
    :param data: (dict) Contiene la informacion de mercado para el dia de valoracion
            con informacion obligatoria:
                date_ini: Fecha de valoracin en dt.date (se convierte en np.array)
                ytm: Tasas de interes (TIR) de los titulos en np.array
                mat_t: Fechas de vencimiento de los titulos en np.array con str 'dd/mm/Y'
                cpn: cupones de los titulos en np.array (en %) [pueden ser totales o cupones actuales (index+spread)]
                noc: valor del nocional de los titulos en np.array
                base: base del denominador del conteo de dias, puede ser 365, 360, 366, etc,
                    o 'Act' para hacer un conteo 365 y 366 si es bisiesto (int o str) np.array
                base_num: '356' es Act/base NL, 'Act' es Act/base, '30' es 30/base en string np.array
                freq_months: cada cuantos meses paga cupon en int np.array
                cpn_complete: np.array booleano que determina si cpn es el cupon completo (True) o es el spread (False)
            con informacion opcional:
                - Si en cpn_complete any False, es necesario, para todos los titulos:
                    issue_t: fecha de emision en dt.date np.array
                    rate_type: Informacion de tipo de tasa de los titulos en str np.array
                    rate_expr:  Expresion de la tasa 'EFE' para efectiva, 'NOM 'para nominal en string np.array
                            (Si se tiene un rate_type DTF y un rate_expr de 'NOM' se asume que el cpn del titulo es NATA,
                             por el contrario, si es un rate_type DTF con el cpn ajustado a efectivo vencido, debe usarse el rate_expr 'EFE'.
                            En el caso de que se calcule el cupon previo para un rate_type DTF, no importa la convencion rate_expr, siempre
                            se calculara como un NATA)
                    spread: parte del cupon que es un spread fijo sobre el indice en float np.array
                    rate_use: Informacion si los titulos utilzan tasa previa P o actual A en str np.array
                    index_hist: Informacion historica de los indices con 3 columnas rate_type, rate_date, value_rate
    :return: (dict) Contiene la informacion:
            mat: Dias a vencimiento anualizados np.array
            flows: matriz de pago de cupones np.array 2D
            term: dias al vencimiento con convencion de conteo de dias np.array
            term_desc: dias al vencimiento con convencion Act NL/365 para la de descuento/curva cero cupon
            accrued_interest: cupon corrido np.array
            failed_instr_pos: posicion de los titulos a los cuales no se les puede construir matriz
    """
    try:
        try:
            len(data['cpn'])
        except:
            out = bond_flows(data)
        else:
            date_ini = np.array(data['date_ini'])
            mat_t = np.array(data['mat_t'])
            cpn = np.array(data['cpn'])
            noc = np.array(data['noc'])
            base = np.array(data['base'])
            base_num = np.array(data['base_num'])
            freq_months = np.array(data['freq_months'])
            cpn_complete = np.array(data['cpn_complete'])

            if cpn.size != noc.size or cpn.size != mat_t.size:
                logger.error('Las dimensiones de la información sobre cupon, nocional y madurez no son consistentes')
                error_message = 'Las dimensiones de la información sobre cupon, nocional y madurez no son consistentes'
                raise PlataformError(error_message=error_message)
            if base.size != base_num.size or base_num.size != freq_months.size:
                logger.error \
                    ('Las dimensiones de la información sobre base, base_num y freq_months no son consistentes')
                error_message = 'Las dimensiones de la información sobre base, base_num y freq_months no son consistentes'
                raise PlataformError(error_message=error_message)
            # traer la informacion  historica de los indices
            if (cpn_complete == False).any():
                try:
                    index_hist = data['index_hist']
                except Exception as e:
                    logger.error('Si cpn_complete tiene any False, debe especificar index_hist, rate_use, rate_type  ' +e.__doc__)
                    logger.error(e)
                    error_message = 'Si cpn_complete tiene any False, debe especificar index_hist, rate_use, rate_type'
                    raise PlataformError(error_message=error_message)
            # Calculando plazos, flujos y cupon corrido
            out1 = [[0] ] *mat_t.size
            out2 = [[0] ] *mat_t.size
            out3 = [[0] ] *mat_t.size
            out4 = [[0] ] *mat_t.size
            out5 = [[0] ] *mat_t.size
            out6 = [] # ubicacion de los titulos que fallan
            for i in range(0 ,cpn.size):
                try:
                    if noc[i] != 0:
                        mat = dt.datetime.strptime(mat_t[i] ,'%d/%m/%Y').date()
                        days_diff = mat -date_ini
                    if freq_months[i] == 0: # PV
                        try:
                            issue_t = data['issue_t']
                            issue_t = issue_t[i]
                            coupon_dates = np.array([issue_t ,dt.datetime.strptime(mat_t[i] ,'%d/%m/%Y').date()])
                            prev_coupon = issue_t
                        except:
                            coupon_dates = np.array \
                                ([data['date_ini'] ,dt.datetime.strptime(mat_t[i] ,'%d/%m/%Y').date()])
                        future_coupon_dates = coupon_dates[coupon_dates >date_ini]
                        future_coupon_dates = np.sort(future_coupon_dates)
                    else:
                        # Se generan flujos mensuales que se saltan cada data['freq_months'] meses (MV, BV, TV, SV, AV)
                        flow = days_diff.days /30 +24
                        try:
                            issue_t = data['issue_t']
                            issue_t = issue_t[i]
                            flow = (mat - issue_t).days /30 +24
                        except:
                            issue_t = np.array([mat - relativedelta(months=+x) for x in range(0 ,int(flow) ,freq_months[i])])[-1]
                        coupon_dates = np.array \
                            ([issue_t + relativedelta(months=+x) for x in range(0 ,int(flow) ,freq_months[i])])
                        coupon_dates[coupon_dates > mat] = mat
                        #### Para ajustar las fechas y el cupon irregular:
                        # Seleccionar solo las fechas antes del vencimiento
                        coupon_dates = np.unique(coupon_dates)
                        # Seleccionar la fecha del penultimo pago, segun la fecha de vencimiento y la frecuencia de pago
                        prev_coupon_period =(coupon_dates[-1]- relativedelta(months=+freq_months[i]))
                        ## Ajustar la fecha del penultimo pago (si la fecha de vencimiento cae en un mes que no se encuentra en la muestra)
                        if freq_months[i]!=1:
                            #Se realiza para las frecuencias de pago diferentes a 1 mes, debido a que si es mensual, siempre estara en la muestra
                            # Extraer la fecha mas cercano a la 'penultima fecha de pago' (es diferente a la muestra los meses de la muestra
                            # cuando el mes de la fecha de vencimiento no esta en la muestra de meses pagados)
                            prev_coupon_period = nearest_value(coupon_dates, prev_coupon_period)
                        # Determinar cuando deberia ser el penultimo pago de cupon, segun el penultimo mes
                        bool_array = [(coupon_dates)[k].month == prev_coupon_period.month  for k in range(0, len(coupon_dates))]
                        #Seleccionar la ultima fecha del mes de pago del penultimo cupon.
                        prev_coupon_pos =  np.where(bool_array)[0][-1]
                        if freq_months[i]>=12:
                            # Si la frecuencia de pagos de cupon es anual, puede que el mes sea el mismo pero los dias no.
                            # Determinar si el ultimo dia y mes es diferente
                            day_pays = np.array([(coupon_dates)[k].day for k in range(0, len(coupon_dates))])
                            months_pays = np.array([(coupon_dates)[k].month for k in range(0, len(coupon_dates))])
                            last_day = day_pays[-1]
                            prev_day = day_pays[-2]
                            last_month = months_pays[-1]
                            prev_month = months_pays[-2]
                            if last_day > prev_day and last_month>=prev_month:
                                #Solo en el caso de que el ultimo mes sea mayor o igual al mes del pago anterior
                                #y los dias sean mayores, se debe alargar el cupon.
                                mensual_days_pays = day_pays[0]
                                bool_day = [(coupon_dates)[k].day == mensual_days_pays  for k in range(0, len(coupon_dates))]
                                # Seleccionar la fecha del penultimo cupon
                                prev_day_pos =  np.where(bool_day)[0][-1]
                                #Si estamos con frecuencia de pago anual
                                coupon_dates[prev_day_pos] = mat
                        else:
                            coupon_dates[prev_coupon_pos+1] = mat
                        coupon_dates = np.unique(coupon_dates)
                        ### Traer informecion del cupon anterior
                        try:
                            prev_coupon = coupon_dates[coupon_dates<=date_ini][-1]
                        except:
                            prev_coupon = issue_t
                        coupon_dates = coupon_dates[coupon_dates>=prev_coupon]
                        future_coupon_dates = coupon_dates[coupon_dates >date_ini]
                        future_coupon_dates = np.sort(future_coupon_dates)
                    date_manager = dm.DateUtils()
                    if base_num[i] == 'Act':
                        accrued_days = (date_ini -prev_coupon).days
                        term_ = (future_coupon_dates -date_ini)
                        term = [ term_[x].days for x in range(0 ,term_.size)]
                        ext_term_ = (coupon_dates -prev_coupon)
                        ext_term = [ ext_term_[x].days for x in range(0 ,ext_term_.size)]
                        coupon_days_diff = [np.diff(coupon_dates)[x].days for x in range(0 ,coupon_dates.size -1)]
                        if base[i] != 'Act':
                            delta = [coupon_days_diff[-future_coupon_dates.size:][x] /base[i] for x in range(0 ,future_coupon_dates.size)]
                        else:
                            base_bool= [366 if date_manager.is_leap(future_coupon_dates[x].year) else 365 for x in range(0 ,future_coupon_dates.size) ]
                            delta = [coupon_days_diff[-future_coupon_dates.size:][x] /base_bool[x] for x in range(0 ,future_coupon_dates.size)]
                    elif base_num[i] == '365':
                        accrued_days = date_manager.days_non_leap(prev_coupon ,data['date_ini'])
                        term = [date_manager.days_non_leap(date_ini ,future_coupon_dates[x]) for x in range(0 ,future_coupon_dates.size)]
                        ext_term = [date_manager.days_non_leap(prev_coupon ,coupon_dates[x]) for x in range(0 ,coupon_dates.size)]
                        term_diff = [np.diff(ext_term)[x] for x in range(0 ,len(ext_term ) -1)]
                        if base[i] != 'Act':
                            delta = [term_diff[x ] /base[i] for x in range(0 ,len(term_diff))]
                        else:
                            base_bool= [366 if date_manager.is_leap(future_coupon_dates[x].year) else 365 for x in range(0 ,future_coupon_dates.size) ]
                            delta = [term_diff[x ] /base_bool[x] for x in range(0 ,len(term_diff))]
                    elif base_num[i] == '30':
                        accrued_days = date_manager.days_30_co(prev_coupon ,data['date_ini'])
                        term = [date_manager.days_30_co(data['date_ini'] ,future_coupon_dates[x]) for x in range(0 ,future_coupon_dates.size)]
                        ext_term = [date_manager.days_30_co(prev_coupon ,coupon_dates[x]) for x in range(0 ,coupon_dates.size)]
                        term_diff = [np.diff(ext_term)[x] for x in range(0 ,len(ext_term ) -1)]
                        if base[i] != 'Act':
                            delta = [term_diff[x ] /base[i] for x in range(0 ,len(term_diff))]
                        else:
                            base_bool= [366 if date_manager.is_leap(future_coupon_dates[x].year) else 365 for x in range(0 ,future_coupon_dates.size) ]
                            delta = [term_diff[x ] /base_bool[x] for x in range(0 ,len(term_diff))]
                    else:
                        logger.info('Esta funcion solo soporta conteo de dias 30, Act NL y Act')
                        out6.append(i)
                        continue
                    if len(delta)==0:
                        logger.info('El calculo de las fechas no es adecuado, ya que el delta del cupon sale vacio')
                        out6.append(i)
                        continue
                    # Generar los dias al vencimiento anualizados con Act NL/365 para las curvas cero cupon
                    # En el caso de titulos con conteo de dias Act NL/365, term y term_desc son iguales
                    term_desc = [date_manager.days_non_leap(date_ini ,future_coupon_dates[x]) for x in range(0 ,future_coupon_dates.size)]
                    anual_term = [term_desc[x ] /365 for x in range(0, len
                        (term_desc))] ## Para calcular el descuento, se usa un conteo de dias Act NL/ 365
                    #  Calculando cupones de cada título
                    try:
                        rate_expr = np.array(data['rate_expr'])
                        rate_type = np.array(data['rate_type'])
                        if rate_expr[i ]=='EFE':  # Tasa efectiva ()
                            cf = (( 1 +cpn[i ] /100 )**np.array(delta ) -1)
                        elif rate_type[i] == 'DTF' and rate_expr[i] == 'NOM':  # Si es DTF es NATA, hay que pasarlo a Efectivo
                            efective_rate_ant = (cpn[i ] /100 ) /4
                            efective_rate = efective_rate_ant /( 1 -efective_rate_ant)
                            cpn_adj = (( 1 +efective_rate )** 4 -1 ) *100
                            cf = (( 1 +cpn_adj /100 )**np.array(delta ) -1)  # Termina siendo tasa efectiva
                        elif rate_expr[i ]=='NOM':  # Tasa Nominal
                            cf = cpn[i ] *np.array(delta ) /100
                        else:
                            logger.info \
                                ('La informacion de rate_expression no es la adecuada: debe ser EFE o NOM del titulo con maturity_date  '+ str
                                    (mat_t[i]))
                            out6.append(i)
                            continue
                    except:
                        # Si no se especifica expresion de la tasa, se toma efectiva
                        cf = (( 1 +cpn[i ] /100 )**np.array(delta ) -1)*100
                    # Para los títulos con tasa previa, se ajusta el primer cupon
                    if (cpn_complete == False).any():
                        try:
                            rate_use = np.array(data['rate_use'])
                            rate_type = np.array(data['rate_type'])
                            index_inst = index_hist[index_hist['RATE_TYPE'] == rate_type[i]]
                            spread = np.array(data['spread'])
                            rate_expr = np.array(data['rate_expr'])
                            if rate_use[i ]=='P' and rate_type[i] == 'FS':
                                logger.info('El titulo con maturity_date  '+ str
                                    (mat_t[i]) +' tiene rate_use P y rate_type FS, se asume A ')
                            elif rate_use[i] == 'P':
                                index_prev = index_inst['RATE_VALUE'][index_inst['RATE_DATE'] == prev_coupon]
                                if len(index_prev) == 0:
                                    logger.info(
                                        'No existe informacion del indice ' + str(rate_type[i]) + ' para el ' + str(
                                            prev_coupon))
                                    out6.append(i)
                                    continue
                                try:
                                    if rate_type[
                                        i] == 'DTF':  # Si es DTF siempre se asume NATA, hay que pasarlo a Efectivo
                                        efective_rate_ant = (spread[i] / 100 + np.array(index_prev) / 100) / 4
                                        efective_rate = efective_rate_ant / (1 - efective_rate_ant)
                                        cpn_adj = ((1 + efective_rate) ** 4 - 1) * 100
                                        cpn_prev = ((1 + cpn_adj / 100) ** np.array(
                                            delta[0]) - 1)  # Termina siendo tasa efectiva
                                    elif rate_type[
                                        i] == 'DTE':  # Si es DTE es EFE, sin mebargo, por metdologia, se suma directo con el spread
                                        cpn_cal = spread[i] + np.array(index_prev)
                                        cpn_prev = ((1 + cpn_cal / 100) ** np.array(delta[0]) - 1)
                                    elif rate_expr[i] == 'EFE':  # Tasa efectiva
                                        cpn_cal = ((spread[i] / 100 + 1) * (1 + np.array(index_prev) / 100) - 1) * 100
                                        cpn_prev = ((1 + cpn_cal / 100) ** np.array(delta[0]) - 1)
                                    elif rate_expr[i] == 'NOM':  # Tasa Nominal
                                        cpn_cal = spread[i] + np.array(index_prev)
                                        cpn_prev = cpn_cal * np.array(delta[0]) / 100
                                    else:
                                        logger.info(
                                            'La informacion de rate_expression no es la adecuada: debe ser EFE o NOM del titulo con maturity_date ' + str(
                                                mat_t[i]))
                                        out6.append(i)
                                        continue
                                except:
                                    # Si no se especifica expresion de la tasa, se toma efectiva
                                    cpn_cal = ((spread[i] / 100 + 1) * (1 + np.array(index_prev) / 100) - 1) * 100
                                    cpn_prev = ((1 + cpn_cal / 100) ** np.array(delta[0]) - 1)
                                cf[0] = cpn_prev
                            elif rate_use[i] != 'P' and rate_use[i] != 'A':
                                logger.info(
                                    'La informacion de use_rate no es la adecuada: debe ser P o A del titulo con maturity_date ' + str(
                                        mat_t[i]))
                                out6.append(i)
                                continue
                        except NameError as e:
                            logger.error(
                                'Si cpn_complete tiene any False, debe especificar index_hist, rate_use, rate_type ')
                            logger.error(e)
                            error_message = "Si cpn_complete tiene any False, debe especificar index_hist, rate_use, rate_type"
                            raise PlataformError(error_message=error_message)
                    cf_noc = rd_vec(cf.copy(),6)
                    cf_noc[cf_noc.size - 1] = cf_noc[cf_noc.size - 1] + noc[i]
                    # Calculado accrued interest
                    accrued_int = [cf[0] * accrued_days * 100 / np.diff(ext_term)[0]]
                    # Almacenando información
                    out1[i] = term  # conteo de dias con la convencion del titulo
                    out2[i] = cf_noc  # vector de cupones del titulo
                    out3[i] = anual_term  # dias anualizados para descuento con convencion Act NL / 365
                    out4[i] = accrued_int  # cupon corrido del titulo
                    out5[i] = term_desc  # conteo de dias con convencion Act NL / 365
                except:
                    logger.info(
                        'Se genero un error en el calculo de cupones y cupon corrido del titulo con maturity_date ' + str(
                            mat_t[i]) + ' ubicacion en la matriz ' + str(i))
                    out6.append(i)
                    continue
            # Definiendo dimensiones del resultado
            time_desc = np.sort(np.unique(list(itertools.chain.from_iterable(out5))))
            cpn_days = np.sort(np.unique(list(itertools.chain.from_iterable(out3))))
            time = np.sort(np.unique(list(itertools.chain.from_iterable(out1))))
            accrued_interest = np.array(list(itertools.chain.from_iterable(out4)))
            bonds = cpn.size
            flows = np.zeros((cpn_days.size, bonds))
            flows = pd.DataFrame(flows)
            # Construyendo matriz
            for j in range(0, cpn.size):
                # flows.iloc[np.in1d(time, out1[j]),j] = out2[j]
                flows.iloc[np.in1d(cpn_days, out3[j]), j] = out2[j]
            ##  En caso de que falle algun titulo, se tendran valores de cero en plazos, hay que eliminarlos
            flows = flows[(flows.T != 0).any()].reset_index(drop=True)
            flows = np.array(flows)
            time_desc = time_desc[time_desc != 0]
            cpn_days = cpn_days[cpn_days != 0]
            time = time[time != 0]
            accrued_interest[accrued_interest <= 0] = 0

            out = dict({
                'mat': cpn_days,  # Dias anualizados para el descuento del cupon Act NL/365
                'flows': flows,  # Matriz de plazos con valor de cupones para cada titulo
                'terms': time,  # Dias de pago de los cupones y titulo
                'terms_desc': time_desc,  # Dias de pago del titulo en Act NL/365 para curva de descuento
                'accrued_interest': accrued_interest,  # Cupon corrido para los titulos
                'failed_instr_pos': out6  # ubicacion de los titulos que fallan
            })
    except ValueError as e:
        logger.error('Se genero un error en la funcion bond_flows_m ')
        logger.error(e)
        
    except NameError as e:
        logger.error('Se genero un error en la funcion bond_flows_m ')
        logger.error(e)

    except AttributeError  as e:
        logger.error('Se genero un error en la funcion bond_flows_m ')
        logger.error(e)
    except TypeError as e:
        logger.error('Se genero un error en la funcion bond_flows_m ')
        logger.error(e)
    except IndexError as e:
        logger.error('Se genero un error en la funcion bond_flows_m ')
        logger.error(e)
    except Exception as e:
        logger.error('Se genero un error en la funcion bond_flows_m ')
        logger.error(e)
    return out

def mac_duration_m(flows_dic, data):
    """
    Funcion que calcula la duracion de Macaulay
    Autor: Laura Natalia Lopez <llopez@precia.co>
    Fecha: 2021-07-02
    :param data: (DataFrame) Contiene las caracterisicas faciales y de mercado del titulo
    :param flows_dic: (dict) Contiene la informacion matricial de las condiciones faciales de los titulos
    :return: (float) Duracion de Macaulay
    """

    try:
        flows = flows_dic['flows'][:, data.flows_loc.values]
        mat = flows_dic['mat']
        mat = mat.reshape(len(mat), 1)
        prices = data['MEAN_PRICE'].values
        prices = prices.reshape(prices.size, 1)
        ytm_data = data['TIR'].values
        ytm = ytm_data.reshape(ytm_data.size, 1) / 100
        mac_duration = []
        for j in range(0,len(prices)):
            descount_m = 1 / (1 + ytm[j]) ** mat.T  # (1,t)
            flows = flows_dic['flows'][:, j] #(t,1)
            flows = flows.reshape(flows.size, 1)
            # calculo
            flows_disc = np.multiply(mat, flows)  # (t,1)
            # mac_num = np.diag(np.matmul(descount_m,flows_disc)) #(m,m) -> (m,)
            mac_num = np.multiply(descount_m.T, flows_disc).sum(axis=0)  # (t,1) -> (1,)
            mac_denom = 1 / prices[j]  # (1,)
            mac_duration.append(mac_num[0] * mac_denom)
        mac_duration = np.array(mac_duration)
    except ValueError as e:
        logger.error('Se genero un error en la funcion mac_duration_m ')
        logger.error(e)
        error_message = 'Se genero un error en la funcion mac_duration_m '
        raise PlataformError(error_message=error_message)
    except NameError as e:
        logger.error('Se genero un error en la funcion mac_duration_m ')
        logger.error(e)
        error_message = 'Se genero un error en la funcion mac_duration_m'
        raise PlataformError(error_message=error_message)
    except TypeError as e:
        logger.error('Se genero un error en la funcion mac_duration_m ')
        logger.error(e)
        error_message = 'Se genero un error en la funcion mac_duration_m'
        raise PlataformError(error_message=error_message)
    except IndexError as e:
        logger.error('Se genero un error en la funcion mac_duration_m ')
        logger.error(e)
        error_message = 'Se genero un error en la funcion mac_duration_m'
        raise PlataformError(error_message=error_message)
    except Exception as e:
        logger.error('Se genero un error en la funcion mac_duration_m ')
        logger.error(e)
        error_message = 'Se genero un error en la funcion mac_duration_m'
        raise PlataformError(error_message=error_message)
    return (mac_duration)

def mod_duration_m_adj(data, mac_duration):
    """
    Funcion que calcula la duracion modificada teniendo como insumo la duracion de Macaulay
        calculada con la funcion mac_duration_m
    Autor: Laura Natalia Lopez <llopez@precia.co>
    Fecha: 2021-09-02
    :param data: (DataFrame) Contiene las caracterisicas faciales y de mercado del titulo
    :param bond_loc: (int) Posicion del titulo a valorar en flows_dict y data
    :param mac_duration: (float) Duracione de Macaulay
    :return: (float) Duracion modificada
    """
    try:
        ytm_data = data['TIR'].values
        ytm = ytm_data.reshape(ytm_data.size, 1) / 100
        mod_duration = []
        for j in range(len(ytm_data)):
            descount_m = 1 / (1 + ytm[j].T)
            mod_duration.append(mac_duration[j] * descount_m[0])
        mod_duration = np.array(mod_duration)
    except ValueError as e:
        logger.error('Se genero un error en la funcion mod_duration_m ')
        logger.error(e)
        error_message = 'Se genero un error en la funcion mod_duration_m'
        raise PlataformError(error_message=error_message)
    except NameError as e:
        logger.error('Se genero un error en la funcion mod_duration_m ')
        logger.error(e)
        error_message = 'Se genero un error en la funcion mod_duration_m'
        raise PlataformError(error_message=error_message)
    except TypeError as e:
        logger.error('Se genero un error en la funcion mod_duration_m ')
        logger.error(e)
        error_message = 'Se genero un error en la funcion mod_duration_m'
        raise PlataformError(error_message=error_message)
    except IndexError as e:
        logger.error('Se genero un error en la funcion mod_duration_m ')
        logger.error(e)
        error_message = 'Se genero un error en la funcion mod_duration_m'
        raise PlataformError(error_message=error_message)
    except Exception as e:
        logger.error('Se genero un error en la funcion mod_duration_m ')
        logger.error(e)
        error_message = 'Se genero un error en la funcion mod_duration_m'
        raise PlataformError(error_message=error_message)
    return (mod_duration)

def convexity_m(flows_dic,data):
    """
    Funcion que calcula la convexidad
    Autor: Laura Natalia Lopez <llopez@precia.co>
    Fecha: 2021-08-20
    :param data: (dict) Contiene la informacion de mercado para el dia de valoracion
    :param flows_dic: (dict) Contiene la informacion matricial de las condiciones faciales de los titulos
    :return: (float) Convexidad
    """

    try:
        flows = flows_dic['flows'][:, data.flows_loc.values]
        mat = flows_dic['mat']
        mat = mat.reshape(len(mat), 1)
        prices = data['MEAN_PRICE'].values
        prices = prices.reshape(prices.size, 1)
        ytm_data = data['TIR'].values
        ytm = ytm_data.reshape(ytm_data.size, 1) / 100
        convexity = []
        for j in range(len(prices)):
            descount_m = 1 / (1 + ytm[j]) ** mat.T  # (1,t)
            flows = flows_dic['flows'][:, j]  # (t,1)
            flows = flows.reshape(flows.size, 1)
            # calculo
            flows_disc_t = np.multiply(mat, flows)  # (t,m) #t*CF
            flows_disc = np.multiply((mat+1), flows_disc_t) # (t,m) #t^2*CF
            # mac_num = np.diag(np.matmul(descount_m,flows_disc)) #(m,m) -> (m,)
            conv_num = np.multiply(descount_m.T, flows_disc).sum(axis=0)  # (t,m) -> (m,)
            prices_inver = 1 / prices[j]  # (m,)
            ytm_2 = 1 / (1 + ytm[j].T)**2
            conv_demon = prices_inver*ytm_2
            convexity.append(conv_num[0] * conv_demon[0])
        convexity = np.array(convexity)
    except ValueError as e:
        logger.error('Se genero un error en la funcion convexity_m ')
        logger.error(e)
        error_message = 'Se genero un error en la funcion convexity_m'
        raise PlataformError(error_message=error_message)
    except NameError as e:
        logger.error('Se genero un error en la funcion convexity_m ')
        logger.error(e)
        error_message = 'Se genero un error en la funcion convexity_m'
        raise PlataformError(error_message=error_message)
    except TypeError as e:
        logger.error('Se genero un error en la funcion convexity_m ')
        logger.error(e)
        error_message = 'Se genero un error en la funcion convexity_m'
        raise PlataformError(error_message=error_message)
    except IndexError as e:
        logger.error('Se genero un error en la funcion convexity_m ')
        logger.error(e)
        error_message = 'Se genero un error en la funcion convexity_m'
        raise PlataformError(error_message=error_message)
    except Exception as e:
        logger.error('Se genero un error en la funcion convexity_m ')
        logger.error(e)
        error_message = 'Se genero un error en la funcion convexity_m'
        raise PlataformError(error_message=error_message)
    return convexity

def instrument_dirty_price_1d(flows_dic, delta_t, discount_factor_cc_curve,bond_loc,margin):
    """
    Funcion que genera el precio sucio de un titulo descontando con la curva de descuento y el margen
    Autor: Laura Natalia Lopez <llopez@precia.co>
    Fecha: 2021-07-02
    :param data: (dict) Contiene la informacion de mercado para el dia de valoracion
    :param flows_dic: (dict) Contiene la informacion de dias a vencimiento anualizados (mat),
                    matriz de pago de cupones (flows) para diferentes titulos (columnas)
                    y dias al vencimiento (term) con convencion Act/365 Non Leap (sin bisiestos)
    :param delta_t: (array) contiene delta del tiempo segun el tamano de plazo de discount_factor_cc_curve
    :param discount_factor_cc_curve: curva de factores de descuento donde las columnas son los titulos
    : param bond_loc (int): posicion del titulo en la matriz de flujos
    :param margin: (float) margen para cada titulo (en porcentaje)
    :return: (float) precios calculado
    """
    try:
        # Calcular los flujos de los titulos
        flows = flows_dic['flows'][:, bond_loc]
        discount_factor_cc = discount_factor_cc_curve[:,bond_loc]
        margin = np.array(margin / 100)
        # Calculando curva
        adj_marg = 1 / (1 + margin) ** delta_t
        descount_m = np.multiply(discount_factor_cc, adj_marg)
        bond_dirty_price = rd_vec(np.multiply(descount_m, flows).sum(axis=0) * 100, 3)
    except ValueError as e:
        logger.error('Se genero un error en la funcion instrument_dirty_price')
        logger.error(e)
    except NameError as e:
        logger.error('Se genero un error en la funcion instrument_dirty_price ')
        logger.error(e)
    except TypeError as e:
        logger.error('Se genero un error en la funcion instrument_dirty_price ')
        logger.error(e)
    except IndexError as e:
        logger.error('Se genero un error en la funcion instrument_dirty_price ')
        logger.error(e)
    except Exception as e:
        logger.error('Se genero un error en la funcion instrument_dirty_price ')
        logger.error(e)
    return (bond_dirty_price)

def bond_price_ytm_1d(ytm, flows_dic,bond_loc):
    '''
    Funcion que genera el precio de mercado de unos titulos descontando con una sola TIR de mercado
    Autor: Laura Natalia Lopez <llopez@precia.co>
    Fecha: 2021-01-26
    :ytm (float): TIR para valorar el titulo
    :flows_dic (array): matriz de pago de cupones (flows) 
    : param bond_loc (array): posicion del titulo en la matriz de flujos
    :returns: bond_price_ytm (array) Vector de precios de mercado de los titulos
    '''
    try:
        flows = flows_dic['flows'][:, bond_loc]
        mat = flows_dic['mat']  # dias vencimiento anualizado
        mat = np.array(mat).reshape(len(mat), 1)
        # Calculando curva
        descount_m = 1 / (1 + ytm / 100) ** mat
        # Calculando precios con TIR de los titulos
        bond_price_ytm = np.matmul(descount_m.T, flows)
    except ValueError as e:
        logger.error('Se genero un error en la funcion bond_price_ytm_1d ')
        logger.error(e)
    except NameError as e:
        logger.error('Se genero un error en la funcion bond_price_ytm_1d ')
        logger.error(e)
    except TypeError as e:
        logger.error('Se genero un error en la funcion bond_price_ytm_1d ')
        logger.error(e)
    except IndexError as e:
        logger.error('Se genero un error en la funcion bond_price_ytm_1d ')
        logger.error(e)
    except Exception as e:
        logger.error('Se genero un error en la funcion bond_price_ytm_1d ')
        logger.error(e)
    return (bond_price_ytm)

def price_to_yield_loop(prices,dataList,flows_dic,bonds_loc):
    '''
    Funcion que encuentra las TIRs para un vector de precios
    Autor: <investigacion@precia.co>
    Fecha: 2022-10-12
    :param prices: (array) vector de precios promedio ponderado
    :param dataList: (dict) Contiene la informacion de mercado para el dia de valoracion
    :param flows_dict: (dict) Contiene los dias a vencimiento anualizados (mat),
        matriz de pago de cupones (flows) y dias al vencimiento (term) con convencion
        Act/365 Non Leap (sin bisiestos) del titulo
    : param bonds_loc (array): posicion de los titulos en la matriz de flujos
    :return: ym (array): valor de la yield
    '''
    try:
        y_lim_0 = dataList['y_lim'][0]
        y_lim_1 = dataList['y_lim'][1]
        ym = np.array([np.nan]* len(bonds_loc))
        logger.info("Inicia calculo de la TIR para " + str(len(ym)) + " fechas")
        
        def optim_ytm_fun(x, price, bond_loc):
            ytm = x
            diff = price - bond_price_ytm_1d(ytm,flows_dic,bond_loc)[0]
            return (diff)

        for i in range(len(bonds_loc)):
            bond_loc = bonds_loc[i]
            price = prices[i]
            if np.int(np.sign(optim_ytm_fun(y_lim_0, price, bond_loc)) * 
                      np.sign(optim_ytm_fun(y_lim_1, price, bond_loc))) == 1:
                continue
            ym[i] = optim.brentq(optim_ytm_fun, y_lim_0, y_lim_1, args = (price, bond_loc))
                
    except ValueError as e:
        logger.error('Se genero un error en la funcion de optimizacion yield_to_worst ')
        logger.error(e)
    except NameError as e:
        logger.error('Se genero un error en la funcion de optimizacion yield_to_worst ')
        logger.error(e)
    except AttributeError  as e:
        logger.error('Se genero un error en la funcion de optimizacion yield_to_worst ')
        logger.error(e)
    except TypeError as e:
        logger.error('Se genero un error en la funcion de optimizacion yield_to_worst ')
        logger.error(e)
    except IndexError as e:
        logger.error('Se genero un error en la funcion de optimizacion yield_to_worst ')
        logger.error(e)
    except Exception as e:
        logger.error('Se genero un error en la funcion de optimizacion yield_to_worst ')
        logger.error(e)
    return(ym)

def instrument_margin(dirty_price,flows_dic, delta_t, discount_factor_cc_curve,bonds_loc):
    """
    Encontrar los diferentes tipos de margen para un titulo dado diferentes precios sucios de mercado.
    Autor: Laura Natalia Lopez <llopez@precia.co>
    Fecha: 2021-01-26
    :param flows_dic: (dict) Contiene la informacion de dias a vencimiento anualizados (mat),
                    matriz de pago de cupones (flows) para diferentes titulos (columnas)
                    y dias al vencimiento (term) con convencion Act/365 Non Leap (sin bisiestos)
    :param delta_t: (array) contiene delta del tiempo segun el tamano de plazo de discount_factor_cc_curve
    :param discount_factor_cc_curve: curva de factores de descuento
    :param dirty_price: (array) precios de los titulos
    :param bonds_loc: (aray): posicion de los titulos en la matriz de flujos
    :return: (array) margenes
    """
    try:
        margins = np.array([np.nan]* len(dirty_price))
        logger.info("Inicia calculo del margen para " + str(len(margins)) + " titulos")
        
        def optim_margin_fun(m,price,bond_loc):
            diff = np.sqrt(((instrument_dirty_price_1d(flows_dic, delta_t, discount_factor_cc_curve,bond_loc,m)
                             - price) * 100) ** 2)
            return (diff)
        
        for i in range(len(bonds_loc)):
            bond_loc = bonds_loc[i]
            price = dirty_price[i]
            m_optim = optim.minimize_scalar(fun=optim_margin_fun, method='bounded', bounds=(-20, 20), args = (price,bond_loc))
            margins[i] = round(m_optim.x, 16)
            
    except ValueError as e:
        logger.error('Se genero un error en la funcion instrument_margin ')
        logger.error(e)
        error_message = 'Se genero un error en la funcion instrument_margin '
        raise PlataformError(error_message=error_message)
    except NameError as e:
        logger.error('Se genero un error en la funcion instrument_margin ')
        logger.error(e)
        error_message = 'Se genero un error en la funcion instrument_margin '
        raise PlataformError(error_message=error_message)
    except AttributeError  as e:
        logger.error('Se genero un error en la funcion instrument_margin ')
        logger.error(e)
        error_message = 'Se genero un error en la funcion instrument_margin '
        raise PlataformError(error_message=error_message)
    except TypeError as e:
        logger.error('Se genero un error en la funcion instrument_margin ')
        logger.error(e)
        error_message = 'Se genero un error en la funcion instrument_margin '
        raise PlataformError(error_message=error_message)
    except IndexError as e:
        logger.error('Se genero un error en la funcion instrument_margin ')
        logger.error(e)
        error_message = 'Se genero un error en la funcion instrument_margin '
        raise PlataformError(error_message=error_message)
    except Exception as e:
        logger.error('Se genero un error en la funcion instrument_margin ')
        logger.error(e)
        error_message = 'Se genero un error en la funcion instrument_margin '
        raise PlataformError(error_message=error_message)
    return (margins)

def discount_factor_curve_m(discount_rate_curve,delta_t):
    """
    Calcular la curva de factores de descuento con una curva de tasas de descuento (no en porcentaje)
    Autor: Laura Natalia Lopez <llopez@precia.co>
    Fecha: 2021-01-26
    :param discount_rate_curve: (np.array) curva de tasas de descuento donde columnas titulos y filas dias
    :param delta_t: (array) contiene delta del tiempo segun el tamano de plazo de discount_rate_curve
    :return: Matriz con los factores de descuento para los titulos en las columnas
    """
    try:
        discount_factor_curve_m = 1/((discount_rate_curve+1).T**delta_t).T
    except ValueError as e:
        logger.error('Se genero un error en el calculo de las curvas de factores de descuento ')
        logger.error(e)
        error_message = 'Se genero un error en el calculo de las curvas de factores de descuento '
        raise PlataformError(error_message=error_message)
    except NameError as e:
        logger.error('Se genero un error en el calculo de las curvas de factores de descuento ')
        logger.error(e)
        error_message = 'Se genero un error en el calculo de las curvas de factores de descuento '
        raise PlataformError(error_message=error_message)
    except AttributeError  as e:
        logger.error('Se genero un error en el calculo de las curvas de factores de descuento ')
        logger.error(e)
        error_message = 'Se genero un error en el calculo de las curvas de factores de descuento '
        raise PlataformError(error_message=error_message)
    except TypeError as e:
        logger.error('Se genero un error en el calculo de las curvas de factores de descuento ')
        logger.error(e)
        error_message = 'Se genero un error en el calculo de las curvas de factores de descuento '
        raise PlataformError(error_message=error_message)
    except IndexError as e:
        logger.error('Se genero un error en el calculo de las curvas de factores de descuento ')
        logger.error(e)
        error_message = 'Se genero un error en el calculo de las curvas de factores de descuento '
        raise PlataformError(error_message=error_message)
    except Exception as e:
        logger.error('Se genero un error en el calculo de las curvas de factores de descuento ')
        logger.error(e)
        error_message = 'Se genero un error en el calculo de las curvas de factores de descuento '
        raise PlataformError(error_message=error_message)
    return discount_factor_curve_m

def fwd_option_price(data,margin_vto,discount_factors,flows_dict,bond_pos):
    '''
    Funcion que calcula el precio estimado de un bono con opcionalidad teniendo en cuenta 
        la comparacion entre el precio forward del bono y el strike para validar si s
        ejerce la opcionalidad
    Autor: <investigacion@precia.co>
    Fecha: 2022-10-12
    :param data (DataFrame): Contiene información de dias a las fechas de opcionalidad (DAYS),
        Dias a las fechas de vencimiento (MATURITY_DAYS), Diferencial del margen (MARGIN_DIFF),
        Margen de la categoria correspondiente a la fecha de opcionalidad (MARGIN_CAT)
    :param margin_vto (array): Margen de la categoria correspondiente a la fecha de vto
    :param discount_factors (array): curva de factores de descuento
    :param flows_dic: (dict) Contiene los dias a vencimiento anualizados (mat),
        matriz de pago de cupones (flows) y dias al vencimiento (term) con convencion
        Act/365 Non Leap (sin bisiestos) del titulo
    :param bond_pos (int): posicion de los flujos a vto del titulo en la matriz de flujos
    :return: ytw (dict): valor de la yield to worst (yield) y fecha de la yield to worst (yiel_date)
    '''
    logger.info("Entrando en la funcion bond_option_price")
    try:
        logger.info("Calculando precio forward para " + str(len(data)) + ' titulos')
        flows_dic = flows_dict.copy()
        opt_days = data['DAYS'].values
        mat_days = data['MATURITY_DAYS'].values
        flows_dic['flows'] = flows_dic['flows'][:,bond_pos]
        discount_factors = discount_factors[:,bond_pos]
        index = np.array([sum(flows_dic["terms_desc"] <= days) for days in opt_days])
        for i in range(len(index)): 
            flows_dic["flows"][:index[i],i] = 0
        fwd_discount_factors = discount_factors / discount_factors[index-1,range(len(index))]
        margin_opt = data['MARGIN_DIFF'].values + data['MARGIN_CAT'].values
        margin_mat = data['MARGIN_DIFF'].values + margin_vto
        fwd_margin = forward_margin(margin_mat,margin_opt,mat_days,opt_days)
        delta_t = (flows_dic["terms_desc"] - opt_days[:,np.newaxis])/365
        adj_marg = 1 / (1 + fwd_margin[:,np.newaxis]) ** delta_t
        descount_m = np.multiply(fwd_discount_factors, adj_marg.T)
        bond_forward_price = np.multiply(descount_m, flows_dic["flows"]).sum(axis=0)
                    
    except ValueError as e:
        logger.error('Se genero un error en la funcion de optimizacion price_to_yield ')
        logger.error(e)
    except NameError as e:
        logger.error('Se genero un error en la funcion de optimizacion price_to_yield ')
        logger.error(e)
    except AttributeError  as e:
        logger.error('Se genero un error en la funcion de optimizacion price_to_yield ')
        logger.error(e)
    except TypeError as e:
        logger.error('Se genero un error en la funcion de optimizacion price_to_yield ')
        logger.error(e)
    except IndexError as e:
        logger.error('Se genero un error en la funcion de optimizacion price_to_yield ')
        logger.error(e)
    except Exception as e:
        logger.error('Se genero un error en la funcion de optimizacion price_to_yield ')
        logger.error(e)
    return bond_forward_price

def instrument_dirty_price(flows_dic, delta_t, discount_factor_cc_curve,bond_loc,margin):
    """
    Funcion que genera el precio sucio de un titulo descontando con la curva de descuento y el margen
    Autor: Laura Natalia Lopez <llopez@precia.co>
    Fecha: 2021-07-02
    :param data: (dict) Contiene la informacion de mercado para el dia de valoracion
    :param flows_dic: (dict) Contiene la informacion de dias a vencimiento anualizados (mat),
                    matriz de pago de cupones (flows) para diferentes titulos (columnas)
                    y dias al vencimiento (term) con convencion Act/365 Non Leap (sin bisiestos)
    :param delta_t: (array) contiene delta del tiempo segun el tamano de plazo de discount_factor_cc_curve
    :param discount_factor_cc_curve: curva de factores de descuento donde las columnas son los titulos
    : param bond_loc (int): posicion de los titulo en la matriz de flujos
    :param margin: (array) margen para cada titulo
    :return: (float) precios calculado
    """
    try:
        # Calcular los flujos de los titulos
        flows = flows_dic['flows'][:, bond_loc]
        discount_factor_cc = discount_factor_cc_curve[:,bond_loc]
        margin = np.array(margin / 100)
        marg = margin.reshape(margin.size, 1)
        # Calculando curva
        adj_marg = 1 / (1 + marg) ** delta_t
        descount_m = np.multiply(discount_factor_cc, adj_marg.T)
        bond_dirty_price = rd_vec(np.multiply(descount_m, flows).sum(axis=0) * 100, 3)
    except ValueError as e:
        logger.error('Se genero un error en la funcion instrument_dirty_price')
        logger.error(e)
    except NameError as e:
        logger.error('Se genero un error en la funcion instrument_dirty_price ')
        logger.error(e)
    except TypeError as e:
        logger.error('Se genero un error en la funcion instrument_dirty_price ')
        logger.error(e)
    except IndexError as e:
        logger.error('Se genero un error en la funcion instrument_dirty_price ')
        logger.error(e)
    except Exception as e:
        logger.error('Se genero un error en la funcion instrument_dirty_price ')
        logger.error(e)
    return (bond_dirty_price)


def forward_margin(mat_margin,opt_margin,days_mat,days_opt):
    f_margin=((1+mat_margin/100)**(days_mat/365)/(1+opt_margin/100)**(days_opt/365))**(365/(days_mat-days_opt))-1
    return(f_margin)