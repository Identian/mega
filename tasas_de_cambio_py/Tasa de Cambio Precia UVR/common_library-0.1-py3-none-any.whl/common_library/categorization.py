import pandas as pd
import numpy as np
from common_library.date_utils import DateUtils
from common_library.error import PlataformError
from common_library.precia_logger import setup_logging, create_log_msg

pd.options.mode.chained_assignment = None  # default='warn'
logger = setup_logging()


class Categorization(object):
    
    def __init__(self, conn_sources, conn_process, valuation_date):
        self.conn_sources = conn_sources
        self.conn_process = conn_process
        self.valuation_date = valuation_date

    def categorize(self,list_instrument, expiration_ranges):
        '''
        categorize : Metodo que calcula la categoria de los titulos
        :param list_instrument (DataFrame) : caracteristicas faciales de los bonos con opcionalidad
        :return: lista de instrumentos
        '''
        try:
            logger.info('Inicia el proceso de categorizacion para '  + str(len(list_instrument)) + ' titulos')
            list_instrument['OPT_DATE'] = list_instrument['OPT_DATE'] + "|" + list_instrument['MATURITY_DATE'].astype(str)
            list_instrument['STRIKE'] = list_instrument['STRIKE'] + "|100"
            list_instrument['OPT_DATE'] = list_instrument['OPT_DATE'].str.split('|')
            list_instrument['STRIKE'] = list_instrument['STRIKE'].str.split('|')
            list_instrument = list_instrument.explode(['OPT_DATE','STRIKE'],ignore_index=True)
            list_instrument['OPT_DATE'] = pd.to_datetime(list_instrument['OPT_DATE']).dt.date
            list_instrument['STRIKE'] = list_instrument['STRIKE'].astype(float)
            logger.info('La cantidad de fechas para categorizar es de ' + str(len(list_instrument)))
            list_instrument['DAYS'] = Categorization.calculated_days(self, list_instrument['OPT_DATE'])
            list_instrument['ID_EXPIRATION_RANGE'] = Categorization.get_days_expiration(self, list_instrument['DAYS'], expiration_ranges)
            
            list_instrument['CATEGORY_ID'] = list_instrument['CLASS'].astype(str) + list_instrument['CURRENCY_GROUP'].astype(str) +\
                list_instrument['RATE_GROUP'].astype(str) + list_instrument['RATING_GROUP'].astype(str) + \
                    list_instrument['ID_EXPIRATION_RANGE'].astype(str)
            list_instrument = list_instrument.drop(['REAL_RATING','CLASS','RATING_GROUP','RATE_GROUP','CURRENCY_GROUP','ID_EXPIRATION_RANGE'],axis=1)
            logger.info('Finaliza el proceso de categorizacion')
        except (Exception,) as sec_exc:
            error_msg = "Se ha presentado un error ejecutando la categorizacion"
            logger.error(create_log_msg(error_msg))
            raise PlataformError(error_msg) from sec_exc
        return list_instrument

    def calculated_days(self, end_dates):
        logger.info('Inicia el calculo de dias al vencimiento para '+str(len(end_dates)) +' fechas')
        try:
            end_days = []
            for date in end_dates:
                day_less = DateUtils.is_leap_dates(self, self.valuation_date, date)
                days = abs(date - self.valuation_date).days - day_less
                end_days.append(days)
            logger.info('Finaliza el calculo de dias al vencimiento ')
        except (Exception,) as sec_exc:
            error_msg = "Se genera un error calculando los dias al vencimiento"
            logger.error(create_log_msg(error_msg))
            raise PlataformError(error_msg) from sec_exc
        return end_days

    def get_days_expiration(self, days_calculated, ranges_expiration):
        try:
            id_expiration_range = []
            ranges_expiration.columns = ranges_expiration.columns.str.upper()
            for day in days_calculated:
                range_pos = np.where((day >= ranges_expiration['START_RANGE'].values) & \
                            (day <= ranges_expiration["END_RANGE"].values))[0]
                id_expiration_range.append(ranges_expiration['ID_EXPIRATION_RANGE'][range_pos].item())
        except (Exception,) as sec_exc:
            error_msg = "Se ha presentado un error en los dias al vencimiento"
            logger.error(create_log_msg(error_msg))
            raise PlataformError(error_msg) from sec_exc
        return id_expiration_range
        
       
