import sys
import sqlalchemy as sa
from sqlalchemy import exc
import pandas as pd
import numpy as np
import datetime as dt
from sqlalchemy import create_engine, MetaData, Table, Column, Text, Integer, String, Float, Date
from sqlalchemy.orm import Session
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import Session
from sqlalchemy import MetaData, Table, Column, Integer, String, Float, Date
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import Session, sessionmaker, load_only
from common_library.error import PlataformError

from common_library.precia_logger import setup_logging, create_log_msg


Base = declarative_base()
logger = setup_logging()
   
    
class Category(Base):
    __tablename__ = 'prc_rfl_get_category'
    category_date = Column(Date)
    category_id = Column(Integer, primary_key=True)
    issuer = Column(String)
    instrument_type = Column(String)
    isin_code = Column(String)
    instrument = Column(String, primary_key=True)
    issue_date = Column(Date)
    maturity_date = Column(Date)
    maturity_days = Column(Integer)
    payment_frequency = Column(String)
    frequency_months = Column(Integer)
    base = Column(String)
    rate_type = Column(String)
    rate_expression = Column(String)
    spread = Column(Float)
    use_rate = Column(String)
    margin_value = Column(Float)
    margin_type = Column(String)
    margin_origin = Column(String)
    cc_curve = Column(String)
    accrued_interest = Column(Float)
    
    
    
class IndividualMarginBonds(Base):
    __tablename__ = 'src_rfl_individual_margin_bonds'
    instrument = Column(String, primary_key=True)
    isin_code = Column(String, primary_key=True)
    real_rating = Column(String)
    opt_date = Column(Date)
    strike = Column(String)
    instrument_type = Column(String)
    
    
    
class IndividualMarginBondsDiff(Base):
    __tablename__ = 'prc_rfl_individual_margin_bonds_diff'
    diff_date = Column(Date, primary_key=True)
    instrument = Column(String, primary_key=True)
    isin_code = Column(String, primary_key=True)
    margin_diff = Column(Float)
  
    
class Rates(Base):
    __tablename__ = 'src_rfl_rates'
    rate_type = Column(String, primary_key=True)
    rate_date = Column(Date, primary_key=True)
    rate_value = Column(Float)
  
  
    
class Yield(Base):
    __tablename__ = 'pub_rfl_yield'
    cc_curve = Column(String, primary_key=True)
    term = Column(Integer,primary_key=True)
    rate = Column(Float)
    rate_date = Column(Date, primary_key=True)
  
  
    
class CategoryMargin(Base):
    __tablename__ = "prc_rfl_category_margin"
    category_id = Column(Integer, primary_key=True)
    margin_value = Column(Float)
    margin_date = Column(Date, primary_key=True)
    
class ExpirationRange(Base):
    __tablename__ = "src_rfl_expiration_range"
    id_expiration_range = Column(Integer, primary_key = True)
    start_range = Column(Integer)
    end_range = Column(Integer)
    description = Column(String)

class Parameters(Base):
    __tablename__ = "src_rfl_parameters"
    parameter_name = Column(String, primary_key = True)
    parameter_value = Column(String)
    rfl_process = Column(String)
    description = Column(String)
    
    
class Model(object):
    def __init__(self, conn_sources, conn_process, conn_publish) -> None:
        self.precia_sources = conn_sources
        self.precia_process = conn_process
        self.precia_publish = conn_publish
        Session_sources = sessionmaker(bind=self.precia_sources)
        self.session_src = Session_sources()
        Session_process = sessionmaker(bind=self.precia_process)
        self.session_prc = Session_process()
        Session_publish = sessionmaker(bind=self.precia_publish)
        self.session_publish = Session_publish()

    def get_option_bonds_info(self):
        return pd.read_sql(self.session_src.query(IndividualMarginBonds).filter(IndividualMarginBonds.instrument_type=='o').statement,self.session_src.bind)
        
    def get_get_category(self, isines, valuation_date):
        get_category = pd.read_sql(self.session_prc.query(Category).filter(Category.isin_code.in_(isines)).filter(Category.category_date==valuation_date).statement, self.session_prc.bind)
        get_category.rename(columns={'spread':'coupon'}, inplace=True)
        return get_category
    
    def get_instrument_info(self, isines):
        stmt = "SELECT instrument AS INSTRUMENT,isin_code AS ISIN_CODE, issue_num AS ISSUE_NUM, currency_type AS CURRENCY_TYPE, class AS CLASS, rating_group AS RATING_GROUP, rate_group AS RATE_GROUP, currency_group AS CURRENCY_GROUP FROM src_rfl_instrument WHERE inst_condition = 'A' AND isin_code IN " + str(tuple(np.append(isines,'1')))
        return pd.read_sql(stmt, self.precia_sources)
    
    def get_option_diff(self, isines,valuation_date):
        prev_date = valuation_date - dt.timedelta(1)
        option_diff = pd.read_sql(self.session_prc.query(IndividualMarginBondsDiff).filter(IndividualMarginBondsDiff.diff_date==str(prev_date)).filter(IndividualMarginBondsDiff.isin_code.in_(isines)).statement,self.session_prc.bind)
        option_diff.drop('diff_date',axis = 1)
        return option_diff
        
    def get_src_rates(self, instrument_rates):
        return pd.read_sql(self.session_src.query(Rates).filter(Rates.rate_type.in_(instrument_rates)).statement,self.session_src.bind)
    
    def get_cc_curve(self, valuation_date, cc_curves):
        cc_curve = pd.read_sql(self.session_publish.query(Yield).filter(Yield.cc_curve.in_(cc_curves)).filter(Yield.rate_date==valuation_date).statement, self.session_publish.bind)
        cc_curve.drop('rate_date',axis = 1)
        return cc_curve
        
    def get_category_margin(self, valuation_date,categories):
        category_margin = pd.read_sql(self.session_prc.query(CategoryMargin).filter(CategoryMargin.margin_date==valuation_date).filter(CategoryMargin.category_id.in_(categories)).statement, self.session_prc.bind)
        category_margin['category_id'] = category_margin['category_id'].astype(str)
        category_margin.rename(columns={'margin_value':'margin_cat'}, inplace=True)
        return category_margin
        
    def get_operations_total_time(self, valuation_date, valuation_datetime,instruments):
        stmt = "SELECT operation_date AS OPERATION_DATE, trading_system AS TRADING_SYSTEM, folio AS FOLIO, instrument AS INSTRUMENT, category_id AS CATEGORY_ID, issue_date AS ISSUE_DATE, maturity_date AS MATURITY_DATE, issue_number AS ISSUE_NUMBER, clean_price AS CLEAN_PRICE, dirty_price AS DIRTY_PRICE, yield AS YIELD, amount AS AMOUNT, volume AS VOLUME, maturity_days AS MATURITY_DAYS, currency_type AS CURRENCY, currency_value AS CURRENCY_VALUE, rate_type AS RATE_TYPE,spread AS COUPON, margin_value AS MARGIN_VALUE,num_control AS NUM_CONTROL, instrument_type AS INSTRUMENT_TYPE, payment_frequency AS PAYMENT_FREQUENCY,frequency_months AS FREQUENCY_MONTHS,selling_broker AS SELLING_BROKER, buying_broker AS BUYING_BROKER FROM prc_rfl_operations WHERE operation_date = '"+str(valuation_date)+"' AND timestamp_operation <= '"+str(valuation_datetime)+"' AND instrument IN " + str(tuple(np.append(instruments,'1')))
        return pd.read_sql(stmt, self.precia_process)
        
    def get_expiration_ranges(self):
        return pd.read_sql(self.session_src.query(ExpirationRange).statement, self.session_src.bind)

    def get_rfl_parameters(self):
        parameters = pd.read_sql(self.session_src.query(Parameters.parameter_name, Parameters.parameter_value).statement, self.session_src.bind)
        logger.info("Se transforman los parametros a diccionario")
        parameters.columns = parameters.columns.str.upper()
        parameters = parameters.set_index('PARAMETER_NAME').to_dict()
        parameters['Properties'] = parameters.pop('PARAMETER_VALUE')
        return parameters

    def get_prices_to_variation(self, valuation_date,isines):
        try:
            logger.info("Inicia la consulta de informacion de titulos para variacion"
                            " de precios y TIRs")
            stmt = "SELECT isin_code AS ISIN_CODE, instrument AS INSTRUMENT, mean_price AS MEAN_PRICE, yield AS YIELD FROM pub_rfl_prices WHERE valuation_date = '" + str(valuation_date) + "' AND isin_code IN " + str(tuple(np.append(isines,'')))
            prices_table = pd.read_sql(stmt, con=self.precia_publish)
            logger.info("Finaliza la consulta de informacion de titulos para variacion de precios y TIRs")
            return prices_table
        except Exception as e:
            logger.error('Se genero un error al realzar la consulta a la base de datos ')
            raise PlataformError(error_message='Se genero un error al realzar la consulta a la base de datos ')

    def delete_rfl_price_yield_variation(self, valuation_date, isines):
        try:
            logger.info("Eliminando registros variaciones para el "+ str(valuation_date) + "y los isines" + str(isines))
            DEL_SQL_QUERY_TO_VAR = ("DELETE FROM prc_rfl_price_yield_variation WHERE valuation_date = '"+
                                    str(valuation_date) + "' AND isin_code IN " + str(tuple(np.append(isines,'1'))))
            
            cursor_db = self.precia_process.connect()
            cursor_db.execute(DEL_SQL_QUERY_TO_VAR)
            logger.info("Finaliza eliminacion registros de variaciones")
        except Exception as e:
            logger.error('Se genero un error al eliminar resgistros')
            logger.error(e)
            raise PlataformError(error_message="Se genero un error al eliminar registros ")


    def insert_rfl_price_yield_variation(self, price_data):
        """
        Insertar la tabla con los titulos con variaciones por fuera de los limites en precio y TIRs
            en prc_rfl_price_yield_variation
        :param price_data: Dataframe con informacion de los titulos
        Autor: Investigacion y Desarrollo <investigacion@precia.co>
        Fecha: 2021-09-17 (Mod 2022-04-13)
        """
        try:
            logger.info("Inicia inclusion de titulos con variaciones por fuera de los limites en precio y TIRs")
            if price_data is None:
                logger.info("No existe informacion para realizar calculos de variaciones en precios y TIRs. Revise log")
                return
            elif len(price_data) == 0:
                logger.info("No hay titulos con variaciones por fuera de los limites en precio y TIRs a incluir")
                return
            price_data.columns = ["valuation_date", "isin_code", "instrument","category_id", "maturity_days", "paid_coupon", "mean_price",
                                  "prev_mean_price", "price_variation", "yield", "prev_yield", "yield_variation", "update_time"]
            price_data.to_sql("prc_rfl_price_yield_variation", self.precia_process, chunksize=100, method='multi', if_exists='append', index = False)
            logger.info("Finaliza proceso de inclusion de titulos con variaciones por fuera de los limites en precio y TIRs")
        except Exception as e:
            logger.error('Se genera un error insertando los datos de variaciones')
            logger.error(e)
            raise PlataformError(error_message="Se genera un error insertando los datos de variaciones")


    def insert_prices_risk_pd(self, price_table):
        """
        Insertar en la tabla pub_rfl_prices el precio promedio, el precio limplio, el margen de valoracion y equivalente,
            la TIR equivalente, duracion, duracion modificada y convexidad para fecha particular (valuation_date)
        Autor: Investigacion y Desarrollo <investigacion@precia.co>
        Fecha: 
        :param price_table: Tabla con informacion del proceso
        """
        try:
            if price_table is None:
                logger.info('No hay informacion de precios a incluir')
                return
            logger.info('Inicia inclusion de titulos')
            price_table_adj = price_table.copy()
            price_table_adj.columns = ['valuation_date', 'category_id', 'isin_code','instrument',
                                   'issue_date', 'maturity_date', 'maturity_days','payment_frequency',
                                   'rate_type', 'spread', 'margin_value','accrued_interest',
                                   'issue_num','yield', 'inst_condition', 'currency_type','mean_price',
                                   'clean_price', 'convexity', 'equivalent_margin','calculation_type',
                                   'duration','modified_duration','rate_fixed_float','calculation_base','real_rating']
            price_table_adj.to_sql("pub_rfl_prices", self.precia_publish, chunksize=125, method='multi', if_exists='append', index=False)
            logger.info('Finaliza inclusion de valoracion de titulos')
        except exc.IntegrityError as e:
            logger.error(
                'Se genero un error en la inclusion de tasas, es posible que sea por llaves primarias ')
            logger.error(e)
            raise PlataformError(error_message='Se genero un error en la inclusion de tasas, es posible que sea por llaves primarias ')
        except Exception as e:
            raise PlataformError(error_message='Se genero un error en la funcion insert_prices_risk_pd')

    def delete_option_bond_prices(self, valuation_date,isines):
        """
        Borrar los registros de los bonos con opcionalidad en la tabla pub_rfl_prices para la fecha de valoracion
		Autor: Investigacion y Desarrollo <investigacion@precia.co>
		Fecha: 2022-11-23
		:param valuation_date: String con fecha de valoracion
		:param isines: array con los isines a eliminar
		"""
        try:
            logger.info("Eliminar los registros del dia de valoracion de precios para los isines" + str(isines))
            DEL_SQL_QUERY= ("DELETE FROM pub_rfl_prices WHERE valuation_date = '" + str(valuation_date) +"' AND " +
								"isin_code IN " + str(tuple(np.append(isines,'1'))))
            cursor_db = self.precia_publish.connect()
            cursor_db.execute(DEL_SQL_QUERY)
            logger.info("Finaliza la eliminacion de los registros de "+str(isines)+" del dia de valoracion")
        except Exception as e:
            logger.error('Se genero un error en la eliminacion de los registros')
            raise PlataformError(error_message='Se genero un error en la eliminacion de los registros')

    def update_options_bonds_margin(self, margin_table):
        """
        Actualizar la tabla prc_rfl_get_category con el margen de los bonos con opcionalidad
        Autor: Investigacion y Desarrollo <investigacion@precia.co>
        Fecha: 2022-10-12
        :param margin_table: DataFrame con informacion para actualizar el diferencial del margen
        """
        try:
            logger.info('Inicio de actualizacion del margen')
            if margin_table is None:
                return
            margin_table['TIMESTAMP'] = dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            margin_table = margin_table[['MARGIN_VALUE','MARGIN_TYPE','MARGIN_ORIGIN','TIMESTAMP','ISIN_CODE']]
            UPDATE_SQL_QUERY_TO_GET_MARGIN = ("UPDATE prc_rfl_get_category " +
                                              "SET margin_value = %s, " +
                                              "margin_type = %s, " +
                                              "margin_origin = %s, " +
                                              "update_time = %s " +
                                              "WHERE isin_code = %s ")
            cursor_db = self.precia_process.connect()
            cursor_db.execute(UPDATE_SQL_QUERY_TO_GET_MARGIN, list(margin_table.itertuples(index=False, name=None)))
                        
            logger.info('Finaliza actualizacion informacion de titulos')
        except Exception as e:
            raise PlataformError(error_message='Se genero un error en la funcion update_get_category_acc_int ')

    def delete_option_bond_diff(self, valuation_date,isines):
        """
		Borrar los registros de los bonos con opcionalidad en la tabla prc_rfl_option_bonds_diff para la fecha de valoracion
		Autor: Investigacion y Desarrollo <investigacion@precia.co>
		Fecha: 2022-11-23
		:param valuation_date: String con fecha de valoracion
		:param isines: array con los isines a eliminar
		"""
        try:
            logger.info("Eliminar los registros del dia de valoracion de diferencial de margen" + str(isines))
            DEL_SQL_QUERY = ("DELETE FROM prc_rfl_individual_margin_bonds_diff WHERE diff_date = '" + str(valuation_date) +"' AND " +
								"isin_code IN " + str(tuple(np.append(isines,'1'))))
            cursor_db = self.precia_process.connect()
            cursor_db.execute(DEL_SQL_QUERY)
            logger.info("Finaliza la eliminacion de los registros de "+str(isines)+" del dia de valoracion")
        except Exception as e:
            logger.error('Se genero un error en la eliminacion de los registros')
            raise PlataformError(error_message='Se genero un error en la eliminacion de los registros')

    def insert_margin_diff(self, margin_table):
        """
        Insertar en la tabla prc_rfl_option_bonds_diff el diferencial del margen
        Autor: Investigacion y Desarrollo <investigacion@precia.co>
        Fecha: 2022-10-12
        :param margin_table: DataFrame con informacion para actualizar el diferencial del margen
        """
        try:
            logger.info('Inicio de inclusion del diferencial del margen')
            if margin_table is None:
                return
            margin_table = margin_table.copy()
            margin_table.columns = ['diff_date','instrument','isin_code','opt_date','margin_diff']
            margin_table.to_sql("prc_rfl_individual_margin_bonds_diff", self.precia_process, chunksize=100, method='multi', if_exists='append', index=False)
            logger.info('Finaliza inclusion de informacion de titulos')
        except Exception as e:
            logger.error('Se genero un error al realizar el insert')
            raise PlataformError(error_message='Se genero un error al realizar el insert')