import boto3
from botocore.exceptions import ClientError
from common_library.error import PlataformError
import pymysql
pymysql.install_as_MySQLdb()
import json
import sqlalchemy as sa
from common_library.precia_logger import setup_logging, create_log_msg


secretsmanagerClient = boto3.client('secretsmanager')
logger = setup_logging()

def getSecret(secretName):
    try:
        get_secret_value_response = secretsmanagerClient.get_secret_value(SecretId=secretName)
        secret = get_secret_value_response['SecretString']
        parameters = json.loads(secret)
    except (Exception,) as sec_exc:
        error_msg = "No se pudo obtener el secreto"
        logger.error(create_log_msg(error_msg))
        raise PlataformError(error_msg) from sec_exc
    return parameters


def connect_db(engine, host, port, schema, username, password, timeout: int = 2):
    error_msg = "No se pudo conectar a la base de datos"
    raise_msg = "Fallo el intento de conexion a la base de datos"
    try:
        db_url = f"{engine}://{username}:{password}@{host}:{port}/{schema}"
        sql_engine = sa.create_engine(db_url, connect_args={"connect_timeout": timeout})
        db_connection = sql_engine.connect()
        logger.info("Conexion exitosa.")
        return db_connection
    except sa.exc.SQLAlchemyError as sql_exc:
        logger.error(create_log_msg(error_msg))
        raise PlataformError(raise_msg) from sql_exc
    except PlataformError:
        logger.error(create_log_msg(error_msg))
        raise
    except (Exception,):
        logger.error(create_log_msg(error_msg))
        raise
