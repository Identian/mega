from datetime import datetime
import boto3
import io
import logging
import pytz

import numpy as np
import pandas as pd
import sqlalchemy as sa

from reportlab.lib import colors
from reportlab.lib.pagesizes import letter, landscape
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph
from reportlab.lib.styles import ParagraphStyle

from precia_utils.precia_aws import get_params, get_secret
from precia_utils.precia_logger import setup_logging, create_log_msg
from precia_utils.precia_db import create_db_url
from precia_utils.precia_exceptions import PlataformError

from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from email.mime.base import MIMEBase
from email import encoders
import smtplib

logger = setup_logging(logging.INFO)
colombia_tz = pytz.timezone('America/Bogota')
dt_with_timezone = datetime.now(pytz.timezone('America/Bogota'))


class DataBaseHandler:
    """Representa la extracción de información desde las bases de datos"""

    def __init__(self, url_connection) -> None:
        self.url_connection = url_connection
        self.engine = sa.create_engine(self.url_connection)

    def get_calendars(self, valuation_date):
        """Obtiene el calendario los días hábiles en Colombia y retorna la fecha
        anterior hábil a la actual"""

        query_rates_exchange = sa.sql.text(
        """
        SELECT dates_calendar, bvc_calendar FROM precia_utils_calendars
        WHERE bvc_calendar = 1
        """
        )

        try:
            connection = self.engine.connect()
        except (Exception,):
            logger.error(create_log_msg("Falló la conexión a base de datos"))
            raise PlataformError("Hubo un error en la conexión a base de datos")
        try:
            logger.info("Comienza la obtención de información...")
            df_calendar_bvc = pd.read_sql(query_rates_exchange, connection)
            previous_business_day = df_calendar_bvc.loc[
                (df_calendar_bvc["dates_calendar"] < valuation_date),"dates_calendar",].iloc[-1]
            logger.info(f"Fecha hábil anterrior a la actual: {previous_business_day}")
            return previous_business_day

        except (Exception,):
            logger.error(
                create_log_msg("Falló la extracción de información de la base de datos")
            )
            raise PlataformError("Hubo un error en la exrtación de la base de datos")
        finally:
            connection.close()

    def get_calculated_rates(self, valuation_date):
        """Obtiene las tasas calculadas por la fecha proporcionada"""

        query_rates_exchange = sa.sql.text(
        """
        SELECT id_precia, value_rates FROM pub_exchange_rate_parity
        WHERE valuation_date = :valuation_date
        AND status_info = :status_info
        """
        )
        query_params = {"valuation_date": valuation_date, "status_info": 1}
        try:
            connection = self.engine.connect()
        except (Exception,):
            logger.error(create_log_msg("Falló la conexión a base de datos"))
            raise PlataformError("Hubo un error en la conexión a base de datos")
        try:
            logger.info("Comienza la obtención de información...")
            df_rates = pd.read_sql(query_rates_exchange, connection, params=query_params)
            logger.info(f"Se obtuvieron las tasas calculadas del día {valuation_date} correctamente")
            return df_rates
        except (Exception,):
            logger.error(create_log_msg("Falló la extracción de tasas de la bd"))
            raise PlataformError("Hubo un error en la extración de tasas de la bd")
        finally:
            connection.close()


class Transformer:
    """Representa las transformaciones a la información que va en el reporte"""

    def __init__(self, df_previous_rates, df_today_rates) -> None:
        self.df_previous_rates = df_previous_rates
        self.df_today_rates = df_today_rates
        self.df_rate_report = pd.DataFrame()

    def join_data(self):
        """Une las tasas del día hábil anterior con las de hoy"""
        try:
            self.df_rate_report = pd.merge(
                self.df_today_rates,
                self.df_previous_rates,
                on="id_precia",
                how="left",
                suffixes=("_today", "_previous"),
            )
        except (Exception,):
            logger.error(create_log_msg("Falló la unificación de la información de tasas"))
            raise PlataformError("Hubo un error en la unificación de la información de tasas")

    def calculate_difference(self):
        """Calcula la diferencia entre la tasa del día hábil anterior y la tasa de hoy"""
        self.df_rate_report["Diferencia"] = (
            self.df_rate_report["value_rates_today"]
            - self.df_rate_report["value_rates_previous"]
        )
        logger.info("Se ha calculado la diferencia entre las tasas correctamente")


    def calculate_logarithmic_variation(self):
        """Calcula la variación logaritmica de la tasa de hoy sobre la tasa anterior"""
        try:
            self.df_rate_report["Variacion"] = np.log(
                self.df_rate_report["value_rates_today"]
                / self.df_rate_report["value_rates_previous"]
            )*100
            logger.info("Se ha calculado la variación logaritmica correctamente entre las tasas correctamente")
        except (Exception,):
            logger.error(create_log_msg("Falló el cálculo de la variación logarítmica de las tasas"))
            raise PlataformError("Hubo un error en el cálculo de la variación logarítmica de las tasas")


    def clean_nulls(self):
        "Elimina las filas que se encuentren nulas"
        self.df_rate_report = self.df_rate_report.dropna()
    

    def select_data(self):
        """Selecciona la data a mostrar:
        1. Cuando la Diferencia es mayor a 1
        2. Cuando la moneda es mayor a 1
        3. Las columnas a mostrar en el reporte"""
        self.df_rate_report = self.df_rate_report[self.df_rate_report["value_rates_today"] > 1]
        self.df_rate_report = self.df_rate_report[["id_precia", "value_rates_today", "Diferencia", "Variacion"]]
        self.df_rate_report = self.df_rate_report.sort_values('Variacion', ascending=False)


    def rename_and_order_columns(self):
        """Renombra y ordena las columnas que se ilustran en el pdf"""
        self.df_rate_report  = self.df_rate_report.rename(
        columns={
            "id_precia": "Moneda",
            "value_rates_today": "Valor",
            "Variacion": "VariacionLogaritmica",
        })
        self.df_rate_report  = self.df_rate_report .reindex(
            columns=["Moneda", "Valor", "VariacionLogaritmica", "Diferencia"]
        )


class PDFReport():
    """Representa el archivo pdf que contiene el reporte de las variaciones"""
    def __init__(self, df_report) -> None:
        self.df_report = df_report
    
    def generate_styles(self):
        """Genera los estilos para la tabla que va en el archivo"""
        self.style = TableStyle(
        [
            ("BACKGROUND", (1, 1), (-1, -1), colors.white),
            (
                "ALIGN",
                (0, 0),
                (-1, 0),
                "CENTER",
            ),  # Alineación horizontal centrada para el encabezado
            (
                "ALIGN",
                (0, 1),
                (-1, -1),
                "CENTER",
            ),  # Alineación horizontal centrada para los datos
            (
                "FONTNAME",
                (0, 0),
                (-1, 0),
                "Helvetica-Bold",
            ),  # Fuente negrita para el encabezado
            ("FONTSIZE", (0, 0), (-1, 0), 14),  # Tamaño de fuente 14 para el encabezado
            (
                "BOTTOMPADDING",
                (0, 0),
                (-1, 0),
                12,
            ),  # Espacio entre el encabezado y los datos
            ("GRID", (0, 0), (-1, -1), 1, colors.black),
        ])
        logger.info("Se ha generado el estilo del pdf correctamente")
    
    def paint_data_boxes(self, param_variation):
        """Pinta las casillas según las condicionales"""
        for i, val in enumerate(self.df_report["VariacionLogaritmica"]):
            if val > param_variation:
                self.style.add("BACKGROUND", (2, i + 1), (2, i + 1), colors.red)
                self.style.add(
                    "TEXTCOLOR", (2, i + 1), (2, i + 1), colors.white
                )  # Fondo rojo para valores mayores a 10
            elif val < (param_variation)*-1:
                self.style.add("BACKGROUND", (2, i + 1), (2, i + 1), colors.green)
                self.style.add("TEXTCOLOR", (2, i + 1), (2, i + 1), colors.white)
        
        logger.info("Se ha pintado las casillas según la variacion logaritmica")
    

    def generate_titles_with_styles(self, param_variation, date_str):
        """Genera los estilos para el texto dela archivo"""
        titulo_estilo_1 = ParagraphStyle(
            name="titulo",
            fontName="Helvetica-Bold",
            fontSize=18,
            spaceAfter=20,
            aligment=100,
            textColor=colors.blue,
        )
        titulo_estilo_2 = ParagraphStyle(
            name="titulo",
            fontName="Helvetica-Bold",
            fontSize=16,
            spaceAfter=20,
            aligment="CENTER",
        )
        informacion_variacion_roja = ParagraphStyle(
            name="titulo",
            fontName="Helvetica",
            fontSize=12,
            spaceAfter=5
        )
        informacion_variacion_verde = ParagraphStyle(
            name="titulo",
            fontName="Helvetica",
            fontSize=12,
            spaceAfter=20
        )
        self.titulo_1 = Paragraph("PRECIA", titulo_estilo_1)
        self.titulo_2 = Paragraph(f"Variaciones tasas de cambio - {date_str}", titulo_estilo_2)
        self.variacion_roja = Paragraph(f"Variaciones mayores al parametro establecido {param_variation}: Resaltadas color rojo", informacion_variacion_roja)
        self.variacion_verde = Paragraph("Variaciones negativas: Resaltadas color verde", informacion_variacion_verde)
        logger.info("Se establecio los estilos de texto para el pdf")
    

    def generate_pdf(self):
        """Genera el pdf con toda la información de tasas y lo retorna en forma de bytes"""
        try:
            buffer_file = io.BytesIO()
            datos = [self.df_report.columns.tolist()] + self.df_report.values.tolist()
            tabla = Table(datos)
            tabla.setStyle(self.style)
            doc = SimpleDocTemplate(buffer_file, pagesize=landscape(letter))
            contenido = [self.titulo_1, self.titulo_2, self.variacion_roja, self.variacion_verde, tabla]
            doc.build(contenido)
            buffer_file.seek(0)
            logger.info("Se ha generado el PDF en Bytes correctamente")
            return buffer_file.getvalue()
        except (Exception,):
            logger.error(create_log_msg("Falló en la generación del pdf"))
            raise PlataformError("Hubo un error en la generación del pdf")
        
    def load_info_s3(self, bucket_s3, s3_file_path,pdf_bytes, name_pdf):
        """Guarda el archivo pdf generado en el S3"""
        try:
            s3 = boto3.client('s3')
            s3.put_object(Body=pdf_bytes, Bucket=bucket_s3, Key=s3_file_path+name_pdf)
            logger.info("Se guardo el PDF de las variaciones en el S3 correctamente")
        except (Exception,):
            logger.error(create_log_msg("No se pudo guardar el PDF en el S3"))

    
class ExchangeRateVariations():
    """Orquesta la generacion"""
    def __init__(self, url_connection_utils, url_connection_rates, valuation_date) -> None:
        self.db_utils = DataBaseHandler(url_connection_utils)
        self.db_rates = DataBaseHandler(url_connection_rates)
        self.valuation_date = datetime.strptime(valuation_date, "%Y-%m-%d").date()

    def extract_data(self):
        """Orquesta la extracción de la informacion de la clase DataBaseHandler"""
        try:
            self.previous_business_day = self.db_utils.get_calendars(self.valuation_date)
            self.df_previous_rates = self.db_rates.get_calculated_rates(self.previous_business_day)
            self.df_today_rates = self.db_rates.get_calculated_rates(self.valuation_date)
        except (Exception,):
            logger.error(create_log_msg("Fallo la etapa de extracción de información"))
            raise
    def transform_data(self):
        """Orquesta la transformación de la informacion de la clase DataBaseHandler"""
        try:
            data_transformer = Transformer(self.df_previous_rates, self.df_today_rates)
            data_transformer.join_data()
            data_transformer.calculate_difference()
            data_transformer.calculate_logarithmic_variation()
            data_transformer.clean_nulls()
            data_transformer.select_data()
            data_transformer.rename_and_order_columns()
            self.data_transform = data_transformer.df_rate_report
        except (Exception,):
            logger.error(create_log_msg("Fallo la etapa de transformación de la data para el reporte"))
            raise
    
    def load_info_pdf(self, bucket_s3, s3_file_path, param_variation):
        """Orquesta la extracción de la informacion de la clase DataBaseHandler"""

        self.date_str = self.valuation_date.strftime('%Y-%m-%d')
        self.name_pdf = 'VariacionesTasas_YYYYMMDD.pdf'.replace('YYYYMMDD', self.valuation_date.strftime('%Y%m%d'))
        pdf = PDFReport(self.data_transform)
        pdf.generate_styles()
        pdf.paint_data_boxes(param_variation)
        pdf.generate_titles_with_styles(param_variation, self.date_str)
        self.pdf_bytes = pdf.generate_pdf()
        pdf.load_info_s3(bucket_s3, s3_file_path, self.pdf_bytes, self.name_pdf)
    
    def send_report_email(self, data_smtp, mail_subject, body):
        """Envia el correo con el pdf del reporte"""
        # Crear el mensaje de correo electrónico
        try:
            msg = MIMEMultipart()
            msg['From'] = data_smtp["mail_from"]
            msg['To'] = data_smtp["mail_to"]
            msg['Subject'] = mail_subject

            # Agregar el cuerpo del correo electrónico
            msg.attach(MIMEText(body))

            # Agregar el archivo PDF como adjunto
            adjunto = MIMEApplication(self.pdf_bytes, _subtype='pdf', _encoder=encoders.encode_base64)
            adjunto.add_header('Content-Disposition', 'attachment', filename=self.name_pdf)
            msg.attach(adjunto)
        except (Exception,):
            logger.error(create_log_msg("Falló en adjuntar el pdf al correo"))
            raise PlataformError("Hubo un error en adjuntar el pdf al correo")

        # Conectar con el servidor SMTP y enviar el correo electrónico
        try:
            servidor_smtp = data_smtp["smtp_server"]
            puerto_smtp = int(data_smtp["smtp_port"])
            usuario_smtp = data_smtp["smtp_user"]
            password_smtp = data_smtp["smtp_password"]
            smtp_server = smtplib.SMTP(servidor_smtp, puerto_smtp)
            smtp_server.starttls()
            smtp_server.login(usuario_smtp, password_smtp)
            smtp_server.sendmail(data_smtp["mail_from"], data_smtp["mail_to"], msg.as_string())
            smtp_server.quit()
            logger.info("Se ha enviado el reporte por correo exitosamente")
        except (Exception,):
            logger.error(create_log_msg("Falló el envio del correo"))
            raise PlataformError("Hubo un error en el envio del correo")