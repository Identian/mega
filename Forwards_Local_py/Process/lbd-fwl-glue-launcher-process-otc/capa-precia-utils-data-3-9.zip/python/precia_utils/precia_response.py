"""
=============================================================

Nombre: precia_response.py
Tipo: Modulo

Autor:
    - Ruben Antonio Parra Medrano
Tecnología - Precia

Ultima modificación: 21/09/2022

Reune las funcionalidades de dar respuesta con formato para
Precia

=============================================================
"""

import logging

from precia_utils.precia_constants import STATUS_CODE_DESCRIPTIONS
from precia_utils.precia_logger import create_log_msg

logger = logging.getLogger()

def create_error_response(status_code, error_message, context):
    """
    Crea la respuesta del API en caso de error, cumple el HTTP protocol version
    1.1 Server Response Codes. Entre los valores que el diccionario que retorna
    se encuentra 'log_group', 'error_message' y 'request_id' que permite buscar
    el log en CloudWatch AWS
    :param status_code: Integer de codigo de respuesta del servidor 4XX o 5XX
    conforme al HTTP protocol version 1.1 Server Response Codes
    :param error_message: String con un mensaje en espaniol para que el usuario
    del API
    :param query_time: String de la fecha y hora que se ejecuto la solicitud
    :param context: Contexto del Lambda AWS
    :return: Diccionario con la respuesta lista para retornar al servicio API
    Gateway AWS
    """
    try:
        logger.debug(
            "[precia_utils.create_error_response] Creando respuesta: error ..."
        )
        error_response = {"statusCode": status_code}
        body = {
            "error_type": STATUS_CODE_DESCRIPTIONS[status_code],
            "error_message": error_message,
        }
        stack_trace = {
            "log_group": str(context.log_group_name),
            "log_stream": str(context.log_stream_name),
            "request_id": str(context.aws_request_id),
        }
        body["stack_trace"] = stack_trace
        error_response["body"] = body
        logger.debug("[Respuesta creada.")
        return error_response
    except (Exception, ):
        log_msg = 'No se purdo crear respuesta'
        logger.critical(create_log_msg(log_msg))
