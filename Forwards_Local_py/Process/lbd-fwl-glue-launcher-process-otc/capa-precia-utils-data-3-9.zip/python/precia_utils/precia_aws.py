"""
=============================================================

Nombre: precia_aws.py
Tipo: Modulo

Autor:
    - Ruben Antonio Parra Medrano
Tecnología - Precia

Ultima modificación: 21/09/2022

Reune las funcionalidades para usar la libreria boto3 que
es el sdk de AWS para python

=============================================================
"""

import base64
import json
import logging
import os

import boto3

from precia_utils.precia_constants import DEFAULT_SECRET_REGION
from precia_utils.precia_exceptions import PlataformError
from precia_utils.precia_logger import create_log_msg

logger = logging.getLogger()


def get_environment_variable(variable_key: str) -> str:
    """
    Obtiene la variable de entorno bajo la llave 'variable_key', sino
    lo encuentra lanza un exception

    Args:
        variable_key (str): Nombre de la variable de entorno configurada
        en la lambda

    Raises:
        PlataformError: Cuando no encuentra ninguna variable bajo el nombre
        declarado en 'variable_key'

    Returns:
        str: String con el valor relacionado con la llave 'variable_key'
    """
    try:
        logger.info('Obteniendo variables de entorno "%s" ...', variable_key)
        variable_value = os.environ[str(variable_key)]
        logger.info("Variable obtenida con exito.")
        return variable_value
    except Exception as var_exc:
        logger.error(create_log_msg("No se encontro variable de entorno"))
        raise PlataformError("Variable de entorno no encontrada") from var_exc


def get_secret(secret_region: str, secret_name: str) -> dict:
    """
    Obtiene secretos almacenados en el servicio Secrets Manager de AWS.

    Args:
        secret_region (str): Region donde se encuentra el secreto.
        secret_name (str): Nombre del secreto en el servicio AWS.

    Raises:
        PlataformError: Cuando ocurre algun error al obtener el secreto.

    Returns:
        dict: Secreto con la informacion desplegada en Secrets Manager AWS.
    """
    try:
        logger.info('Intentando obtener secreto: "%s" ...', secret_name)
        session = boto3.session.Session()
        cliente_secrets_manager = session.client(
            service_name="secretsmanager", region_name=secret_region
        )
        secret_data = cliente_secrets_manager.get_secret_value(SecretId=secret_name)
        if "SecretString" in secret_data:
            secret_str = secret_data["SecretString"]
        else:
            secret_str = base64.b64decode(secret_data["SecretBinary"])
        logger.info("Se obtuvo el secreto.")
        return json.loads(secret_str)
    except Exception as sec_exc:
        error_msg = f'Fallo en obtener el secreto "{secret_name}"'
        logger.error(create_log_msg(error_msg))
        raise PlataformError(error_msg) from sec_exc


def get_config_secret(
    secret_name: str, secret_region: str = DEFAULT_SECRET_REGION
) -> dict:
    """
    Obtiene el secreto de configuracion desde Secrets Manager AWS.

    Args:
        secret_name (str): Nombre del secreto de configuracion.
        secret_region (str, optional): Region donde se encuentra el secreto.
        Defaults to DEFAULT_SECRET_REGION.

    Returns:
        dict: Secreto de configuracion.
    """
    return get_secret(secret_region, secret_name)
