"""
=============================================================

Nombre: precia_constants.py
Tipo: Modulo

Autor:
    - Ruben Antonio Parra Medrano
Tecnología - Precia

Ultima modificación: 21/09/2022

Reune las contanstes que no tienen que ver con logica del
negocio, y son usadas por dos o mas modulos de precia_utils

=============================================================
"""

# Region por defecto para obtener el secretos desde Secrets Manager AWS
DEFAULT_SECRET_REGION = "us-east-1"
# Status codes HTML usados para dar respuesta a la solicitud de datos
STATUS_CODE_DESCRIPTIONS = {
    204: "No data",
    400: "Bad Request",
    500: "Internal Server Error",
    503: 'Service Unavailable'
}
